@echo off
echo ============================================
echo   NitoCoin Uninstaller
echo ============================================
echo.
echo This will remove NitoCoin from your system.
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0uninstall-nito-core.ps1"

pause
