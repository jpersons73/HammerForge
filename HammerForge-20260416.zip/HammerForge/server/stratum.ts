// Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
// Proprietary and confidential. See LICENSE file for details.

import * as net from "net";
import { randomUUID } from "crypto";
import { createHash } from "crypto";
import { exec } from "child_process";
import * as fs from "fs";
import * as path from "path";
import { storage } from "./storage";
import type { Worker, ShareEntry } from "@shared/schema";
import { log } from "./index";
import { getBlockTemplate, getFreshBlockTemplate, isTemplateAvailable, setOnNewBlock, submitBlock, rpcCall } from "./rpc";
import type { BlockTemplate } from "./rpc";
import { sendBlockFoundEmail } from "./email";

interface StratumClient {
  id: string;
  socket: net.Socket;
  workerName: string;
  walletAddress: string;
  authorized: boolean;
  subscribed: boolean;
  difficulty: number;
  ipAddress: string;
  buffer: string;
  userAgent: string;
  extranonce1: string;
  versionMask: string;
  mappedWorkerId: string;
  notifyEmail: string;
  vardiffShareTimes: number[];
  vardiffLastAdjust: number;
  reportedHashrate: number;
}

const MIN_DIFFICULTY = 1;
const MINER_MIN_DIFFICULTY = 10000;
const DEFAULT_DIFFICULTY = 15000;
const NICEHASH_MIN_DIFFICULTY = 500000;
const MAX_DIFFICULTY = 4000000000;
const VARDIFF_TARGET_SECONDS = 15;
const VARDIFF_RETARGET_SECONDS = 15;
const VARDIFF_VARIANCE = 0.40;
const VARDIFF_NO_SHARE_TIMEOUT = 30;
const EXTRANONCE2_SIZE = 4;

interface JobTemplate {
  jobId: string;
  version: string;
  prevHash: string;
  prevHashStratum: string;
  coinb1: string;
  coinb2: string;
  merkleBranches: string[];
  nbits: string;
  ntime: string;
  isReal: boolean;
  blockTemplate: BlockTemplate | null;
  coinbaseTxPrefix: string;
  coinbaseTxSuffix: string;
}

const clients: Map<string, StratumClient> = new Map();
const jobTemplates: Map<string, JobTemplate> = new Map();
let server: net.Server | null = null;
let jobCounter = 0;
let upnpRefreshInterval: ReturnType<typeof setInterval> | null = null;
let upnpMappedPort: number | null = null;
let currentJobId = "";
let extranonce1Counter = 0;
const DIFF1_TARGET = BigInt("0x00000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");

function generateJobId(): string {
  jobCounter++;
  return jobCounter.toString(16).padStart(8, "0");
}

function generateExtranonce1(): string {
  const bytes = Buffer.alloc(4);
  bytes.writeUInt32BE(Math.floor(Math.random() * 0xFFFFFFFF) >>> 0, 0);
  return bytes.toString("hex");
}

function hashrateToDifficulty(hashrate: number): number {
  return Math.max(MIN_DIFFICULTY, Math.floor(hashrate / 4294967296));
}

function adjustVardiff(client: StratumClient): void {
  const now = Date.now();
  const timeSinceLastAdjust = (now - client.vardiffLastAdjust) / 1000;
  const shareCount = client.vardiffShareTimes.length;

  if (timeSinceLastAdjust < VARDIFF_RETARGET_SECONDS) return;

  const isNH = client.userAgent.toLowerCase().includes("nicehash") ||
    client.userAgent.toLowerCase().includes("nhmp");
  const floorDiff = isNH ? NICEHASH_MIN_DIFFICULTY : MINER_MIN_DIFFICULTY;

  if (shareCount < 1) {
    if (timeSinceLastAdjust >= VARDIFF_NO_SHARE_TIMEOUT && client.difficulty > floorDiff) {
      if (isNH) return;
      const oldDiff = client.difficulty;
      let newDiff = Math.max(floorDiff, Math.floor(client.difficulty / 2));
      client.difficulty = newDiff;
      client.vardiffLastAdjust = now;
      client.vardiffShareTimes = [];
      sendToClient(client, { id: null, method: "mining.set_difficulty", params: [newDiff] });
      log(`Vardiff DOWN (idle ${timeSinceLastAdjust.toFixed(0)}s): ${client.workerName || client.ipAddress} ${oldDiff.toLocaleString()} -> ${newDiff.toLocaleString()}`, "stratum");
    }
    return;
  }

  const windowSeconds = timeSinceLastAdjust;
  const sharesPerSecond = shareCount / windowSeconds;
  const avgInterval = shareCount > 0 ? windowSeconds / shareCount : windowSeconds;

  const targetLow = VARDIFF_TARGET_SECONDS * (1 - VARDIFF_VARIANCE);
  const targetHigh = VARDIFF_TARGET_SECONDS * (1 + VARDIFF_VARIANCE);

  if (avgInterval >= targetLow && avgInterval <= targetHigh) {
    client.vardiffLastAdjust = now;
    client.vardiffShareTimes = [];
    return;
  }

  const ratio = avgInterval / VARDIFF_TARGET_SECONDS;
  let newDiff: number;
  if (ratio < 1) {
    newDiff = Math.round(client.difficulty / ratio);
  } else {
    newDiff = Math.round(client.difficulty / ratio);
  }
  newDiff = Math.max(floorDiff, Math.min(MAX_DIFFICULTY, newDiff));

  if (newDiff === client.difficulty) {
    client.vardiffLastAdjust = now;
    client.vardiffShareTimes = [];
    return;
  }

  const oldDiff = client.difficulty;
  client.difficulty = newDiff;
  client.vardiffLastAdjust = now;
  client.vardiffShareTimes = [];

  sendToClient(client, {
    id: null,
    method: "mining.set_difficulty",
    params: [newDiff],
  });

  const direction = newDiff > oldDiff ? "UP" : "DOWN";
  log(`Vardiff ${direction}: ${client.workerName || client.ipAddress} ${oldDiff.toLocaleString()} -> ${newDiff.toLocaleString()}`, "stratum");
}

function sha256d(data: Buffer): Buffer {
  const first = createHash("sha256").update(data).digest();
  return createHash("sha256").update(first).digest();
}

function reverseBytes(hex: string): string {
  const bytes = [];
  for (let i = 0; i < hex.length; i += 2) {
    bytes.push(hex.slice(i, i + 2));
  }
  return bytes.reverse().join("");
}

function swapEndian32(hex: string): string {
  let result = "";
  for (let i = 0; i < hex.length; i += 8) {
    const chunk = hex.slice(i, i + 8);
    for (let j = 6; j >= 0; j -= 2) {
      result += chunk.slice(j, j + 2);
    }
  }
  return result;
}

function bech32Decode(address: string): { version: number; program: Buffer } | null {
  try {
    const CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
    const addr = address.toLowerCase();
    const sepIdx = addr.lastIndexOf("1");
    if (sepIdx < 1) return null;

    const data: number[] = [];
    for (let i = sepIdx + 1; i < addr.length; i++) {
      const idx = CHARSET.indexOf(addr[i]);
      if (idx === -1) return null;
      data.push(idx);
    }

    const version = data[0];
    const payload = data.slice(1, data.length - 6);

    let acc = 0;
    let bits = 0;
    const result: number[] = [];
    for (const value of payload) {
      acc = (acc << 5) | value;
      bits += 5;
      while (bits >= 8) {
        bits -= 8;
        result.push((acc >> bits) & 0xff);
      }
    }

    return { version, program: Buffer.from(result) };
  } catch {
    return null;
  }
}

function cashAddrPolymod(values: number[]): bigint {
  const GENERATORS = [
    0x98f2bc8e61n, 0x79b76d99e2n, 0xf33e5fb3c4n, 0xae2eabe2a8n, 0x1e4f43e470n
  ];
  let chk = 1n;
  for (const v of values) {
    const top = chk >> 35n;
    chk = ((chk & 0x07ffffffffn) << 5n) ^ BigInt(v);
    for (let i = 0; i < 5; i++) {
      if ((top >> BigInt(i)) & 1n) {
        chk ^= GENERATORS[i];
      }
    }
  }
  return chk ^ 1n;
}

function cashAddrHrpExpand(hrp: string): number[] {
  const result: number[] = [];
  for (const c of hrp) {
    result.push(c.charCodeAt(0) & 0x1f);
  }
  result.push(0);
  return result;
}

function cashAddrDecode(address: string): { type: number; hash: Buffer } | null {
  try {
    const CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
    let addr = address.toLowerCase();
    let hrp = "";
    const colonIdx = addr.indexOf(":");
    if (colonIdx >= 0) {
      hrp = addr.slice(0, colonIdx);
      addr = addr.slice(colonIdx + 1);
    } else {
      return null;
    }
    const validHrps = ["bitcoincash", "bitcoincashii", "ecash", "bchtest", "ectest"];
    if (!validHrps.includes(hrp)) return null;
    const data: number[] = [];
    for (const c of addr) {
      const idx = CHARSET.indexOf(c);
      if (idx === -1) return null;
      data.push(idx);
    }
    if (data.length < 8) return null;
    const hrpData = cashAddrHrpExpand(hrp);
    const checksumInput = [...hrpData, ...data];
    if (cashAddrPolymod(checksumInput) !== 0n) return null;
    const payload = data.slice(0, data.length - 8);
    const versionByte = payload[0];
    const typeBits = (versionByte >> 3) & 0x1f;
    const hashSizeBits = versionByte & 0x07;
    const hashSizes: Record<number, number> = { 0: 20, 1: 24, 2: 28, 3: 32, 4: 40, 5: 48, 6: 56, 7: 64 };
    const expectedSize = hashSizes[hashSizeBits];
    if (expectedSize === undefined) return null;
    const rest = payload.slice(1);
    let acc = 0;
    let bits = 0;
    const result: number[] = [];
    for (const value of rest) {
      acc = (acc << 5) | value;
      bits += 5;
      while (bits >= 8) {
        bits -= 8;
        result.push((acc >> bits) & 0xff);
      }
    }
    const hashBytes = Buffer.from(result.slice(0, expectedSize));
    if (hashBytes.length !== expectedSize) return null;
    return { type: typeBits, hash: hashBytes };
  } catch {
    return null;
  }
}

function addressToScriptPubKey(address: string): string {
  if (address.startsWith("bc1q") || address.startsWith("bc1p") ||
      address.startsWith("BC1Q") || address.startsWith("BC1P") ||
      address.startsWith("tb1q") || address.startsWith("tb1p") ||
      address.startsWith("dgb1q") || address.startsWith("dgb1p") ||
      address.startsWith("DGB1Q") || address.startsWith("DGB1P") ||
      address.startsWith("pc1q") || address.startsWith("pc1p") ||
      address.startsWith("PC1Q") || address.startsWith("PC1P") ||
      address.startsWith("xro1q") || address.startsWith("xro1p") ||
      address.startsWith("XRO1Q") || address.startsWith("XRO1P") ||
      address.startsWith("nito1q") || address.startsWith("nito1p") ||
      address.startsWith("NITO1Q") || address.startsWith("NITO1P") ||
      address.startsWith("lcc1q") || address.startsWith("lcc1p") ||
      address.startsWith("LCC1Q") || address.startsWith("LCC1P") ||
      address.startsWith("fb1q") || address.startsWith("fb1p") ||
      address.startsWith("FB1Q") || address.startsWith("FB1P") ||
      address.startsWith("firo1q") || address.startsWith("firo1p") ||
      address.startsWith("FIRO1Q") || address.startsWith("FIRO1P")) {
    const decoded = bech32Decode(address);
    if (!decoded) return "";

    if (decoded.version === 0 && decoded.program.length === 20) {
      return "0014" + decoded.program.toString("hex");
    }
    if (decoded.version === 0 && decoded.program.length === 32) {
      return "0020" + decoded.program.toString("hex");
    }
    if (decoded.version === 1 && decoded.program.length === 32) {
      return "5120" + decoded.program.toString("hex");
    }
    return "";
  }

  const addrLower = address.toLowerCase();
  if (addrLower.startsWith("bitcoincash:q") || addrLower.startsWith("bitcoincash:p") ||
      addrLower.startsWith("bitcoincashii:q") || addrLower.startsWith("bitcoincashii:p") ||
      addrLower.startsWith("ecash:q") || addrLower.startsWith("ecash:p")) {
    const decoded = cashAddrDecode(address);
    if (!decoded) return "";
    if (decoded.type === 0 && decoded.hash.length === 20) {
      return "76a914" + decoded.hash.toString("hex") + "88ac";
    }
    if (decoded.type === 1 && decoded.hash.length === 20) {
      return "a914" + decoded.hash.toString("hex") + "87";
    }
    return "";
  }

  if (address.startsWith("1") || address.startsWith("m") || address.startsWith("n") ||
      address.startsWith("D") || address.startsWith("P") ||
      address.startsWith("N") || address.startsWith("C") ||
      address.startsWith("a") || address.startsWith("L") ||
      address.startsWith("F") || address.startsWith("E")) {
    const decoded = base58Decode(address);
    if (!decoded || decoded.length < 21) return "";
    const hash160 = decoded.slice(1, 21).toString("hex");
    return "76a914" + hash160 + "88ac";
  }

  if (address.startsWith("3") || address.startsWith("2") ||
      address.startsWith("S") || address.startsWith("p") ||
      address.startsWith("M") || address.startsWith("Z")) {
    const decoded = base58Decode(address);
    if (!decoded || decoded.length < 21) return "";
    const hash160 = decoded.slice(1, 21).toString("hex");
    return "a914" + hash160 + "87";
  }

  const genericBase58 = base58Decode(address);
  if (genericBase58 && genericBase58.length >= 21) {
    const versionByte = genericBase58[0];
    const hash160 = genericBase58.slice(1, 21).toString("hex");
    if (versionByte === 0x05 || versionByte === 0x32 || versionByte === 0xC4) {
      log(`Address decoded via generic base58 P2SH (version=0x${versionByte.toString(16)}): ${address.slice(0, 8)}...`, "stratum");
      return "a914" + hash160 + "87";
    }
    log(`Address decoded via generic base58 P2PKH (version=0x${versionByte.toString(16)}): ${address.slice(0, 8)}...`, "stratum");
    return "76a914" + hash160 + "88ac";
  }

  return "";
}

function base58Decode(str: string): Buffer | null {
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  try {
    let num = BigInt(0);
    for (const c of str) {
      const idx = ALPHABET.indexOf(c);
      if (idx === -1) return null;
      num = num * 58n + BigInt(idx);
    }
    let hex = num.toString(16);
    if (hex.length % 2) hex = "0" + hex;
    let leadingZeros = 0;
    for (const c of str) {
      if (c === "1") leadingZeros++;
      else break;
    }
    const prefix = "00".repeat(leadingZeros);
    return Buffer.from(prefix + hex, "hex");
  } catch {
    return null;
  }
}

function encodeVarInt(n: number): string {
  if (n < 0xfd) {
    return n.toString(16).padStart(2, "0");
  } else if (n <= 0xffff) {
    return "fd" + Buffer.from([n & 0xff, (n >> 8) & 0xff]).toString("hex");
  } else if (n <= 0xffffffff) {
    const buf = Buffer.alloc(4);
    buf.writeUInt32LE(n);
    return "fe" + buf.toString("hex");
  }
  return "ff" + "0000000000000000";
}

function encodeScriptNum(height: number): string {
  if (height <= 0) return "00";
  const bytes: number[] = [];
  let val = height;
  while (val > 0) {
    bytes.push(val & 0xff);
    val >>= 8;
  }
  if (bytes[bytes.length - 1] & 0x80) {
    bytes.push(0);
  }
  const lenByte = bytes.length.toString(16).padStart(2, "0");
  return lenByte + Buffer.from(bytes).toString("hex");
}

function satoshisToLE8(satoshis: number): string {
  const buf = Buffer.alloc(8);
  const lo = satoshis % 0x100000000;
  const hi = Math.floor(satoshis / 0x100000000);
  buf.writeUInt32LE(lo >>> 0, 0);
  buf.writeUInt32LE(hi >>> 0, 4);
  return buf.toString("hex");
}

function uint32ToLE(n: number): string {
  const buf = Buffer.alloc(4);
  buf.writeUInt32LE(n >>> 0);
  return buf.toString("hex");
}

const COINS_WITH_TX_TIME = ["PPC"];

function buildCoinbaseTransaction(
  template: BlockTemplate,
  walletAddress: string,
  extranonce1Len: number,
  extranonce2Len: number
): { coinb1: string; coinb2: string } {
  const heightScript = encodeScriptNum(template.height);
  const extranonceLen = extranonce1Len + extranonce2Len;
  const coin = storage.getConfig().coin;
  const coinbaseTags: Record<string, string> = {
    BC2: "/BC2Solo/", DGB: "/DGBSolo/", BTC: "/BTCSolo/",
    BCH: "/BCHSolo/", BSV: "/BSVSolo/", XEC: "/XECSolo/",
    FB: "/FBSolo/", PPC: "/PPCSolo/", LCC: "/LCCSolo/", NITO: "/NITOSolo/",
    BCH2: "/BCH2Solo/",
    XRO: "/XROSolo/"
  };
  const coinbaseTag = coinbaseTags[coin] || "/Solo/";
  const arbitraryData = Buffer.from(coinbaseTag, "utf8").toString("hex");
  const auxFlags = template.coinbaseaux?.flags || "";
  const scriptSigBeforeExtranonce = heightScript + auxFlags + arbitraryData;
  const totalScriptSigLen = scriptSigBeforeExtranonce.length / 2 + extranonceLen;
  const scriptSigLenHex = totalScriptSigLen.toString(16).padStart(2, "0");

  const txTimestamp = COINS_WITH_TX_TIME.includes(coin) ? uint32ToLE(template.curtime) : "";

  const coinb1 =
    "02000000" +
    txTimestamp +
    "01" +
    "0000000000000000000000000000000000000000000000000000000000000000" +
    "ffffffff" +
    scriptSigLenHex +
    scriptSigBeforeExtranonce;

  let scriptPubKey = addressToScriptPubKey(walletAddress);
  if (!scriptPubKey && walletAddress && rpcScriptPubKeyCache[walletAddress]) {
    scriptPubKey = rpcScriptPubKeyCache[walletAddress];
    log(`Using cached RPC-decoded scriptPubKey for ${walletAddress.slice(0, 12)}...`, "stratum", true);
  }
  if (!scriptPubKey) {
    log(`CRITICAL: Could not decode wallet address "${walletAddress}" for ${coin}`, "stratum");
    log(`  Block rewards will be UNSPENDABLE until this is fixed!`, "stratum");
    log(`  Supported formats: base58 (1/3/D/N/P/C/a/L/F...), bech32 (bc1q/dgb1q/nito1q/lcc1q/xro1q/pc1q/fb1q/firo1q...), cashaddr (bitcoincash:q/ecash:q/bitcoincashii:q)`, "stratum");
    log(`  Attempting RPC fallback via validateaddress...`, "stratum");
  }

  const valueHex = satoshisToLE8(template.coinbasevalue);
  const scriptPubKeyLenHex = (scriptPubKey.length / 2).toString(16).padStart(2, "0");

  const noSegwitCoins = ["BSV", "BCH", "XEC", "BCH2"];
  const hasWitness = noSegwitCoins.includes(coin) ? false : template.transactions.some(tx => tx.hash && tx.hash !== tx.txid);

  let coinb2 = "";
  coinb2 += "ffffffff";

  if (hasWitness) {
    const witnessCommitmentScript = buildWitnessCommitment(template);
    const witnessCommitmentScriptLen = (witnessCommitmentScript.length / 2).toString(16).padStart(2, "0");
    coinb2 += "02";
    coinb2 += valueHex + scriptPubKeyLenHex + scriptPubKey;
    coinb2 += satoshisToLE8(0) + witnessCommitmentScriptLen + witnessCommitmentScript;
  } else {
    coinb2 += "01";
    coinb2 += valueHex + scriptPubKeyLenHex + scriptPubKey;
  }

  coinb2 += "00000000";

  return { coinb1, coinb2 };
}

function addWitnessToCoinbase(nonWitnessCoinbase: string): string {
  const coin = storage.getConfig().coin;
  const prefixLen = COINS_WITH_TX_TIME.includes(coin) ? 16 : 8;
  const prefix = nonWitnessCoinbase.slice(0, prefixLen);
  const locktime = nonWitnessCoinbase.slice(-8);
  const middle = nonWitnessCoinbase.slice(prefixLen, -8);
  const witnessStack = "01" + "20" + "0000000000000000000000000000000000000000000000000000000000000000";
  return prefix + "0001" + middle + witnessStack + locktime;
}

function buildWitnessCommitment(template: BlockTemplate): string {
  const witnessMerkleRoot = computeWitnessMerkleRoot(template);
  const witnessReserved = "0000000000000000000000000000000000000000000000000000000000000000";
  const combined = Buffer.from(witnessMerkleRoot + witnessReserved, "hex");
  const commitment = sha256d(combined).toString("hex");
  return "6a24aa21a9ed" + commitment;
}

function computeWitnessMerkleRoot(template: BlockTemplate): string {
  const leaves: Buffer[] = [];
  leaves.push(Buffer.alloc(32, 0));
  for (const tx of template.transactions) {
    leaves.push(Buffer.from(reverseBytes(tx.hash || tx.txid), "hex"));
  }
  return computeMerkleRootFromBuffers(leaves).toString("hex");
}

function computeMerkleRootFromBuffers(leaves: Buffer[]): Buffer {
  if (leaves.length === 0) return Buffer.alloc(32, 0);
  let level = [...leaves];
  while (level.length > 1) {
    const next: Buffer[] = [];
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = i + 1 < level.length ? level[i + 1] : left;
      next.push(sha256d(Buffer.concat([left, right])));
    }
    level = next;
  }
  return level[0];
}

function computeMerkleBranches(template: BlockTemplate): string[] {
  const branches: string[] = [];
  const coin = storage.getConfig().coin;
  const CTOR_COINS = ["BCH", "XEC", "BCH2"];
  let txList = template.transactions;
  if (CTOR_COINS.includes(coin) && txList.length > 1) {
    txList = [...txList].sort((a, b) => {
      const aBuf = Buffer.from(a.txid, "hex");
      const bBuf = Buffer.from(b.txid, "hex");
      return Buffer.compare(aBuf, bBuf);
    });
  }
  let hashes = txList.map(tx =>
    Buffer.from(reverseBytes(tx.txid), "hex")
  );

  while (hashes.length > 0) {
    branches.push(hashes.shift()!.toString("hex"));

    const paired: Buffer[] = [];
    for (let i = 0; i < hashes.length; i += 2) {
      const left = hashes[i];
      const right = i + 1 < hashes.length ? hashes[i + 1] : left;
      paired.push(sha256d(Buffer.concat([left, right])));
    }
    hashes = paired;
  }

  return branches;
}

let shareDebugCount = 0;

const rpcScriptPubKeyCache: Record<string, string> = {};

async function resolveAddressViaRPC(address: string): Promise<string> {
  if (!address) return "";
  if (rpcScriptPubKeyCache[address]) return rpcScriptPubKeyCache[address];
  try {
    const result = await rpcCall("validateaddress", [address]);
    if (result && result.scriptPubKey) {
      rpcScriptPubKeyCache[address] = result.scriptPubKey;
      log(`RPC validateaddress resolved "${address.slice(0, 12)}..." -> scriptPubKey=${result.scriptPubKey.slice(0, 20)}... (${result.scriptPubKey.length / 2} bytes)`, "stratum");
      return result.scriptPubKey;
    }
    const result2 = await rpcCall("getaddressinfo", [address]);
    if (result2 && result2.scriptPubKey) {
      rpcScriptPubKeyCache[address] = result2.scriptPubKey;
      log(`RPC getaddressinfo resolved "${address.slice(0, 12)}..." -> scriptPubKey=${result2.scriptPubKey.slice(0, 20)}... (${result2.scriptPubKey.length / 2} bytes)`, "stratum");
      return result2.scriptPubKey;
    }
    log(`RPC address resolution failed: no scriptPubKey returned for "${address}"`, "stratum");
  } catch (err: any) {
    log(`RPC address resolution error for "${address.slice(0, 12)}...": ${err.message}`, "stratum");
  }
  return "";
}

interface ShareResult {
  difficulty: number;
  hash: string;
  headerHex: string;
  coinbaseTx: string;
  blockHeaderHex: string;
  blockHash: string;
  blockDifficulty: number;
}

function computeShareDifficulty(
  job: JobTemplate,
  extranonce1: string,
  extranonce2: string,
  ntime: string,
  nonce: string,
  versionBits: string
): ShareResult {
  try {
    const paddedExtranonce2 = extranonce2.padEnd(EXTRANONCE2_SIZE * 2, "0");
    const coinbaseTx = job.coinb1 + extranonce1 + paddedExtranonce2 + job.coinb2;
    const coinbaseHash = sha256d(Buffer.from(coinbaseTx, "hex"));

    let merkleRoot = coinbaseHash;
    for (const branch of job.merkleBranches) {
      const branchBuf = Buffer.from(branch, "hex");
      const combined = Buffer.concat([merkleRoot, branchBuf]);
      merkleRoot = sha256d(combined);
    }

    let version = job.version;
    if (versionBits) {
      const baseVersion = parseInt(version, 16);
      const rolledBits = parseInt(versionBits, 16);
      const rollingMask = 0x1fffe000;
      version = (((baseVersion & ~rollingMask) | (rolledBits & rollingMask)) >>> 0).toString(16).padStart(8, "0");
    }

    const merkleRootHex = merkleRoot.toString("hex");

    const versionLE = swapEndian32(version);
    const ntimeLE = swapEndian32(ntime);
    const nbitsLE = swapEndian32(job.nbits);
    const nonceLE = swapEndian32(nonce);

    const blockHeader = versionLE + job.prevHashStratum + merkleRootHex + ntimeLE + nbitsLE + nonceLE;
    const blockHashBuf = sha256d(Buffer.from(blockHeader, "hex"));
    const blockHashHex = reverseBytes(blockHashBuf.toString("hex"));
    const blockHashBig = BigInt("0x" + blockHashHex);
    const blockDiff = blockHashBig === 0n ? Number.MAX_SAFE_INTEGER : Number(DIFF1_TARGET / blockHashBig);

    const shouldDebug = shareDebugCount < 10 || blockDiff >= 1000000000;
    if (shouldDebug) {
      shareDebugCount++;
      log(`[ShareDebug #${shareDebugCount}] ver=${version} ntime=${ntime} nonce=${nonce} vbits=${versionBits}`, "stratum", true);
      log(`[ShareDebug] prevHash(display)=${job.prevHash.slice(0, 16)}... prevHash(stratum/internal)=${job.prevHashStratum.slice(0, 16)}...`, "stratum", true);
      log(`[ShareDebug] merkle=${merkleRootHex.slice(0, 16)}... nbits=${job.nbits}`, "stratum", true);
      log(`[ShareDebug] header(160)=${blockHeader.slice(0, 160)}`, "stratum", true);
      log(`[ShareDebug] hash=${blockHashHex.slice(0, 24)}... diff=${blockDiff.toFixed(2)} isReal=${job.isReal}`, "stratum", true);
    }

    return {
      difficulty: Math.max(1, blockDiff),
      hash: blockHashHex,
      headerHex: blockHeader,
      coinbaseTx,
      blockHeaderHex: blockHeader,
      blockHash: blockHashHex,
      blockDifficulty: Math.max(1, blockDiff),
    };
  } catch (err: any) {
    log(`ERROR in computeShareDifficulty: ${err.message} stack=${err.stack?.slice(0, 200)}`, "stratum");
    const fallbackHash = createHash("sha256")
      .update(`${job.jobId}${extranonce1}${extranonce2}${ntime}${nonce}`)
      .digest("hex");
    return { difficulty: 1, hash: fallbackHash, headerHex: "", coinbaseTx: "", blockHeaderHex: "", blockHash: fallbackHash, blockDifficulty: 1 };
  }
}

function findMatchingWorker(client: StratumClient): Worker | undefined {
  const workers = storage.getWorkers();
  const name = client.workerName.toLowerCase();
  const ip = client.ipAddress;
  const agent = client.userAgent.toLowerCase();

  for (const w of workers) {
    if (w.name.toLowerCase() === name) return w;
  }

  for (const w of workers) {
    if (w.ipAddress && w.ipAddress !== "manual" && w.ipAddress === ip) return w;
  }

  for (const w of workers) {
    const wName = w.name.toLowerCase();
    if (name && name !== "unknown" && (name.includes(wName) || wName.includes(name))) return w;
  }

  if (agent) {
    for (const w of workers) {
      const wType = w.minerType.toLowerCase();
      if (!w.connected && wType && agent.includes(wType)) return w;
    }
  }

  return undefined;
}

function handleStratumMessage(client: StratumClient, message: any): void {
  const { id, method, params } = message;

  switch (method) {
    case "mining.configure": {
      const extensions = params?.[0] || [];
      const extensionParams = params?.[1] || {};
      const resultExtensions: Record<string, any> = {};

      if (extensions.includes("version-rolling")) {
        const SERVER_ALLOWED_MASK = 0x1fffe000;
        const minerMask = parseInt(extensionParams["version-rolling.mask"] || "1fffe000", 16);
        let allowedMask = SERVER_ALLOWED_MASK;
        const coinType = storage.getConfig().coin;
        if (coinType === "DGB") {
          allowedMask = (allowedMask & ~0xF00) >>> 0;
        }
        const finalMask = ((minerMask & allowedMask) >>> 0);
        const mask = finalMask.toString(16).padStart(8, "0");
        client.versionMask = mask;
        resultExtensions["version-rolling"] = true;
        resultExtensions["version-rolling.mask"] = mask;
      }

      if (extensions.includes("minimum-difficulty")) {
        resultExtensions["minimum-difficulty"] = true;
      }

      if (extensions.includes("subscribe-extranonce")) {
        resultExtensions["subscribe-extranonce"] = true;
      }

      if (extensions.includes("info")) {
        resultExtensions["info"] = true;
      }

      sendToClient(client, { id, result: resultExtensions, error: null });

      log(`Miner configured: ${client.ipAddress} extensions=[${extensions.join(",")}] versionMask=${client.versionMask || "none"}`, "stratum", true);
      break;
    }

    case "mining.subscribe": {
      const userAgent = params?.[0] || "";
      if (userAgent) {
        client.userAgent = userAgent;
      }

      const isNiceHash = client.userAgent.toLowerCase().includes("nicehash") ||
        client.userAgent.toLowerCase().includes("nhmp");
      if (isNiceHash) {
        if (client.difficulty < NICEHASH_MIN_DIFFICULTY) {
          client.difficulty = NICEHASH_MIN_DIFFICULTY;
        }
        log(`NiceHash miner detected: ${client.userAgent} — difficulty set to ${client.difficulty.toLocaleString()}`, "stratum", true);
      }

      const response = {
        id,
        error: null,
        result: [
          [
            ["mining.notify", client.extranonce1],
          ],
          client.extranonce1,
          EXTRANONCE2_SIZE,
        ],
      };
      sendToClient(client, response);
      client.subscribed = true;

      if (client.authorized) {
        sendToClient(client, {
          id: null,
          method: "mining.set_difficulty",
          params: [client.difficulty],
        });
        sendJob(client);
      }

      log(`Miner subscribed: ${client.ipAddress} agent="${client.userAgent}"`, "stratum", true);
      break;
    }

    case "mining.authorize": {
      const rawName = params?.[0] || "unknown";
      const password = params?.[1] || "";
      const dotIndex = rawName.lastIndexOf(".");
      if (dotIndex > 0) {
        client.walletAddress = rawName.slice(0, dotIndex);
        client.workerName = rawName.slice(dotIndex + 1);
      } else {
        client.walletAddress = "";
        client.workerName = rawName;
      }

      const diffMatch = password.match(/diff[=:](\d+)/i);
      if (diffMatch) {
        const requestedDiff = parseInt(diffMatch[1], 10);
        if (requestedDiff >= MIN_DIFFICULTY && requestedDiff <= MAX_DIFFICULTY) {
          const isNHAuth = client.userAgent.toLowerCase().includes("nicehash") ||
            client.userAgent.toLowerCase().includes("nhmp");
          const authFloor = isNHAuth ? NICEHASH_MIN_DIFFICULTY : MINER_MIN_DIFFICULTY;
          client.difficulty = Math.max(authFloor, requestedDiff);
          log(`Password-based difficulty: ${client.workerName} requested diff=${requestedDiff.toLocaleString()} applied=${client.difficulty.toLocaleString()}`, "stratum", true);
        }
      }

      const emailMatch = password.match(/(?:notif|email)[=:]([^\s,]+@[^\s,]+)/i);
      if (emailMatch) {
        client.notifyEmail = emailMatch[1];
        log(`Notification email set: ${client.workerName} -> ${client.notifyEmail}`, "stratum", true);
      }

      client.authorized = true;

      sendToClient(client, { id, result: true, error: null });

      if (client.subscribed) {
        sendToClient(client, {
          id: null,
          method: "mining.set_difficulty",
          params: [client.difficulty],
        });
        sendJob(client);
      }

      const matchedWorker = findMatchingWorker(client);
      if (matchedWorker) {
        client.mappedWorkerId = matchedWorker.id;
        storage.updateWorker(matchedWorker.id, {
          connected: true,
          connectedAt: Date.now(),
          ipAddress: client.ipAddress,
        });
        log(`Worker matched: ${client.workerName} -> "${matchedWorker.name}"`, "stratum", true);
      } else {
        const newWorker: Worker = {
          id: client.id,
          name: client.workerName || "unnamed",
          minerType: client.userAgent || "unknown",
          ipAddress: client.ipAddress,
          connected: true,
          connectedAt: Date.now(),
          lastShareAt: 0,
          sharesAccepted: 0,
          sharesRejected: 0,
          hashrate1m: 0,
          hashrate5m: 0,
          hashrate1hr: 0,
          hashrate1d: 0,
          bestDifficulty: 0,
          bestDifficultyShare: "",
          colorIndex: storage.getWorkers().length,
          coin: storage.getConfig().coin,
        };
        storage.addWorker(newWorker);
        client.mappedWorkerId = newWorker.id;
        log(`New worker created: ${client.workerName} (${client.ipAddress})`, "stratum");
      }

      log(`Miner authorized: ${client.workerName} (${client.ipAddress})`, "stratum", true);
      break;
    }

    case "mining.submit": {
      if (!client.authorized) {
        const submitName = params?.[0] || "";
        if (submitName) {
          const dotIdx = submitName.lastIndexOf(".");
          if (dotIdx > 0) {
            client.walletAddress = submitName.slice(0, dotIdx);
            client.workerName = submitName.slice(dotIdx + 1);
          } else {
            client.workerName = submitName;
          }
          client.authorized = true;
          const matched = findMatchingWorker(client);
          if (matched) {
            client.mappedWorkerId = matched.id;
            storage.updateWorker(matched.id, { connected: true, connectedAt: Date.now(), ipAddress: client.ipAddress });
            log(`Auto-authorized on submit: ${client.workerName} -> "${matched.name}"`, "stratum", true);
          } else {
            const newW: Worker = {
              id: client.id,
              name: client.workerName || "unnamed",
              minerType: client.userAgent || "unknown",
              ipAddress: client.ipAddress,
              connected: true,
              connectedAt: Date.now(),
              lastShareAt: 0,
              sharesAccepted: 0,
              sharesRejected: 0,
              hashrate1m: 0,
              hashrate5m: 0,
              hashrate1hr: 0,
              hashrate1d: 0,
              bestDifficulty: 0,
              bestDifficultyShare: "",
              colorIndex: storage.getWorkers().length,
              coin: storage.getConfig().coin,
            };
            storage.addWorker(newW);
            client.mappedWorkerId = newW.id;
            log(`New worker (auto-auth submit): ${client.workerName} (${client.ipAddress})`, "stratum", true);
          }
        }
      }

      const workerSubmit = params?.[0] || client.workerName;
      const jobIdSubmit = params?.[1] || "";
      const extranonce2 = params?.[2] || "";
      const ntime = params?.[3] || "";
      const nonce = params?.[4] || "";
      const versionBits = params?.[5] || "";

      const job = jobTemplates.get(jobIdSubmit);
      let shareDifficulty = client.difficulty;
      let shareHash = "";
      let shareResult: ShareResult | null = null;

      if (job) {
        shareResult = computeShareDifficulty(job, client.extranonce1, extranonce2, ntime, nonce, versionBits);
        shareDifficulty = shareResult.difficulty;
        shareHash = shareResult.hash;
      } else {
        shareHash = createHash("sha256")
          .update(`${jobIdSubmit}${client.extranonce1}${extranonce2}${ntime}${nonce}`)
          .digest("hex");
      }

      const meetsTarget = shareDifficulty >= client.difficulty;

      if (!client.mappedWorkerId) {
        const matched = findMatchingWorker(client);
        if (matched) {
          client.mappedWorkerId = matched.id;
          storage.updateWorker(matched.id, { connected: true, ipAddress: client.ipAddress });
          log(`Late-matched ${client.workerName} to worker "${matched.name}"`, "stratum", true);
        } else if (client.authorized) {
          const newW: Worker = {
            id: client.id,
            name: client.workerName || "unnamed",
            minerType: client.userAgent || "unknown",
            ipAddress: client.ipAddress,
            connected: true,
            connectedAt: Date.now(),
            lastShareAt: 0,
            sharesAccepted: 0,
            sharesRejected: 0,
            hashrate1m: 0,
            hashrate5m: 0,
            hashrate1hr: 0,
            hashrate1d: 0,
            bestDifficulty: 0,
            bestDifficultyShare: "",
            colorIndex: storage.getWorkers().length,
            coin: storage.getConfig().coin,
          };
          storage.addWorker(newW);
          client.mappedWorkerId = newW.id;
          log(`New worker (late-create): ${client.workerName} (${client.ipAddress})`, "stratum", true);
        }
      }

      const workerId = client.mappedWorkerId || client.id;

      sendToClient(client, { id, result: true, error: null });

      client.vardiffShareTimes.push(Date.now());
      adjustVardiff(client);

      if (!meetsTarget) {
        break;
      }

      const share: ShareEntry = {
        id: randomUUID(),
        workerId,
        workerName: client.workerName,
        difficulty: shareDifficulty,
        targetDifficulty: client.difficulty,
        accepted: true,
        timestamp: Date.now(),
        hash: shareHash,
      };
      storage.addShare(share);

      if (client.mappedWorkerId) {
        const worker = storage.getWorker(client.mappedWorkerId);
        if (worker) {
          const updates: Partial<Worker> = {
            lastShareAt: Date.now(),
            sharesAccepted: worker.sharesAccepted + 1,
            hashrate1m: calculateHashrate(client.mappedWorkerId, 60),
            hashrate5m: calculateHashrate(client.mappedWorkerId, 300),
            hashrate1hr: calculateHashrate(client.mappedWorkerId, 3600),
            hashrate1d: calculateHashrate(client.mappedWorkerId, 86400),
          };
          if (shareDifficulty > worker.bestDifficulty) {
            updates.bestDifficulty = shareDifficulty;
            updates.bestDifficultyShare = shareHash;
          }
          storage.updateWorker(client.mappedWorkerId, updates);
        }
      }

      const isRealJob = !!(job && job.isReal && job.blockTemplate);
      const templateStatus = isRealJob ? "REAL" : "FALLBACK";
      log(`Share accepted from ${client.workerName} diff=${shareDifficulty.toLocaleString()} target=${client.difficulty.toLocaleString()} hash=${shareHash.slice(0, 16)}... template=${templateStatus}`, "stratum");

      if (isRealJob && shareResult && shareResult.blockHeaderHex) {
        checkAndSubmitBlock(job!, shareResult, client).catch((err: any) => {
          log(`CRITICAL: checkAndSubmitBlock crashed: ${err.message}`, "stratum");
          log(`  Stack: ${err.stack?.slice(0, 300)}`, "stratum");
          const coinLabel = storage.getConfig().coin;
          const now = new Date();
          const timestamp = now.toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
          const crashInfo = {
            coin: coinLabel,
            height: job!.blockTemplate?.height || 0,
            hash: shareResult.blockHash,
            reward: "UNKNOWN",
            difficulty: shareResult.blockDifficulty.toLocaleString(),
            worker: client.workerName,
            workerIp: client.ipAddress,
            timestamp,
            status: `ERROR - submission crashed: ${err.message}`,
          };
          launchBlockFoundPopup(crashInfo);
          storage.addBlockFound(crashInfo);
        });
      } else if (shareDifficulty >= 1000000000) {
        const coinLabel = storage.getConfig().coin;
        const diffStr = shareDifficulty.toLocaleString();
        log(``, "stratum");
        log(`!!! WASTED BLOCK-LEVEL SHARE !!! diff=${diffStr}`, "stratum");
        log(`  Worker: ${client.workerName} (${client.ipAddress})`, "stratum");
        log(`  This share had enough difficulty to be a BLOCK but was on a FALLBACK template.`, "stratum");
        log(`  The ${coinLabel} node is NOT synced or not running — blocks cannot be submitted!`, "stratum");
        log(`  ACTION REQUIRED: Sync your ${coinLabel} node fully, then restart mining.`, "stratum");
        log(``, "stratum");

        const now = new Date();
        const timestamp = now.toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
        launchBlockFoundPopup({
          coin: coinLabel,
          height: 0,
          hash: shareHash,
          reward: "UNKNOWN",
          difficulty: diffStr,
          worker: client.workerName,
          workerIp: client.ipAddress,
          timestamp,
          status: "WASTED — NODE NOT SYNCED (fallback template, block could not be submitted)",
        });
      }

      break;
    }

    case "mining.suggest_difficulty": {
      const suggestedDiff = params?.[0] || DEFAULT_DIFFICULTY;
      const isNH = client.userAgent.toLowerCase().includes("nicehash") ||
        client.userAgent.toLowerCase().includes("nhmp");
      const suggestFloor = isNH ? NICEHASH_MIN_DIFFICULTY : MINER_MIN_DIFFICULTY;
      let newDiff = Math.max(suggestFloor, Math.floor(suggestedDiff));
      newDiff = Math.min(MAX_DIFFICULTY, newDiff);
      client.difficulty = newDiff;
      client.reportedHashrate = suggestedDiff * 4294967296 / VARDIFF_TARGET_SECONDS;
      sendToClient(client, { id, result: true, error: null });
      sendToClient(client, {
        id: null,
        method: "mining.set_difficulty",
        params: [newDiff],
      });
      log(`Difficulty suggested by ${client.workerName || client.ipAddress}: ${suggestedDiff} -> accepted ${newDiff} (implied hashrate: ${(client.reportedHashrate / 1e12).toFixed(2)} TH/s)`, "stratum", true);
      break;
    }

    case "mining.suggest_target": {
      sendToClient(client, { id, result: true, error: null });
      break;
    }

    case "mining.extranonce.subscribe": {
      sendToClient(client, { id, result: true, error: null });
      break;
    }

    case "mining.multi_version": {
      sendToClient(client, { id, result: true, error: null });
      break;
    }

    case "mining.get_transactions": {
      sendToClient(client, { id, result: [], error: null });
      break;
    }

    default: {
      if (id !== undefined && id !== null) {
        sendToClient(client, { id, result: true, error: null });
      }
      log(`Unknown method from ${client.workerName || client.ipAddress}: ${method}`, "stratum", true);
      break;
    }
  }
}

function formatCoinReward(satoshis: number, coin: string): string {
  if (coin === "XEC") {
    return (satoshis / 100).toFixed(2);
  }
  return (satoshis / 1e8).toFixed(8);
}

function escapeBatString(str: string): string {
  return str
    .replace(/\^/g, "^^")
    .replace(/&/g, "^&")
    .replace(/\|/g, "^|")
    .replace(/</g, "^<")
    .replace(/>/g, "^>")
    .replace(/%/g, "%%")
    .replace(/!/g, "^^!");
}

function scheduleOrphanCheck(blockHash: string, height: number, coin: string, reward: string, delaySec: number): void {
  setTimeout(async () => {
    try {
      const blockCheck = await rpcCall("getblock", [blockHash]);
      if (blockCheck) {
        const confs = blockCheck.confirmations;
        if (confs !== undefined && confs < 0) {
          log(`ORPHAN ALERT: Block ${blockHash.slice(0, 16)}... at height ${height} has been ORPHANED (confirmations=${confs})`, "stratum");
          log(`  This block's ${reward} ${coin} reward is LOST. Another miner found a competing block.`, "stratum");
          storage.updateBlockStatus(blockHash, "ORPHANED (reorg detected)");
        } else if (confs !== undefined && confs >= 0) {
          log(`Block ${blockHash.slice(0, 16)}... at height ${height}: ${confs} confirmation(s) after ${delaySec}s -- still on chain`, "stratum");
        }
      }
    } catch (err: any) {
      log(`Orphan check failed for ${blockHash.slice(0, 16)}... -- ${err.message}`, "stratum");
    }
  }, delaySec * 1000);
}

function launchBlockFoundPopup(blockInfo: {
  coin: string;
  height: number;
  hash: string;
  reward: string;
  difficulty: string;
  worker: string;
  workerIp: string;
  timestamp: string;
  status: string;
}): void {
  try {
    const logsDir = path.resolve(import.meta.dirname, "..", "logs");
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }

    const logLine = `[${blockInfo.timestamp}] ${blockInfo.coin} Height=${blockInfo.height} Hash=${blockInfo.hash} Reward=${blockInfo.reward} ${blockInfo.coin} Worker=${blockInfo.worker} (${blockInfo.workerIp}) Diff=${blockInfo.difficulty} Status=${blockInfo.status}`;
    const logFile = path.join(logsDir, "blocks-found.log");
    fs.appendFileSync(logFile, logLine + "\n", "utf-8");
    log(`Block recorded to ${logFile}`, "stratum");

    const isWindows = process.platform === "win32";
    if (!isWindows) {
      log(`Block popup skipped (not Windows)`, "stratum");
      return;
    }

    const safeCoin = escapeBatString(blockInfo.coin);
    const safeReward = escapeBatString(blockInfo.reward);
    const safeStatus = escapeBatString(blockInfo.status);
    const safeHash = escapeBatString(blockInfo.hash);
    const safeDifficulty = escapeBatString(blockInfo.difficulty);
    const safeWorker = escapeBatString(blockInfo.worker);
    const safeWorkerIp = escapeBatString(blockInfo.workerIp);
    const safeTimestamp = escapeBatString(blockInfo.timestamp);

    const batFileName = `BLOCK-FOUND-${blockInfo.coin}-${blockInfo.height}.bat`;
    const batPath = path.join(logsDir, batFileName);

    const batLines = [
      `@echo off`,
      `title BLOCK FOUND! - ${safeCoin} Height ${blockInfo.height}`,
      `color 0E`,
      `mode con cols=72 lines=40`,
      `echo.`,
      `echo  ====================================================================`,
      `echo  !                                                                  !`,
      `echo  !   ######  ##       #####   #####  ##  ##                         !`,
      `echo  !   ##   ## ##      ##   ## ##   ## ## ##                           !`,
      `echo  !   ######  ##      ##   ## ##      ####                            !`,
      `echo  !   ##   ## ##      ##   ## ##   ## ## ##                           !`,
      `echo  !   ######  ######   #####   #####  ##  ##                         !`,
      `echo  !                                                                  !`,
      `echo  !   ######  #####  ##   ## ##   ## ######  ##                      !`,
      `echo  !   ##     ##   ## ##   ## ###  ## ##   ## ##                      !`,
      `echo  !   ####   ##   ## ##   ## ## # ## ##   ## ##                      !`,
      `echo  !   ##     ##   ## ##   ## ##  ### ##   ##                         !`,
      `echo  !   ##      #####   #####  ##   ## ######  ##                     !`,
      `echo  !                                                                  !`,
      `echo  ====================================================================`,
      `echo.`,
      `echo   Coin:        ${safeCoin}`,
      `echo   Height:      ${blockInfo.height}`,
      `echo   Reward:      ${safeReward} ${safeCoin}`,
      `echo   Status:      ${safeStatus}`,
      `echo.`,
      `echo   Block Hash:`,
      `echo   ${safeHash}`,
      `echo.`,
      `echo   Difficulty:  ${safeDifficulty}`,
      `echo   Worker:      ${safeWorker}`,
      `echo   Worker IP:   ${safeWorkerIp}`,
      `echo   Time:        ${safeTimestamp}`,
      `echo.`,
      `echo  ====================================================================`,
      `echo   100%% of this block reward goes to YOUR wallet!`,
      `echo  ====================================================================`,
      `echo.`,
      `echo  Press any key to close this window...`,
      `pause >nul`,
    ];

    const batContent = batLines.join("\r\n") + "\r\n";
    fs.writeFileSync(batPath, batContent, "ascii");

    exec(`cmd.exe /c start "BLOCK FOUND!" "${batPath}"`, (err) => {
      if (err) {
        log(`Block popup launch failed: ${err.message}`, "stratum");
      }
    });

    log(`Block popup launched: ${batFileName}`, "stratum");
  } catch (err: any) {
    log(`Block popup error: ${err.message}`, "stratum");
  }
}

async function checkAndSubmitBlock(
  job: JobTemplate,
  result: ShareResult,
  client: StratumClient,
): Promise<void> {
  if (!job.blockTemplate) return;

  const target = job.blockTemplate.target;
  const targetBig = BigInt("0x" + target);
  const targetDiff = targetBig === 0n ? Number.MAX_SAFE_INTEGER : Number(DIFF1_TARGET / targetBig);

  const blockHashBig = BigInt("0x" + result.blockHash);

  const meetsNetworkTarget = blockHashBig <= targetBig;

  if (result.blockDifficulty >= 1000000000 || result.blockDifficulty >= targetDiff * 0.5) {
    log(`High-diff share check: shareDiff=${result.blockDifficulty.toLocaleString()} networkDiff=${targetDiff.toLocaleString()} hash=${result.blockHash.slice(0, 24)}... target=${target.slice(0, 24)}... meetsTarget=${meetsNetworkTarget}`, "stratum", true);
  }

  if (!meetsNetworkTarget) {
    if (result.blockDifficulty >= targetDiff * 0.01) {
      log(`Near-miss share: diff=${result.blockDifficulty.toLocaleString()} need=${targetDiff.toLocaleString()} (${((result.blockDifficulty / targetDiff) * 100).toFixed(2)}% of target)`, "stratum", true);
    }
    return;
  }

  const submitStartTime = Date.now();
  const coinLabel = storage.getConfig().coin;
  const rewardStr = formatCoinReward(job.blockTemplate.coinbasevalue, coinLabel);

  log(`*** BLOCK FOUND *** hash=${result.blockHash} diff=${result.blockDifficulty.toLocaleString()} height=${job.blockTemplate.height} -- FAST-PATH SUBMIT`, "stratum");

  try {
    const submitCoin = coinLabel;
    const noSegwitSubmit = ["BSV", "BCH", "XEC", "BCH2"];
    const hasWitness = noSegwitSubmit.includes(submitCoin) ? false : job.blockTemplate.transactions.some(tx => tx.hash && tx.hash !== tx.txid);
    const coinbaseForBlock = hasWitness ? addWitnessToCoinbase(result.coinbaseTx) : result.coinbaseTx;

    const CTOR_COINS = ["BCH", "XEC", "BCH2"];
    let templateTxs = job.blockTemplate.transactions;
    if (CTOR_COINS.includes(submitCoin) && templateTxs.length > 1) {
      templateTxs = [...templateTxs].sort((a, b) => {
        const aBuf = Buffer.from(a.txid, "hex");
        const bBuf = Buffer.from(b.txid, "hex");
        return Buffer.compare(aBuf, bBuf);
      });
    }

    const allTxs = [coinbaseForBlock];
    for (const tx of templateTxs) {
      allTxs.push(tx.data);
    }
    const txCount = encodeVarInt(allTxs.length);
    const txData = txCount + allTxs.join("");

    const COINS_WITH_BLOCK_SIG = ["PPC"];
    const blockSig = COINS_WITH_BLOCK_SIG.includes(submitCoin) ? "00" : "";
    const blockHex = result.blockHeaderHex + txData + blockSig;

    const buildTime = Date.now() - submitStartTime;
    log(`  Block built in ${buildTime}ms (${(blockHex.length / 2).toLocaleString()} bytes) -- submitting NOW`, "stratum");

    const submitResult = await submitBlock(blockHex);
    const submitTime = Date.now() - submitStartTime;

    const now = new Date();
    const timestamp = now.toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });

    log(``, "stratum");
    log(`!!! BLOCK FOUND !!! hash=${result.blockHash}`, "stratum");
    log(`  Height: ${job.blockTemplate.height}`, "stratum");
    log(`  Block difficulty: ${result.blockDifficulty.toLocaleString()}`, "stratum");
    log(`  Network target: ${target.slice(0, 24)}...`, "stratum");
    log(`  Worker: ${client.workerName}`, "stratum");
    log(`  Reward: ${rewardStr} ${coinLabel}`, "stratum");
    log(`  Submit latency: ${submitTime}ms (build=${buildTime}ms rpc=${submitTime - buildTime}ms)`, "stratum");
    log(`  hasWitness=${hasWitness} CTOR=${CTOR_COINS.includes(submitCoin)} txCount=${job.blockTemplate.transactions.length + 1}`, "stratum");
    log(``, "stratum");

    const hdrHex = result.blockHeaderHex;
    log(`  Coinbase TX (${coinbaseForBlock.length / 2} bytes): ${coinbaseForBlock.slice(0, 40)}...${coinbaseForBlock.slice(-40)}`, "stratum");
    log(`  Header: version=${hdrHex.slice(0, 8)} prevHash=${hdrHex.slice(8, 24)}... merkle=${hdrHex.slice(72, 88)}... ntime=${hdrHex.slice(136, 144)} nbits=${hdrHex.slice(144, 152)} nonce=${hdrHex.slice(152, 160)}`, "stratum");

    const verifyHash = sha256d(Buffer.from(result.blockHeaderHex, "hex"));
    const verifyHashHex = reverseBytes(verifyHash.toString("hex"));
    log(`  Verify: re-hash=${verifyHashHex.slice(0, 24)}... match=${verifyHashHex === result.blockHash}`, "stratum");

    if (submitResult === null) {
      log(`BLOCK SUBMITTED SUCCESSFULLY in ${submitTime}ms! Height=${job.blockTemplate.height} Reward=${rewardStr} ${coinLabel}`, "stratum");
      log(`  Hash: ${result.blockHash}`, "stratum");
      log(`  Submitted by: ${client.workerName} (${client.ipAddress})`, "stratum");

      const acceptedInfo = {
        coin: coinLabel,
        height: job.blockTemplate.height,
        hash: result.blockHash,
        reward: rewardStr,
        difficulty: result.blockDifficulty.toLocaleString(),
        worker: client.workerName,
        workerIp: client.ipAddress,
        timestamp,
        status: "ACCEPTED BY NETWORK",
      };
      launchBlockFoundPopup(acceptedInfo);
      storage.addBlockFound(acceptedInfo);

      sendBlockNotification(client, acceptedInfo);

      scheduleOrphanCheck(result.blockHash, job.blockTemplate.height, coinLabel, rewardStr, 30);
      scheduleOrphanCheck(result.blockHash, job.blockTemplate.height, coinLabel, rewardStr, 120);

      postSubmitVerification(result.blockHash, job.blockTemplate.height, coinLabel).catch(() => {});
    } else {
      log(`Block submission result: ${submitResult} (${submitTime}ms)`, "stratum");

      let blockVerified = false;
      try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        const blockCheck = await rpcCall("getblock", [result.blockHash]);
        if (blockCheck && blockCheck.confirmations !== undefined) {
          blockVerified = true;
          log(`Block verification: CONFIRMED on chain with ${blockCheck.confirmations} confirmations`, "stratum");
        }
      } catch {
        log(`Block verification: could not verify block ${result.blockHash} on chain`, "stratum");
      }

      if (blockVerified) {
        log(`Block ACCEPTED despite submitblock message: "${submitResult}"`, "stratum");
        const acceptedInfo = {
          coin: coinLabel,
          height: job.blockTemplate.height,
          hash: result.blockHash,
          reward: rewardStr,
          difficulty: result.blockDifficulty.toLocaleString(),
          worker: client.workerName,
          workerIp: client.ipAddress,
          timestamp,
          status: "ACCEPTED BY NETWORK",
        };
        launchBlockFoundPopup(acceptedInfo);
        storage.addBlockFound(acceptedInfo);
        sendBlockNotification(client, acceptedInfo);
        return;
      }

      let popupStatus = "";
      if (submitResult.includes("duplicate") || submitResult.includes("stale")) {
        log(`Block was valid but already found by someone else`, "stratum");
        popupStatus = "STALE / DUPLICATE (someone else found it first)";
      } else if (submitResult.includes("inconclusive")) {
        log(`Block submission inconclusive -- may still propagate`, "stratum");
        popupStatus = "INCONCLUSIVE (may still propagate)";
      } else if (submitResult.includes("bad-diffbits")) {
        log(`Block rejected: bad-diffbits`, "stratum");
        log(`  Job nBits: ${job.nbits} | blockHeaderHex version (LE): ${result.blockHeaderHex.slice(0, 8)}`, "stratum");
        popupStatus = "REJECTED (bad-diffbits)";
      } else {
        log(`Block rejected: ${submitResult}`, "stratum");
        log(`  blockHash: ${result.blockHash}`, "stratum");
        popupStatus = `REJECTED (${submitResult})`;
      }

      if (popupStatus) {
        const rejectedInfo = {
          coin: coinLabel,
          height: job.blockTemplate.height,
          hash: result.blockHash,
          reward: rewardStr,
          difficulty: result.blockDifficulty.toLocaleString(),
          worker: client.workerName,
          workerIp: client.ipAddress,
          timestamp,
          status: popupStatus,
        };
        launchBlockFoundPopup(rejectedInfo);
        storage.addBlockFound(rejectedInfo);
        sendBlockNotification(client, rejectedInfo);
      }
    }
  } catch (err: any) {
    log(`CRITICAL: Block submission error: ${err.message}`, "stratum");
    log(`  Stack: ${err.stack?.slice(0, 300)}`, "stratum");
    const now = new Date();
    const timestamp = now.toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
    const errorInfo = {
      coin: coinLabel,
      height: job.blockTemplate?.height || 0,
      hash: result.blockHash,
      reward: rewardStr,
      difficulty: result.blockDifficulty.toLocaleString(),
      worker: client.workerName,
      workerIp: client.ipAddress,
      timestamp,
      status: `ERROR during submission: ${err.message}`,
    };
    launchBlockFoundPopup(errorInfo);
    storage.addBlockFound(errorInfo);
  }
}

function sendBlockNotification(client: StratumClient, blockInfo: any): void {
  const baseCfg = storage.getConfig().email;
  if (baseCfg && baseCfg.enabled && baseCfg.smtpHost) {
    const emailTo = client.notifyEmail || baseCfg.to;
    const emailCfg = { ...baseCfg, to: emailTo };
    log(`Sending block-found email to ${emailTo}...`, "stratum");
    sendBlockFoundEmail(emailCfg, blockInfo).catch((err: any) => {
      log(`Email send FAILED: ${err.message}`, "stratum");
    });
  } else if (client.notifyEmail) {
    log(`Cannot send email to ${client.notifyEmail}: no SMTP settings configured in config.json`, "stratum");
  }
}

async function postSubmitVerification(blockHash: string, height: number, coin: string): Promise<void> {
  try {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const blockCheck = await rpcCall("getblock", [blockHash]);
    if (blockCheck) {
      const confs = blockCheck.confirmations;
      if (confs !== undefined && confs >= 0) {
        log(`  Post-submit verification: CONFIRMED on chain, ${confs} confirmation(s)`, "stratum");
      } else if (confs !== undefined && confs < 0) {
        log(`  Post-submit verification: Block ORPHANED (confirmations=${confs})`, "stratum");
        storage.updateBlockStatus(blockHash, "ORPHANED (reorg detected)");
      }
      if (blockCheck.tx && blockCheck.tx.length > 0) {
        log(`  Coinbase txid: ${blockCheck.tx[0]}`, "stratum");
      }
    }
    const chainInfo = await rpcCall("getblockchaininfo");
    if (chainInfo) {
      log(`  Chain: height=${chainInfo.blocks} headers=${chainInfo.headers} peers=${chainInfo.connections || "?"}`, "stratum");
      if (chainInfo.blocks < chainInfo.headers) {
        log(`  WARNING: Node still syncing (${chainInfo.headers - chainInfo.blocks} blocks behind)`, "stratum");
      }
      if (chainInfo.initialblockdownload) {
        log(`  WARNING: Node in Initial Block Download -- blocks may not propagate`, "stratum");
      }
      const bestHash = await rpcCall("getbestblockhash");
      if (bestHash === blockHash) {
        log(`  CONFIRMED: Our block IS the best chain tip!`, "stratum");
      }
    }
    const peerInfo = await rpcCall("getpeerinfo");
    if (peerInfo && Array.isArray(peerInfo)) {
      const outbound = peerInfo.filter((p: any) => !p.inbound);
      log(`  Peers: ${peerInfo.length} total, ${outbound.length} outbound`, "stratum");
      if (outbound.length === 0) {
        log(`  CRITICAL: No outbound peers -- block cannot propagate to network!`, "stratum");
      }
    }
  } catch (err: any) {
    log(`  Post-submit verification error: ${err.message}`, "stratum");
  }
}

function sendToClient(client: StratumClient, data: any): void {
  try {
    if (client.socket.writable) {
      const json = JSON.stringify(data);
      log(`>> ${client.workerName || client.ipAddress}: ${json.slice(0, 200)}`, "stratum");
      client.socket.write(json + "\n");
    }
  } catch {
  }
}

function sendJob(client: StratumClient, cleanJobs: boolean = true): void {
  const template = getBlockTemplate();
  const config = storage.getConfig();

  if (template && config.walletAddress && isTemplateAvailable()) {
    sendRealJob(client, template, config.walletAddress, cleanJobs);
  } else {
    sendFallbackJob(client, cleanJobs);
  }
}

function sendRealJob(client: StratumClient, template: BlockTemplate, walletAddress: string, cleanJobs: boolean): void {
  const jobId = generateJobId();
  currentJobId = jobId;

  const { coinb1, coinb2 } = buildCoinbaseTransaction(template, walletAddress, 4, EXTRANONCE2_SIZE);

  const coinType2 = storage.getConfig().coin;
  const auxF = template.coinbaseaux?.flags || "";
  if (auxF) {
    log(`  Coinbase includes coinbaseaux.flags: "${auxF}" (${auxF.length / 2} bytes)`, "stratum", true);
  }
  log(`  Coinbase: txVer=2 scriptSig=[height(${template.height})+auxFlags(${auxF.length / 2}b)+tag] out=1 addr=${walletAddress.slice(0, 16)}...`, "stratum", true);

  const merkleBranches = computeMerkleBranches(template);

  const prevHashInternal = reverseBytes(template.previousblockhash);
  const prevHashStratum = swapEndian32(prevHashInternal);
  let versionNum = template.version;
  const coinType = storage.getConfig().coin;
  if (coinType === "DGB") {
    const DGB_ALGO_MASK = 0xF00;
    const DGB_VERSION_SHA256D = (2 << 8);
    const currentAlgo = versionNum & DGB_ALGO_MASK;
    if (currentAlgo !== DGB_VERSION_SHA256D) {
      versionNum = (versionNum & ~DGB_ALGO_MASK) | DGB_VERSION_SHA256D;
    }
  }
  const version = versionNum.toString(16).padStart(8, "0");
  const ntime = template.curtime.toString(16).padStart(8, "0");
  const nbits = template.bits;

  const job: JobTemplate = {
    jobId,
    version,
    prevHash: template.previousblockhash,
    prevHashStratum: prevHashInternal,
    coinb1,
    coinb2,
    merkleBranches,
    nbits,
    ntime,
    isReal: true,
    blockTemplate: template,
    coinbaseTxPrefix: coinb1,
    coinbaseTxSuffix: coinb2,
  };
  jobTemplates.set(jobId, job);

  if (jobTemplates.size > 100) {
    const keys = Array.from(jobTemplates.keys());
    for (let i = 0; i < keys.length - 100; i++) {
      jobTemplates.delete(keys[i]);
    }
  }

  if (cleanJobs) {
    const coinType = storage.getConfig().coin;
    const algoBits = parseInt(version, 16) & 0xF00;
    log(`Job ${jobId} → ${client.workerName || client.ipAddress}: version=${version} (algo_bits=0x${algoBits.toString(16)}) nbits=${nbits} height=${template.height} coin=${coinType}`, "stratum");
  }

  const notification = {
    id: null,
    method: "mining.notify",
    params: [
      jobId,
      prevHashStratum,
      coinb1,
      coinb2,
      merkleBranches,
      version,
      nbits,
      ntime,
      cleanJobs,
    ],
  };
  sendToClient(client, notification);
}

function sendFallbackJob(client: StratumClient, cleanJobs: boolean): void {
  const jobId = generateJobId();
  currentJobId = jobId;

  const rawPrevHash = createHash("sha256").update(Date.now().toString()).digest("hex").slice(0, 64);
  const prevHashInternal = reverseBytes(rawPrevHash);
  const prevHashStratum = swapEndian32(prevHashInternal);

  const ntime = Math.floor(Date.now() / 1000).toString(16).padStart(8, "0");
  const version = "20000000";
  const nbits = "1d00ffff";

  const coinb1Prefix = "01000000010000000000000000000000000000000000000000000000000000000000000000ffffffff20" +
    createHash("sha256").update(`cb1-${jobId}`).digest("hex").slice(0, 24);
  const coinb2Suffix = "ffffffff01" +
    "0000000000000000" +
    "19" + "76a914" +
    createHash("sha256").update("solopool").digest("hex").slice(0, 40) +
    "88ac" + "00000000";

  const job: JobTemplate = {
    jobId, version, prevHash: rawPrevHash,
    prevHashStratum: prevHashInternal,
    coinb1: coinb1Prefix, coinb2: coinb2Suffix,
    merkleBranches: [], nbits, ntime,
    isReal: false,
    blockTemplate: null,
    coinbaseTxPrefix: coinb1Prefix,
    coinbaseTxSuffix: coinb2Suffix,
  };
  jobTemplates.set(jobId, job);

  if (jobTemplates.size > 50) {
    const keys = Array.from(jobTemplates.keys());
    for (let i = 0; i < keys.length - 50; i++) {
      jobTemplates.delete(keys[i]);
    }
  }

  const notification = {
    id: null,
    method: "mining.notify",
    params: [
      jobId,
      prevHashStratum,
      coinb1Prefix,
      coinb2Suffix,
      [],
      version,
      nbits,
      ntime,
      cleanJobs,
    ],
  };
  sendToClient(client, notification);
}

function detectMinerType(workerName: string, userAgent: string = ""): string {
  const lowerName = workerName.toLowerCase();
  const lowerAgent = userAgent.toLowerCase();
  const combined = `${lowerName} ${lowerAgent}`;

  if (combined.includes("avalon")) return "Avalon";
  if (combined.includes("canaan")) return "Avalon";
  if (combined.includes("magic")) return "MagicMiner";
  if (combined.includes("lucky")) return "Luckyminer";
  if (combined.includes("nerd")) return "Nerdminer";
  if (combined.includes("bitaxe")) return "Bitaxe";
  if (combined.includes("antminer")) return "Antminer";
  if (combined.includes("whatsminer")) return "WhatsMiner";
  if (combined.includes("cgminer")) return "CGMiner";
  if (combined.includes("bfgminer")) return "BFGMiner";
  if (combined.includes("bmminer")) return "Antminer";
  if (combined.includes("btccom")) return "BTCcom";
  if (combined.includes("nicehash")) return "NiceHash";
  return "Unknown";
}

function calculateHashrate(workerId: string, windowSeconds: number): number {
  const now = Date.now();
  const cutoff = now - windowSeconds * 1000;
  const shares = storage.getRecentShares(10000).filter(
    (s) => s.workerId === workerId && s.accepted && s.timestamp >= cutoff
  );
  if (shares.length === 0) return 0;
  const totalWork = shares.reduce((sum, s) => sum + s.targetDifficulty, 0);
  const workerObj = storage.getWorker(workerId);
  const connectedAt = workerObj?.connectedAt || cutoff;
  const workerUptime = (now - connectedAt) / 1000;
  const elapsed = Math.min(windowSeconds, Math.max(workerUptime, 1));
  return (totalWork * 4294967296) / elapsed;
}

function broadcastJob(cleanJobs: boolean = false): void {
  for (const client of clients.values()) {
    if (client.authorized && client.subscribed) {
      sendJob(client, cleanJobs);
    }
  }
}

let lastLoggedTemplateState = "";
let fallbackWarningCount = 0;

function setupUpnpMapping(port: number): void {
  const coinLabel = storage.getConfig().coin || "COIN";
  const description = `${coinLabel} HammerForge Stratum`;
  const UPNP_TTL = 7200;
  const UPNP_REFRESH = 3600000;

  const doMapping = () => {
    import("nat-upnp-2").then((natUpnp: any) => {
      const createClient = natUpnp.createClient || natUpnp.default?.createClient;
      if (!createClient) {
        log(`UPnP: Module loaded but createClient not found. Manual port forwarding may be needed.`, "stratum");
        return;
      }
      const upnpClient = createClient({ timeout: 10000 });

      upnpClient.portMapping({
        public: port,
        private: port,
        protocol: "TCP",
        description,
        ttl: UPNP_TTL,
      }, (err: any) => {
        if (err) {
          log(`UPnP: Could not map port ${port} (${coinLabel}) — ${err.message}. Manual port forwarding may be needed.`, "stratum");
          try { upnpClient.close(); } catch (_e) {}
          return;
        }
        upnpMappedPort = port;
        log(`UPnP: Port ${port} (${coinLabel}) mapped successfully for external access`, "stratum");

        upnpClient.externalIp((ipErr: any, ip: string) => {
          if (!ipErr && ip) {
            log(`UPnP: External/public IP is ${ip} — NiceHash pool host: ${ip}:${port}`, "stratum");
          }
          try { upnpClient.close(); } catch (_e) {}
        });
      });
    }).catch((err: any) => {
      log(`UPnP: Not available — ${err.message}. Manual port forwarding may be needed.`, "stratum");
    });
  };

  doMapping();
  upnpRefreshInterval = setInterval(doMapping, UPNP_REFRESH);
}

function cleanupUpnpMapping(): void {
  if (upnpRefreshInterval) {
    clearInterval(upnpRefreshInterval);
    upnpRefreshInterval = null;
  }

  if (upnpMappedPort) {
    const port = upnpMappedPort;
    const coinLabel = storage.getConfig().coin || "COIN";
    upnpMappedPort = null;

    import("nat-upnp-2").then((natUpnp: any) => {
      const createClient = natUpnp.createClient || natUpnp.default?.createClient;
      if (!createClient) return;
      const upnpClient = createClient({ timeout: 5000 });

      upnpClient.portUnmapping({
        public: port,
        protocol: "TCP",
      }, (err: any) => {
        if (err) {
          log(`UPnP: Could not unmap port ${port} — ${err.message}`, "stratum");
        } else {
          log(`UPnP: Port ${port} (${coinLabel}) unmapped`, "stratum");
        }
        upnpClient.close();
      });
    }).catch((err: any) => {
      log(`UPnP: Cleanup error — ${err.message}`, "stratum");
    });
  }
}

export function startStratumServer(port: number): net.Server | null {
  if (server) {
    log("Stratum server already running", "stratum");
    return server;
  }

  setOnNewBlock(() => {
    log("Broadcasting new block template to all miners (clean_jobs=true)", "stratum");
    broadcastJob(true);
  });

  const cfg = storage.getConfig();
  if (cfg.walletAddress) {
    const localResult = addressToScriptPubKey(cfg.walletAddress);
    if (!localResult) {
      log(`Wallet address "${cfg.walletAddress}" not decoded locally -- trying RPC fallback...`, "stratum");
      resolveAddressViaRPC(cfg.walletAddress).then(spk => {
        if (spk) {
          log(`RPC fallback SUCCESS: wallet address resolved for ${cfg.coin}`, "stratum");
        } else {
          log(`CRITICAL: wallet address "${cfg.walletAddress}" could NOT be decoded by local decoder OR RPC!`, "stratum");
          log(`  Mining will continue but block rewards will be UNSPENDABLE!`, "stratum");
          log(`  Check the wallet address format and make sure the ${cfg.coin} node is running.`, "stratum");
        }
      });
    } else {
      log(`Wallet address verified: ${cfg.walletAddress.slice(0, 16)}... (${localResult.length / 2} byte scriptPubKey)`, "stratum");
    }
  }

  const handleConnection = (socket: net.Socket) => {
      const clientId = randomUUID();
      const client: StratumClient = {
        id: clientId,
        socket,
        workerName: "",
        walletAddress: "",
        authorized: false,
        subscribed: false,
        difficulty: DEFAULT_DIFFICULTY,
        ipAddress: socket.remoteAddress?.replace("::ffff:", "") || "unknown",
        buffer: "",
        userAgent: "",
        extranonce1: generateExtranonce1(),
        versionMask: "1fffe000",
        mappedWorkerId: "",
        notifyEmail: "",
        vardiffShareTimes: [],
        vardiffLastAdjust: Date.now(),
        reportedHashrate: 0,
      };
      clients.set(clientId, client);

      log(`New connection from ${client.ipAddress}`, "stratum");

      socket.setKeepAlive(true, 30000);
      socket.setTimeout(600000);

      socket.on("timeout", () => {
        log(`Timeout: ${client.workerName || client.ipAddress}`, "stratum");
        socket.destroy();
      });

      socket.on("data", (data) => {
        const raw = data.toString();
        client.buffer += raw;

        if (client.buffer.length > 65536) {
          log(`Buffer overflow from ${client.ipAddress}, disconnecting`, "stratum");
          socket.destroy();
          return;
        }

        const lines = client.buffer.split("\n");
        client.buffer = lines.pop() || "";

        for (const rawLine of lines) {
          const line = rawLine.replace(/\r/g, "").trim();
          if (line) {
            try {
              const message = JSON.parse(line);
              log(`<< ${client.workerName || client.ipAddress}: ${JSON.stringify(message).slice(0, 200)}`, "stratum");
              handleStratumMessage(client, message);
            } catch (err: any) {
              if (err instanceof SyntaxError) {
                if (line.startsWith("{") || line.startsWith("[")) {
                  log(`<< ${client.workerName || client.ipAddress} JSON PARSE ERROR: ${line.slice(0, 200)}`, "stratum");
                } else if (!client.workerName && line.includes("HTTP/")) {
                  socket.destroy();
                  return;
                }
              } else {
                log(`ERROR handling message from ${client.workerName || client.ipAddress}: ${err.message}`, "stratum");
                log(`  Stack: ${err.stack?.split('\n').slice(0, 3).join(' | ')}`, "stratum");
              }
            }
          }
        }
      });

      socket.on("close", () => {
        log(`Disconnected: ${client.workerName || client.ipAddress}`, "stratum");
        if (client.mappedWorkerId) {
          let anotherClientHasWorker = false;
          for (const c of clients.values()) {
            if (c.id !== clientId && c.mappedWorkerId === client.mappedWorkerId && c.authorized) {
              anotherClientHasWorker = true;
              break;
            }
          }
          if (!anotherClientHasWorker) {
            storage.updateWorker(client.mappedWorkerId, { connected: false });
          }
        }
        clients.delete(clientId);
      });

      socket.on("error", (err) => {
        log(`Socket error from ${client.ipAddress}: ${err.message}`, "stratum");
      });
  };

  function startStratumServer(listenPort: number, isRetry: boolean = false): void {
    server = net.createServer(handleConnection);

    server.listen(listenPort, "0.0.0.0", () => {
      const coinLabel = storage.getConfig().coin;
      const coinDesc = coinLabel === "DGB" ? "DGB SHA-256 Solo Mining" : `${coinLabel} Solo Mining`;
      log(`${coinDesc} — Stratum server listening on port ${port}`, "stratum");
      const emailCfg = storage.getConfig().email;
      if (emailCfg && emailCfg.enabled && emailCfg.smtpHost) {
        log(`Email notifications: ON (to: ${emailCfg.to}, via ${emailCfg.smtpHost}:${emailCfg.smtpPort})`, "stratum");
      } else {
        log(`Email notifications: OFF (not configured in config.json)`, "stratum");
      }
      storage.setStratumStatus({
        running: true,
        port,
        connections: 0,
        startedAt: Date.now(),
      });
      setupUpnpMapping(port);
    });

    server.on("error", (err: any) => {
      if (err.code === "EADDRINUSE") {
        log(`Port ${port} is in use — attempting to kill old process and retry...`, "stratum");

        if (process.platform === "win32") {
          exec(`for /f "tokens=5" %a in ('netstat -aon ^| findstr ":${port}" ^| findstr "LISTENING"') do taskkill /F /PID %a`, { shell: "cmd.exe" }, (killErr) => {
            if (killErr) {
              log(`Could not kill process on port ${port}: ${killErr.message}. Retrying bind in 3s...`, "stratum");
            } else {
              log(`Killed old process on port ${port}, retrying...`, "stratum");
            }
            setTimeout(() => {
              startStratumServer(port, true);
            }, 3000);
          });
        } else {
          log(`Cannot start stratum on port ${port}: ${err.message}`, "stratum");
          log(`ACTION REQUIRED: Kill the process using port ${port} and restart.`, "stratum");
          storage.setStratumStatus({ running: false, port, connections: 0, startedAt: 0 });
        }
      } else if (err.code === "EACCES") {
        log(`Cannot start stratum on port ${port}: ${err.message}`, "stratum");
        storage.setStratumStatus({ running: false, port, connections: 0, startedAt: 0 });
      }
    });
  }

  try {
    startStratumServer(port);

    setInterval(() => {
      const state = isTemplateAvailable() ? "REAL" : "FALLBACK";
      const coinLabel = storage.getConfig().coin;
      if (state !== lastLoggedTemplateState) {
        if (state === "REAL") {
          log(`Switched to REAL block templates from ${coinLabel} node — blocks can be found!`, "stratum");
          fallbackWarningCount = 0;
        } else {
          const rpcPort = storage.getConfig().rpcPort;
          log(`WARNING: Using FALLBACK templates — ${coinLabel} node not available on RPC port ${rpcPort}, blocks cannot be submitted. Is the node running and synced?`, "stratum");
          fallbackWarningCount = 0;
        }
        lastLoggedTemplateState = state;
      } else if (state === "FALLBACK" && clients.size > 0) {
        fallbackWarningCount++;
        if (fallbackWarningCount % 2 === 0) {
          const rpcPort = storage.getConfig().rpcPort;
          log(`*** WARNING: ${coinLabel} node STILL not available (RPC port ${rpcPort}). Miners are hashing on FALLBACK templates — blocks CANNOT be found! Sync your node! ***`, "stratum");
        }
      }
      broadcastJob(false);
    }, 30000);

    setInterval(() => {
      for (const client of clients.values()) {
        if (client.authorized) {
          adjustVardiff(client);
        }
      }
    }, 10000);

    setInterval(() => {
      const stats = storage.getNetworkStats();
      storage.addHashrateSnapshot({
        timestamp: Date.now(),
        hashrate: stats.totalHashrate,
        workers: stats.connectedWorkers,
        accepted: stats.totalAccepted,
        rejected: stats.totalRejected,
        bestShare: stats.bestShare,
      });
    }, 30000);

    return server;
  } catch (err: any) {
    log(`Failed to start stratum server: ${err.message}`, "stratum");
    return null;
  }
}

export function stopStratumServer(): void {
  if (server) {
    cleanupUpnpMapping();
    for (const client of clients.values()) {
      client.socket.destroy();
    }
    clients.clear();
    server.close();
    server = null;
    storage.setStratumStatus({
      running: false,
      port: storage.getStratumStatus().port,
      connections: 0,
      startedAt: 0,
    });
    log("Stratum server stopped", "stratum");
  }
}

export function getConnectedClients(): number {
  return clients.size;
}
