import type { Worker, ShareEntry, NetworkStats, StratumStatus, DashboardData, MiningConfig, HashrateSnapshot, BlockFoundEntry, MonitorData, BestShareEntry, ActiveNode, CoinType } from "@shared/schema";
import { randomUUID } from "crypto";
import * as fs from "fs";
import * as path from "path";

const WORKER_COLORS = [
  "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4",
  "#FFEAA7", "#DDA0DD", "#98D8C8", "#F7DC6F",
  "#BB8FCE", "#85C1E9", "#82E0AA", "#F8C471",
  "#D2B4DE", "#AED6F1", "#A3E4D7", "#FAD7A0",
];

const MAX_SHARES_LOG = 10000;
const MAX_HASHRATE_HISTORY = 2880;
const MAX_BLOCKS_FOUND = 1000;

export interface IStorage {
  getConfig(): MiningConfig;
  setConfig(config: MiningConfig): void;
  addWorker(worker: Worker): void;
  removeWorker(workerId: string): void;
  getWorker(workerId: string): Worker | undefined;
  getWorkers(): Worker[];
  updateWorker(workerId: string, updates: Partial<Worker>): void;
  addShare(share: ShareEntry): void;
  getRecentShares(limit?: number): ShareEntry[];
  getNetworkStats(): NetworkStats;
  updateNetworkStats(updates: Partial<NetworkStats>): void;
  getStratumStatus(): StratumStatus;
  setStratumStatus(status: StratumStatus): void;
  getDashboardData(): DashboardData;
  getNextColorIndex(): number;
  addHashrateSnapshot(snapshot: HashrateSnapshot): void;
  getHashrateHistory(): HashrateSnapshot[];
  recordBestShare(difficulty: number): void;
  getBestShareHistory(): BestShareEntry[];
  addBlockFound(block: BlockFoundEntry): void;
  updateBlockStatus(hash: string, newStatus: string): void;
  clearBlocksFound(): void;
  getBlocksFound(): BlockFoundEntry[];
  getMonitorData(): MonitorData;
}

export class MemStorage implements IStorage {
  private config: MiningConfig;
  private workers: Map<string, Worker>;
  private shares: ShareEntry[];
  private networkStats: NetworkStats;
  private stratumStatus: StratumStatus;
  private colorCounter: number;
  private startTime: number;
  private hashrateHistory: HashrateSnapshot[];
  private bestShareHistory: BestShareEntry[];
  private currentIntervalBest: number;
  private currentIntervalStart: number;
  private blocksFound: BlockFoundEntry[];

  constructor() {
    this.startTime = Date.now();
    this.colorCounter = 0;
    this.workers = new Map();
    this.shares = [];
    this.hashrateHistory = [];
    this.bestShareHistory = [];
    this.currentIntervalBest = 0;
    this.currentIntervalStart = Date.now();
    this.blocksFound = this.loadBlocksFromDisk();
    this.config = {
      walletAddress: "",
      stratumPort: 3333,
      rpcHost: "127.0.0.1",
      rpcPort: 8232,
      rpcUser: "bc2rpc",
      rpcPassword: "bc2rpcpassword",
      coin: "BC2",
    };
    this.networkStats = {
      blockHeight: 0,
      networkDifficulty: 0,
      networkHashrate: 0,
      coinPrice: 0,
      bestShare: 0,
      totalAccepted: 0,
      totalRejected: 0,
      uptime: 0,
      connectedWorkers: 0,
      totalHashrate: 0,
    };
    this.stratumStatus = {
      running: false,
      port: 3333,
      connections: 0,
      startedAt: 0,
    };
  }

  getConfig(): MiningConfig {
    return { ...this.config };
  }

  setConfig(config: MiningConfig): void {
    this.config = { ...config };
  }

  addWorker(worker: Worker): void {
    this.workers.set(worker.id, worker);
    this.updateAggregates();
  }

  removeWorker(workerId: string): void {
    this.workers.delete(workerId);
    this.updateAggregates();
  }

  getWorker(workerId: string): Worker | undefined {
    return this.workers.get(workerId);
  }

  getWorkers(): Worker[] {
    return Array.from(this.workers.values());
  }

  updateWorker(workerId: string, updates: Partial<Worker>): void {
    const worker = this.workers.get(workerId);
    if (worker) {
      Object.assign(worker, updates);
      this.updateAggregates();
    }
  }

  addShare(share: ShareEntry): void {
    this.shares.unshift(share);
    if (this.shares.length > MAX_SHARES_LOG) {
      this.shares = this.shares.slice(0, MAX_SHARES_LOG);
    }
    if (share.accepted) {
      this.networkStats.totalAccepted++;
    } else {
      this.networkStats.totalRejected++;
    }
    if (share.difficulty > this.networkStats.bestShare) {
      this.networkStats.bestShare = share.difficulty;
    }
    this.recordBestShare(share.difficulty);
  }

  getRecentShares(limit = 50): ShareEntry[] {
    return this.shares.slice(0, limit);
  }

  getNetworkStats(): NetworkStats {
    return {
      ...this.networkStats,
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
    };
  }

  updateNetworkStats(updates: Partial<NetworkStats>): void {
    Object.assign(this.networkStats, updates);
  }

  getStratumStatus(): StratumStatus {
    return { ...this.stratumStatus };
  }

  setStratumStatus(status: StratumStatus): void {
    this.stratumStatus = { ...status };
  }

  getDashboardData(): DashboardData {
    return {
      workers: this.getWorkers(),
      recentShares: this.getRecentShares(),
      networkStats: this.getNetworkStats(),
      stratumStatus: this.getStratumStatus(),
    };
  }

  getNextColorIndex(): number {
    const idx = this.colorCounter % WORKER_COLORS.length;
    this.colorCounter++;
    return idx;
  }

  addHashrateSnapshot(snapshot: HashrateSnapshot): void {
    this.hashrateHistory.push(snapshot);
    if (this.hashrateHistory.length > MAX_HASHRATE_HISTORY) {
      this.hashrateHistory = this.hashrateHistory.slice(-MAX_HASHRATE_HISTORY);
    }
  }

  getHashrateHistory(): HashrateSnapshot[] {
    return [...this.hashrateHistory];
  }

  recordBestShare(difficulty: number): void {
    const now = Date.now();
    const INTERVAL_MS = 5 * 60 * 1000;
    if (now - this.currentIntervalStart >= INTERVAL_MS) {
      if (this.currentIntervalBest > 0) {
        this.bestShareHistory.push({
          timestamp: this.currentIntervalStart,
          difficulty: this.currentIntervalBest,
        });
        if (this.bestShareHistory.length > 192) {
          this.bestShareHistory = this.bestShareHistory.slice(-192);
        }
      }
      this.currentIntervalBest = 0;
      this.currentIntervalStart = now;
    }
    if (difficulty > this.currentIntervalBest) {
      this.currentIntervalBest = difficulty;
    }
  }

  getBestShareHistory(): BestShareEntry[] {
    const history = [...this.bestShareHistory];
    if (this.currentIntervalBest > 0) {
      history.push({
        timestamp: this.currentIntervalStart,
        difficulty: this.currentIntervalBest,
      });
    }
    return history;
  }

  private getBlocksFilePath(): string {
    const logsDir = path.resolve(import.meta.dirname, "..", "logs");
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }
    return path.join(logsDir, "blocks-found.json");
  }

  private loadBlocksFromDisk(): BlockFoundEntry[] {
    try {
      const filePath = this.getBlocksFilePath();
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, "utf-8");
        const blocks = JSON.parse(data);
        if (Array.isArray(blocks)) {
          return blocks.slice(0, MAX_BLOCKS_FOUND);
        }
      }
    } catch {}
    return [];
  }

  private saveBlocksToDisk(): void {
    try {
      const filePath = this.getBlocksFilePath();
      fs.writeFileSync(filePath, JSON.stringify(this.blocksFound, null, 2), "utf-8");
    } catch {}
  }

  addBlockFound(block: BlockFoundEntry): void {
    this.blocksFound.unshift(block);
    if (this.blocksFound.length > MAX_BLOCKS_FOUND) {
      this.blocksFound = this.blocksFound.slice(0, MAX_BLOCKS_FOUND);
    }
    this.saveBlocksToDisk();
  }

  updateBlockStatus(hash: string, newStatus: string): void {
    const block = this.blocksFound.find(b => b.hash === hash);
    if (block) {
      block.status = newStatus;
      this.saveBlocksToDisk();
    }
  }

  clearBlocksFound(): void {
    this.blocksFound = [];
    this.saveBlocksToDisk();
  }

  getBlocksFound(): BlockFoundEntry[] {
    return [...this.blocksFound];
  }

  getMonitorData(): MonitorData {
    const cfg = this.getConfig();
    const workers = this.getWorkers();
    const coinSet = new Set<string>();
    coinSet.add(cfg.coin);
    workers.forEach(w => { if (w.coin) coinSet.add(w.coin); });

    const activeNodes: ActiveNode[] = Array.from(coinSet).map(c => {
      const coinWorkers = workers.filter(w => (w.coin || cfg.coin) === c);
      const connectedCount = coinWorkers.filter(w => w.connected).length;
      const totalHash = coinWorkers.reduce((s, w) => s + w.hashrate1m, 0);
      return {
        coin: c as CoinType,
        stratumPort: cfg.coin === c ? cfg.stratumPort : 0,
        rpcPort: cfg.coin === c ? cfg.rpcPort : 0,
        workers: connectedCount,
        hashrate: totalHash,
        running: cfg.coin === c ? this.getStratumStatus().running : true,
      };
    });

    return {
      config: {
        coin: cfg.coin,
        walletAddress: cfg.walletAddress,
        stratumPort: cfg.stratumPort,
        algoNote: cfg.coin === "DGB" ? " SHA-256" : "",
      },
      workers,
      recentShares: this.getRecentShares(200),
      networkStats: this.getNetworkStats(),
      stratumStatus: this.getStratumStatus(),
      hashrateHistory: this.getHashrateHistory(),
      bestShareHistory: this.getBestShareHistory(),
      blocksFound: this.getBlocksFound(),
      activeNodes,
    };
  }

  private updateAggregates(): void {
    const workers = this.getWorkers();
    this.networkStats.connectedWorkers = workers.filter(w => w.connected).length;
    this.networkStats.totalHashrate = workers.reduce((sum, w) => sum + w.hashrate1m, 0);
    this.stratumStatus.connections = this.networkStats.connectedWorkers;
  }
}

export const storage = new MemStorage();
