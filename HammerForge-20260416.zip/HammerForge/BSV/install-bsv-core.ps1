# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Bitcoin SV Node Installer
# Downloads and installs Bitcoin SV Node
# Double-click INSTALL-BSV-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "1.2.0"
$GithubRepo = "bitcoin-sv/bitcoin-sv"
$AssetPattern = "x86_64-linux-gnu\.tar\.gz$"
$BSVDefaultInstallDir = "$env:ProgramFiles\BitcoinSV"
$BSVDefaultDataDir = "$env:APPDATA\BitcoinSV"

Write-Host ""
Write-Host "  Default install location: $BSVDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Default data directory:   $BSVDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
$customInstall = Read-Host "  Use default locations? (Y=yes, N=choose custom) [Y]"
if ($customInstall -eq 'N' -or $customInstall -eq 'n') {
      $newInstallDir = Read-Host "  Enter install path (e.g. D:\Mining\BSV)"
      if ($newInstallDir -and $newInstallDir.Trim() -ne '') {
          $BSVDefaultInstallDir = $newInstallDir.Trim()
          Write-Host "  Install path set to: $BSVDefaultInstallDir" -ForegroundColor Green
      }
      $newDataDir = Read-Host "  Enter data directory (e.g. D:\MiningData\BSV) [press Enter for default]"
      if ($newDataDir -and $newDataDir.Trim() -ne '') {
          $BSVDefaultDataDir = $newDataDir.Trim()
          Write-Host "  Data directory set to: $BSVDefaultDataDir" -ForegroundColor Green
      }
  }
$BSVSourceUrl = "https://github.com/bitcoin-sv/bitcoin-sv"
$BSVDownloadPage = "https://bitcoinsv.io/download/"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        $tarballName = "bitcoin-sv-$version-x86_64-linux-gnu.tar.gz"
        $fallbackUrl = "https://download.bitcoinsv.io/bitcoinsv/$version/$tarballName"
        return @{
            Version = $version
            Tag = $tag
            FileName = $tarballName
            Url = $fallbackUrl
        }
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-BSVExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\BitcoinSV",
        "${env:ProgramFiles(x86)}\BitcoinSV",
        "$env:LOCALAPPDATA\BitcoinSV",
        "C:\BitcoinSV",
        "$env:ProgramFiles\Bitcoin SV",
        "${env:ProgramFiles(x86)}\Bitcoin SV",
        "C:\Bitcoin SV"
    )
    $exeNames = @("bitcoin-qt.exe", "bitcoind.exe", "bitcoin-sv.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Bitcoin SV Node Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-BSV-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/3] Checking for existing Bitcoin SV installation..." -ForegroundColor Yellow
$existing = Find-BSVExecutable
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Bitcoin SV already installed at: $($existing.Dir)" -ForegroundColor Green
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Bitcoin SV not found. Will guide setup." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~10 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain (~400+ GB)." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/3] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "bitcoin-sv-$FallbackVersion-x86_64-linux-gnu.tar.gz"
        $useUrl = "https://download.bitcoinsv.io/bitcoinsv/$FallbackVersion/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n  Bitcoin SV Setup..." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  NOTE: Bitcoin SV currently provides Linux-only binaries." -ForegroundColor Yellow
    Write-Host "  There are no official Windows builds available." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  ============ OPTION 1: WSL (Recommended) ============" -ForegroundColor White
    Write-Host ""
    Write-Host "  Use Windows Subsystem for Linux to run the BSV node:" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Step 1: Install WSL (if not already installed)" -ForegroundColor Cyan
    Write-Host "    Open PowerShell as Admin and run:  wsl --install" -ForegroundColor Gray
    Write-Host "    Restart your computer after install." -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Step 2: Download BSV node $useTag in WSL" -ForegroundColor Cyan
    Write-Host "    Open Ubuntu (from Start Menu) and run:" -ForegroundColor Gray
    Write-Host "    wget $useUrl" -ForegroundColor DarkGray
    Write-Host "    tar xzf $useFileName" -ForegroundColor DarkGray
    Write-Host "    sudo cp bitcoin-sv-$useVersion/bin/* /usr/local/bin/" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  Step 3: Start the BSV node" -ForegroundColor Cyan
    Write-Host "    bitcoind -server -rpcuser=bsvrpc -rpcpassword=bsvrpcpassword -rpcport=8532 -port=8533 -rpcbind=0.0.0.0 -rpcallowip=0.0.0.0/0" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  The RPC port will be accessible from Windows at 127.0.0.1:8532" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  ============ OPTION 2: Build from Source ============" -ForegroundColor White
    Write-Host ""
    Write-Host "  Source code: $BSVSourceUrl" -ForegroundColor Cyan
    Write-Host "  Follow Bitcoin Core build instructions for Windows." -ForegroundColor Gray
    Write-Host "  Install to: $BSVDefaultInstallDir" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  ============ OPTION 3: Third-Party Build ============" -ForegroundColor White
    Write-Host ""
    Write-Host "  Check: $BSVDownloadPage" -ForegroundColor Cyan
    Write-Host "  Some community members provide Windows builds." -ForegroundColor Gray
    Write-Host "  If you have a Windows .zip or .exe, extract/install" -ForegroundColor Gray
    Write-Host "  to: $BSVDefaultInstallDir" -ForegroundColor Gray
    Write-Host ""

    $wslInstall = Read-Host "  Would you like to install WSL now? (y/n)"
    if ($wslInstall -eq "y") {
        Write-Host ""
        Write-Host "  Installing WSL..." -ForegroundColor Yellow
        Write-Host "  A system restart may be required after this step." -ForegroundColor Gray
        try {
            Start-Process -FilePath "wsl" -ArgumentList "--install" -Wait -NoNewWindow
            Write-Host "  WSL install command completed." -ForegroundColor Green
            Write-Host "  You may need to restart your computer." -ForegroundColor Yellow
        } catch {
            Write-Host "  Could not run WSL install automatically." -ForegroundColor Yellow
            Write-Host "  Open PowerShell as Admin and run: wsl --install" -ForegroundColor Gray
        }
    }
}

Write-Host "`n[3/3] Setting up directories and firewall..." -ForegroundColor Yellow

if (-not (Test-Path $BSVDefaultDataDir)) {
    New-Item -ItemType Directory -Path $BSVDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $BSVDefaultDataDir" -ForegroundColor Green
}

$confPath = Join-Path $BSVDefaultDataDir "bitcoin.conf"
if (Test-Path $confPath) {
    $backup = "$confPath.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    Copy-Item $confPath $backup -Force -ErrorAction SilentlyContinue
    Write-Host "  Backed up existing config to: $backup" -ForegroundColor Gray
}
if ($pruneEnabled) {
    $pruneValue = "prune=10000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoin.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoin.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoin.conf with pruning enabled (~10 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "Bitcoin SV Node P2P (Port 8533)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8533 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Bitcoin SV peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8533" -ForegroundColor Green

$firewallRuleName2 = "Bitcoin SV RPC (Port 8532)"
$existingRule2 = Get-NetFirewallRule -DisplayName $firewallRuleName2 -ErrorAction SilentlyContinue
if ($existingRule2) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName2
}
New-NetFirewallRule -DisplayName $firewallRuleName2 `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8532 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Bitcoin SV RPC connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8532" -ForegroundColor Green

if ($existing) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "Bitcoin SV Node.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $existing.Exe
    $shortcut.Arguments = "-datadir=`"$BSVDefaultDataDir`""
    $shortcut.WorkingDirectory = (Split-Path $existing.Exe)
    $shortcut.Description = "Bitcoin SV Node"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: Bitcoin SV Node" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Bitcoin SV Setup Complete" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Data folder:  $BSVDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Install BSV node via WSL, build from source," -ForegroundColor Yellow
Write-Host "     or install a third-party Windows build" -ForegroundColor Yellow
Write-Host ""
Write-Host "  2. Start the node and let it sync the blockchain" -ForegroundColor Yellow
Write-Host ""
Write-Host "  3. Make sure RPC is configured:" -ForegroundColor Yellow
Write-Host "       rpcuser=bsvrpc" -ForegroundColor Gray
Write-Host "       rpcpassword=bsvrpcpassword" -ForegroundColor Gray
Write-Host "       rpcport=8532" -ForegroundColor Gray
Write-Host "       server=1" -ForegroundColor Gray
Write-Host ""
Write-Host "  4. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from BSV node:" -ForegroundColor White
Write-Host "       bitcoin-cli -rpcport=8532 getnewaddress" -ForegroundColor Gray
Write-Host "       BSV uses legacy addresses starting with 1 or 3" -ForegroundColor Gray
Write-Host ""

if ($existing) {
    $startNow = Read-Host "  Start Bitcoin SV Node now? (y/n)"
    if ($startNow -eq "y") {
        Write-Host ""
        Write-Host "  Starting Bitcoin SV Node..." -ForegroundColor Yellow
        Start-Process $existing.Exe -ArgumentList "-datadir=`"$BSVDefaultDataDir`"", "-conf=bitcoin.conf"
        Write-Host "  Bitcoin SV Node is starting. Let it sync fully before mining." -ForegroundColor Green
    }
}

Write-Host ""
Read-Host "Press Enter to exit"
