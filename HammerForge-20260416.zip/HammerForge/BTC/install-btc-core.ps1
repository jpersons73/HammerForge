# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Bitcoin Core Wallet Installer
# Downloads and installs Bitcoin Core from bitcoincore.org
# Double-click INSTALL-BTC-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "30.2"
$GithubRepo = "bitcoin/bitcoin"
$BTCDefaultInstallDir = "$env:ProgramFiles\Bitcoin"
$BTCDefaultDataDir = "$env:APPDATA\Bitcoin"

Write-Host ""
Write-Host "  Default install location: $BTCDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Default data directory:   $BTCDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
$customInstall = Read-Host "  Use default locations? (Y=yes, N=choose custom) [Y]"
if ($customInstall -eq 'N' -or $customInstall -eq 'n') {
      $newInstallDir = Read-Host "  Enter install path (e.g. D:\Mining\BTC)"
      if ($newInstallDir -and $newInstallDir.Trim() -ne '') {
          $BTCDefaultInstallDir = $newInstallDir.Trim()
          Write-Host "  Install path set to: $BTCDefaultInstallDir" -ForegroundColor Green
      }
      $newDataDir = Read-Host "  Enter data directory (e.g. D:\MiningData\BTC) [press Enter for default]"
      if ($newDataDir -and $newDataDir.Trim() -ne '') {
          $BTCDefaultDataDir = $newDataDir.Trim()
          Write-Host "  Data directory set to: $BTCDefaultDataDir" -ForegroundColor Green
      }
  }

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        $fileName = "bitcoin-$version-win64.zip"
        $url = "https://bitcoincore.org/bin/bitcoin-core-$version/$fileName"
        return @{
            Version = $version
            Tag = $tag
            FileName = $fileName
            Url = $url
        }
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-BTCExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\Bitcoin",
        "${env:ProgramFiles(x86)}\Bitcoin",
        "$env:LOCALAPPDATA\Bitcoin",
        "C:\Bitcoin",
        "$env:ProgramFiles\Bitcoin Core",
        "${env:ProgramFiles(x86)}\Bitcoin Core"
    )
    $exeNames = @("bitcoin-qt.exe", "bitcoind.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Bitcoin Core Wallet Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-BTC-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing Bitcoin Core installation..." -ForegroundColor Yellow
$existing = Find-BTCExecutable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Bitcoin Core already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Bitcoin Core not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~10 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain (~600+ GB)." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "bitcoin-$FallbackVersion-win64.zip"
        $useUrl = "https://bitcoincore.org/bin/bitcoin-core-$FallbackVersion/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading Bitcoin Core $useTag from bitcoincore.org..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "btcsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $zipPath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $zipPath)
        $sizeMB = [math]::Round((Get-Item $zipPath).Length / 1MB, 1)
        Write-Host "  Downloaded Bitcoin Core ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download Bitcoin Core." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://bitcoincore.org/en/download/" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Installing Bitcoin Core..." -ForegroundColor Yellow
    $extractDir = Join-Path $tempDir "btc-extract"

    try {
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
        Write-Host "  Extracting archive..." -ForegroundColor Gray
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

        $innerDir = Get-ChildItem $extractDir | Select-Object -First 1
        $sourceDir = $innerDir.FullName

        if (Test-Path $BTCDefaultInstallDir) {
            $backup = "$BTCDefaultInstallDir.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Write-Host "  Backing up existing install to: $backup" -ForegroundColor Gray
            Rename-Item $BTCDefaultInstallDir $backup
        }

        New-Item -ItemType Directory -Path $BTCDefaultInstallDir -Force | Out-Null
        Copy-Item "$sourceDir\*" $BTCDefaultInstallDir -Recurse -Force

        $exeNames = @("bitcoin-qt.exe", "bitcoind.exe")
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $BTCDefaultInstallDir $exe
            if (Test-Path $testPath) { $foundExe = $testPath; break }
            $binPath = Join-Path $BTCDefaultInstallDir "bin\$exe"
            if (Test-Path $binPath) { $foundExe = $binPath; break }
        }

        if ($foundExe) {
            Write-Host "  Installed to: $BTCDefaultInstallDir" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Files extracted but executable not found in expected location." -ForegroundColor Yellow
            Write-Host "  Check: $BTCDefaultInstallDir" -ForegroundColor Gray
        }
    } catch {
        Write-Host "  ERROR: Failed to extract Bitcoin Core." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $zipPath -ErrorAction SilentlyContinue
        Remove-Item $extractDir -Recurse -ErrorAction SilentlyContinue
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $BTCDefaultDataDir)) {
    New-Item -ItemType Directory -Path $BTCDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $BTCDefaultDataDir" -ForegroundColor Green
}

if ($pruneEnabled) {
    $confPath = Join-Path $BTCDefaultDataDir "bitcoin.conf"
    $pruneValue = "prune=10000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoin.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoin.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoin.conf with pruning enabled (~10 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "Bitcoin Core P2P (Port 8333)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8333 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Bitcoin Core peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8333" -ForegroundColor Green

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "Bitcoin Core.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "Bitcoin Core Wallet"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: Bitcoin Core" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Bitcoin Core READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to: $BTCDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Data folder:  $BTCDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Double-click 'Bitcoin Core' on your Desktop" -ForegroundColor Yellow
Write-Host "     to open the wallet and start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from Bitcoin Core:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host ""
Write-Host "  ============================================" -ForegroundColor Magenta
Write-Host "  FAST SYNC: UTXO Snapshot (Optional)" -ForegroundColor Magenta
Write-Host "  ============================================" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Bitcoin Core v28+ supports UTXO snapshots for FAST initial sync." -ForegroundColor White
Write-Host "  Instead of syncing the full blockchain from scratch (days)," -ForegroundColor Gray
Write-Host "  you can load a snapshot and be mining-ready in under an hour." -ForegroundColor Gray
Write-Host ""
Write-Host "  The snapshot for block height 840,000 is built into Bitcoin Core." -ForegroundColor Gray
Write-Host ""
Write-Host "  HOW TO USE UTXO SNAPSHOT:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Start Bitcoin Core (let it begin syncing normally)" -ForegroundColor White
Write-Host ""
Write-Host "  2. Download the UTXO snapshot file (~12 GB):" -ForegroundColor White
Write-Host "     https://github.com/nicehash/bitcoin-utxo-snapshot" -ForegroundColor Cyan
Write-Host "     (or search for 'utxo-840000.dat' torrent)" -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Open a command prompt and run:" -ForegroundColor White
Write-Host "     bitcoin-cli -rpcclienttimeout=0 loadtxoutset C:\path\to\utxo-840000.dat" -ForegroundColor Cyan
Write-Host ""
Write-Host "  4. Bitcoin Core loads the snapshot (10-30 min) and is immediately" -ForegroundColor White
Write-Host "     usable for mining. Background validation continues automatically." -ForegroundColor Gray
Write-Host ""
Write-Host "  For full details: https://blog.lopp.net/bitcoin-node-sync-with-utxo-snapshots/" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NOTE: You can skip this and sync normally. The snapshot just speeds" -ForegroundColor Gray
Write-Host "  up the initial sync. Once synced either way, mining works the same." -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start Bitcoin Core now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting Bitcoin Core..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$BTCDefaultDataDir`"", "-conf=bitcoin.conf"
    Write-Host "  Bitcoin Core is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
