# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Solo Mining Setup - BC2 + DGB + BTC + BCH + BSV + XEC + FB + PPC + LCC + NITO (concurrent)
# Installs Node.js + stratum server for LAN miners and NiceHash rentals
# Sets up ALL coins - each on its own stratum port
# Double-click INSTALL-MINING.bat to run this

param(
    [string]$BC2WalletAddress = "",
    [string]$DGBWalletAddress = "",
    [string]$BTCWalletAddress = "",
    [string]$BCHWalletAddress = "",
    [string]$BSVWalletAddress = "",
    [string]$XECWalletAddress = "",
    [string]$FBWalletAddress = "",
    [string]$PPCWalletAddress = "",
    [string]$BC2RpcUser = "",
    [string]$BC2RpcPassword = "",
    [string]$DGBRpcUser = "",
    [string]$DGBRpcPassword = "",
    [string]$BTCRpcUser = "",
    [string]$BTCRpcPassword = "",
    [string]$BCHRpcUser = "",
    [string]$BCHRpcPassword = "",
    [string]$BSVRpcUser = "",
    [string]$BSVRpcPassword = "",
    [string]$XECRpcUser = "",
    [string]$XECRpcPassword = "",
    [string]$FBRpcUser = "",
    [string]$FBRpcPassword = "",
    [string]$PPCRpcUser = "",
    [string]$PPCRpcPassword = "",
    [string]$LCCWalletAddress = "",
    [string]$LCCRpcUser = "",
    [string]$LCCRpcPassword = "",
    [string]$NITOWalletAddress = "",
    [string]$NITORpcUser = "",
    [string]$NITORpcPassword = ""
)

$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((Split-Path -Leaf $ScriptDir) -eq "Mining") {
    $ProjectDir = Split-Path -Parent $ScriptDir
} else {
    $ProjectDir = $ScriptDir
}
$InstallDir = $ProjectDir
$MiningDir = Join-Path $InstallDir "Mining"

$NodeVersion = "20.18.1"

$CoinConfig = @{
    BC2 = @{ StratumPort = 3333; RpcPort = 8232; P2PPort = 8338; Label = "BC2 (BitcoinII)"; ShortLabel = "BC2"; AlgoNote = ""; ExeNames = @("bitcoinII-qt.exe", "bitcoin-qt.exe", "bitcoinIId.exe", "bitcoind.exe"); QtExe = "bitcoinII-qt.exe"; DaemonExe = "bitcoinIId.exe"; NodeLabel = "BitcoinII-Core"; DataDirName = "BitcoinII"; ConfName = "bitcoinII.conf"; DefaultRpcUser = "bc2rpc"; WalletEnv = "BC2_WALLET_ADDRESS"; AddrHint = "Addresses start with 1, 3, or bc1q"; InstallerBat = "INSTALL-BC2-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
    DGB = @{ StratumPort = 3334; RpcPort = 14022; P2PPort = 12024; Label = "DGB (DigiByte SHA-256)"; ShortLabel = "DGB"; AlgoNote = " SHA-256"; ExeNames = @("digibyte-qt.exe", "digibyted.exe"); QtExe = "digibyte-qt.exe"; DaemonExe = "digibyted.exe"; NodeLabel = "DigiByte Core"; DataDirName = "DigiByte"; ConfName = "digibyte.conf"; DefaultRpcUser = "dgbrpc"; WalletEnv = "DGB_WALLET_ADDRESS"; AddrHint = "Addresses start with D, S, or dgb1q"; InstallerBat = "INSTALL-DGB-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 360 }
    BTC = @{ StratumPort = 3335; RpcPort = 8332; P2PPort = 8333; Label = "BTC (Bitcoin)"; ShortLabel = "BTC"; AlgoNote = ""; ExeNames = @("bitcoin-qt.exe", "bitcoind.exe"); QtExe = "bitcoin-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin Core"; DataDirName = "Bitcoin"; ConfName = "bitcoin.conf"; DefaultRpcUser = "btcrpc"; WalletEnv = "BTC_WALLET_ADDRESS"; AddrHint = "Addresses start with 1, 3, or bc1q"; InstallerBat = "INSTALL-BTC-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 60 }
    BCH = @{ StratumPort = 3336; RpcPort = 8432; P2PPort = 8433; Label = "BCH (Bitcoin Cash)"; ShortLabel = "BCH"; AlgoNote = ""; ExeNames = @("bitcoin-cash-node-qt.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-cash-node-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin Cash Node"; DataDirName = "BitcoinCash"; ConfName = "bitcoin.conf"; DefaultRpcUser = "bchrpc"; WalletEnv = "BCH_WALLET_ADDRESS"; AddrHint = "Addresses start with bitcoincash:q or 1"; InstallerBat = "INSTALL-BCH-CORE.bat"; NeedsDataDir = $true ; StartupDelay = 60 }
    BSV = @{ StratumPort = 3337; RpcPort = 8532; P2PPort = 8533; Label = "BSV (Bitcoin SV)"; ShortLabel = "BSV"; AlgoNote = ""; ExeNames = @("bitcoin-sv.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-sv.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin SV Node"; DataDirName = "BitcoinSV"; ConfName = "bitcoin.conf"; DefaultRpcUser = "bsvrpc"; WalletEnv = "BSV_WALLET_ADDRESS"; AddrHint = "Addresses start with 1 or 3"; InstallerBat = "INSTALL-BSV-CORE.bat"; NeedsDataDir = $true ; StartupDelay = 60 }
    XEC = @{ StratumPort = 3338; RpcPort = 8632; P2PPort = 8633; Label = "XEC (eCash)"; ShortLabel = "XEC"; AlgoNote = ""; ExeNames = @("bitcoin-abc-qt.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-abc-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "eCash Node (Bitcoin ABC)"; DataDirName = "BitcoinABC"; ConfName = "bitcoin.conf"; DefaultRpcUser = "xecrpc"; WalletEnv = "XEC_WALLET_ADDRESS"; AddrHint = "Addresses start with ecash:q or 1"; InstallerBat = "INSTALL-XEC-CORE.bat"; NeedsDataDir = $true ; StartupDelay = 60 }
    FB  = @{ StratumPort = 3339; RpcPort = 8732; P2PPort = 8733; Label = "FB (Fractal Bitcoin)"; ShortLabel = "FB"; AlgoNote = ""; ExeNames = @("bitcoin-qt.exe", "bitcoind.exe"); QtExe = "bitcoin-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Fractal Bitcoin"; DataDirName = "FractalBitcoin"; ConfName = "bitcoin.conf"; DefaultRpcUser = "fbrpc"; WalletEnv = "FB_WALLET_ADDRESS"; AddrHint = "Addresses start with 1, 3, or bc1q"; InstallerBat = "INSTALL-FB-CORE.bat"; NeedsDataDir = $true ; StartupDelay = 60 }
    PPC  = @{ StratumPort = 3340; RpcPort = 9902; P2PPort = 9901; Label = "PPC (Peercoin)"; ShortLabel = "PPC"; AlgoNote = ""; ExeNames = @("peercoin-qt.exe", "peercoind.exe"); QtExe = "peercoin-qt.exe"; DaemonExe = "peercoind.exe"; NodeLabel = "Peercoin"; DataDirName = "Peercoin"; ConfName = "peercoin.conf"; DefaultRpcUser = "ppcrpc"; WalletEnv = "PPC_WALLET_ADDRESS"; AddrHint = "Addresses start with P, p, or pc1q"; InstallerBat = "INSTALL-PPC-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
    LCC  = @{ StratumPort = 3341; RpcPort = 62457; P2PPort = 62458; Label = "LCC (Litecoin Cash)"; ShortLabel = "LCC"; AlgoNote = ""; ExeNames = @("litecoincash-qt.exe", "litecoincashd.exe"); QtExe = "litecoincash-qt.exe"; DaemonExe = "litecoincashd.exe"; NodeLabel = "Litecoin Cash"; DataDirName = "LitecoinCash"; ConfName = "litecoincash.conf"; DefaultRpcUser = "lccrpc"; WalletEnv = "LCC_WALLET_ADDRESS"; AddrHint = "Addresses start with C or 3"; InstallerBat = "INSTALL-LCC-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
    NITO = @{ StratumPort = 3342; RpcPort = 8821; P2PPort = 8820; Label = "NITO (NitoCoin)"; ShortLabel = "NITO"; AlgoNote = ""; ExeNames = @("nito-qt.exe", "nitod.exe"); QtExe = "nito-qt.exe"; DaemonExe = "nitod.exe"; NodeLabel = "NitoCoin"; DataDirName = "Nito"; ConfName = "nito.conf"; DefaultRpcUser = "nitorpc"; WalletEnv = "NITO_WALLET_ADDRESS"; AddrHint = "Addresses start with N"; InstallerBat = "INSTALL-NITO-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
    BCH2 = @{ StratumPort = 3343; RpcPort = 8342; P2PPort = 8339; Label = "BCH2 (Bitcoin Cash II)"; ShortLabel = "BCH2"; AlgoNote = ""; ExeNames = @("bitcoincashII-qt.exe", "bitcoincashIId.exe"); QtExe = "bitcoincashII-qt.exe"; DaemonExe = "bitcoincashIId.exe"; NodeLabel = "Bitcoin Cash II"; DataDirName = "BitcoinCashII"; ConfName = "bitcoincashII.conf"; DefaultRpcUser = "bch2rpc"; WalletEnv = "BCH2_WALLET_ADDRESS"; AddrHint = "Addresses start with bitcoincashii:q"; InstallerBat = "INSTALL-BCH2-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
    XRO  = @{ StratumPort = 3344; RpcPort = 25169; P2PPort = 25170; Label = "XRO (XeroCoin)"; ShortLabel = "XRO"; AlgoNote = ""; ExeNames = @("xero-qt.exe", "xerod.exe"); QtExe = "xero-qt.exe"; DaemonExe = "xerod.exe"; NodeLabel = "XeroCoin"; DataDirName = "Xero"; ConfName = "xero.conf"; DefaultRpcUser = "xrorpc"; WalletEnv = "XRO_WALLET_ADDRESS"; AddrHint = "Addresses start with xro1q"; InstallerBat = "INSTALL-XRO-CORE.bat"; NeedsDataDir = $false ; StartupDelay = 30 }
}

$CoinOrder = @("BC2", "DGB", "BTC", "BCH", "BSV", "XEC", "FB", "PPC", "LCC", "NITO", "BCH2", "XRO")


function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-NodeJS {
    try {
        $nodeVersion = & node --version 2>$null
        if ($nodeVersion) {
            Write-Host "  Node.js found: $nodeVersion" -ForegroundColor Green
            return $true
        }
    } catch {}
    return $false
}

function Install-NodeJS {
    Write-Host "  Node.js not found. Downloading Node.js v$NodeVersion..." -ForegroundColor Yellow

    $msiName = "node-v$NodeVersion-x64.msi"
    $msiUrl = "https://nodejs.org/dist/v$NodeVersion/$msiName"
    $tempDir = Join-Path $env:TEMP "miningsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $msiPath = Join-Path $tempDir $msiName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        $wc.DownloadFile($msiUrl, $msiPath)
        Write-Host "  Downloaded Node.js installer ($([math]::Round((Get-Item $msiPath).Length / 1MB, 1)) MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download Node.js." -ForegroundColor Red
        Write-Host "  Please install manually from https://nodejs.org" -ForegroundColor Yellow
        Write-Host "  Error: $_" -ForegroundColor Gray
        return $false
    }

    Write-Host "  Running Node.js installer (this may take a minute)..." -ForegroundColor Gray
    try {
        $installArgs = "/i `"$msiPath`" /qn /norestart"
        $process = Start-Process -FilePath "msiexec.exe" -ArgumentList $installArgs -Wait -PassThru
        if ($process.ExitCode -ne 0) {
            Write-Host "  WARNING: Installer returned exit code $($process.ExitCode)" -ForegroundColor Yellow
        }

        $nodeInstallDir = "$env:ProgramFiles\nodejs"
        $env:PATH = "$nodeInstallDir;$env:PATH"

        $testVersion = & "$nodeInstallDir\node.exe" --version 2>$null
        if ($testVersion) {
            Write-Host "  Node.js $testVersion installed successfully" -ForegroundColor Green
            return $true
        } else {
            Write-Host "  WARNING: Node.js installed but could not verify." -ForegroundColor Yellow
            return $true
        }
    } catch {
        Write-Host "  ERROR: Failed to install Node.js." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
    } finally {
        Remove-Item $msiPath -ErrorAction SilentlyContinue
    }

    return $false
}


function Check-Tailscale {
    $tsExe = $null
    $tsPaths = @(
        "$env:ProgramFiles\Tailscale\tailscale.exe",
        "${env:ProgramFiles(x86)}\Tailscale\tailscale.exe",
        "$env:LOCALAPPDATA\Tailscale\tailscale.exe"
    )
    foreach ($p in $tsPaths) {
        if (Test-Path $p) { $tsExe = $p; break }
    }
    if (-not $tsExe) {
        $tsCmd = Get-Command tailscale.exe -ErrorAction SilentlyContinue
        if ($tsCmd) { $tsExe = $tsCmd.Source }
    }
    if ($tsExe) {
        try {
            $tsIp = & $tsExe ip -4 2>$null
            if ($tsIp -and $tsIp -match "^100\.") {
                Write-Host "  Tailscale DETECTED (IP: $tsIp)" -ForegroundColor Green
                Write-Host "  Remote monitor: http://${tsIp}:<coin-port>/monitor (5000-5011)" -ForegroundColor Cyan
                return $true
            } else {
                Write-Host "  Tailscale installed but not connected. Run tailscale up to connect." -ForegroundColor Yellow
                return $true
            }
        } catch {
            Write-Host "  Tailscale installed but could not get IP. Make sure it is running." -ForegroundColor Yellow
            return $true
        }
    }
    Write-Host "  Tailscale NOT installed." -ForegroundColor Yellow
    Write-Host "" -ForegroundColor Gray
    Write-Host "  For remote monitor access (from phone/work), install Tailscale:" -ForegroundColor White
    Write-Host "    1. Download from https://tailscale.com/download/windows" -ForegroundColor Gray
    Write-Host "    2. Install and sign in (free account)" -ForegroundColor Gray
    Write-Host "    3. Install Tailscale on your phone too" -ForegroundColor Gray
    Write-Host "    4. Access monitor via http://<tailscale-ip>:<port>/monitor (ports 5000-5011)" -ForegroundColor Gray
    Write-Host "" -ForegroundColor Gray
    Write-Host "  Without Tailscale, you can still access the monitor on your home LAN." -ForegroundColor Gray
    return $false
}
function Find-CoinExecutable {
    param([string]$Coin)

    $cfg = $CoinConfig[$Coin]
    $exeNames = $cfg.ExeNames

    $searchDirs = @(
        "$env:ProgramFiles\$($cfg.DataDirName)",
        "${env:ProgramFiles(x86)}\$($cfg.DataDirName)",
        "$env:LOCALAPPDATA\$($cfg.DataDirName)",
        "$env:LOCALAPPDATA\Programs\$($cfg.DataDirName)",
        "$env:APPDATA\$($cfg.DataDirName)",
        "C:\$($cfg.DataDirName)"
    )

    if ($Coin -eq "BC2") {
        $searchDirs += @("$env:ProgramFiles\Bitcoin2", "${env:ProgramFiles(x86)}\Bitcoin2", "C:\Bitcoin2")
    }
    if ($Coin -eq "DGB") {
        $searchDirs += @(
            "$env:ProgramFiles\DigiByte Core", "${env:ProgramFiles(x86)}\DigiByte Core",
            "$env:LOCALAPPDATA\DigiByte Core", "C:\DigiByte Core",
            "$env:USERPROFILE\Downloads\digibyte-8.22.0-win64\digibyte-8.22.0",
            "$env:USERPROFILE\Desktop\digibyte-8.22.0-win64\digibyte-8.22.0"
        )
    }
    if ($Coin -eq "BTC") {
        $searchDirs += @("$env:ProgramFiles\Bitcoin", "${env:ProgramFiles(x86)}\Bitcoin", "C:\Bitcoin")
    }
    if ($Coin -eq "BCH") {
        $searchDirs += @(
            "$env:ProgramFiles\Bitcoin Cash Node", "${env:ProgramFiles(x86)}\Bitcoin Cash Node",
            "$env:LOCALAPPDATA\Bitcoin Cash Node", "C:\Bitcoin Cash Node"
        )
    }
    if ($Coin -eq "BSV") {
        $searchDirs += @(
            "$env:ProgramFiles\Bitcoin SV", "${env:ProgramFiles(x86)}\Bitcoin SV",
            "$env:ProgramFiles\Bitcoin SV Node", "C:\Bitcoin SV"
        )
    }
    if ($Coin -eq "XEC") {
        $searchDirs += @(
            "$env:ProgramFiles\Bitcoin ABC", "${env:ProgramFiles(x86)}\Bitcoin ABC",
            "$env:LOCALAPPDATA\Bitcoin ABC", "C:\Bitcoin ABC",
            "$env:ProgramFiles\eCash", "C:\eCash"
        )
    }
    if ($Coin -eq "BCH2") {
        $searchDirs += @(
            "$env:ProgramFiles\Bitcoin Cash II", "${env:ProgramFiles(x86)}\Bitcoin Cash II",
            "$env:LOCALAPPDATA\Bitcoin Cash II", "C:\Bitcoin Cash II",
            "$env:ProgramFiles\BitcoinCash II", "${env:ProgramFiles(x86)}\BitcoinCash II"
        )
    }

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = (Split-Path $binPath -Parent); Exe = $binPath }
            }
            $daemonPath = Join-Path $dir "daemon\$exe"
            if (Test-Path $daemonPath) {
                return @{ Dir = (Split-Path $daemonPath -Parent); Exe = $daemonPath }
            }
        }
    }

    $genericExes = @("bitcoin-qt.exe", "bitcoind.exe")
    $uniqueExes = $exeNames | Where-Object { $_ -notin $genericExes }

    if ($uniqueExes.Count -gt 0) {
        foreach ($exe in $uniqueExes) {
            try {
                $found = Get-Command $exe -ErrorAction SilentlyContinue
                if ($found) {
                    $exePath = $found.Source
                    return @{ Dir = (Split-Path $exePath -Parent); Exe = $exePath }
                }
            } catch {}
        }

        foreach ($exe in $uniqueExes) {
            try {
                $proc = Get-Process -Name ($exe -replace '\.exe$','') -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($proc -and $proc.Path) {
                    return @{ Dir = (Split-Path $proc.Path -Parent); Exe = $proc.Path }
                }
            } catch {}
        }
    }

    return $null
}

function Find-CoinDataDir {
    param([string]$Coin)

    $cfg = $CoinConfig[$Coin]
    if (-not $cfg -or -not $cfg.DataDirName) {
        return ""
    }
    $commonPaths = @(
        "$env:APPDATA\$($cfg.DataDirName)",
        "$env:LOCALAPPDATA\$($cfg.DataDirName)"
    )
    $default = "$env:APPDATA\$($cfg.DataDirName)"

    if ($Coin -eq "BC2") {
        $commonPaths += @("$env:APPDATA\Bitcoin2", "$env:LOCALAPPDATA\Bitcoin2")
    }
    if ($Coin -eq "BCH2") {
        $commonPaths += @(
            "$env:APPDATA\Bitcoin Cash II", "$env:LOCALAPPDATA\Bitcoin Cash II",
            "$env:APPDATA\BitcoinCash II", "$env:LOCALAPPDATA\BitcoinCash II"
        )
    }

    foreach ($path in $commonPaths) {
        if (Test-Path $path) { return $path }
    }
    return $default
}

function Configure-CoinNode {
    param([string]$DataDir, [string]$RpcUser, [string]$RpcPassword, [string]$Coin)

    $cfg = $CoinConfig[$Coin]
    if (-not $cfg) {
        Write-Host "  ERROR: Unknown coin '$Coin' - skipping config" -ForegroundColor Red
        return
    }
    if (-not $DataDir -or $DataDir -eq $env:APPDATA -or $DataDir -eq "$env:APPDATA\") {
        Write-Host "  ERROR: Invalid data directory for $Coin - skipping config" -ForegroundColor Red
        return
    }

    if (-not (Test-Path $DataDir)) {
        New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
        Write-Host "  Created data directory: $DataDir" -ForegroundColor Green
    }

    $confPath = Join-Path $DataDir $cfg.ConfName

    $knownConfNames = @("bitcoin.conf", "Bitcoin.conf", "bitcoinII.conf", "BitcoinII.conf", "digibyte.conf", "peercoin.conf")
    foreach ($altName in $knownConfNames) {
        if ($altName -eq $cfg.ConfName) { continue }
        $altPath = Join-Path $DataDir $altName
        if (Test-Path $altPath) {
            $altBackup = "$altPath.old.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Copy-Item $altPath $altBackup -Force -ErrorAction SilentlyContinue
            Remove-Item $altPath -Force -ErrorAction SilentlyContinue
            $coinShort = $cfg.ShortLabel
            $correctConf = $cfg.ConfName
            Write-Host "  Removed stale $altName (backed up) - $coinShort uses $correctConf" -ForegroundColor Yellow
        }
    }

    if (Test-Path $confPath) {
        $backup = "$confPath.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        Copy-Item $confPath $backup
        Write-Host "  Backed up existing config to: $backup" -ForegroundColor Gray
    }

    $allLines = @(
        "server=1",
        "rpcuser=$RpcUser",
        "rpcpassword=$RpcPassword",
        "rpcallowip=127.0.0.1",
        "rpcport=$($cfg.RpcPort)",
        "port=$($cfg.P2PPort)",
        "listen=1",
        "txindex=1",
        "maxconnections=40",
        "debug=0",
        "printtoconsole=0"
    )
    if ($Coin -eq "BC2") {
        $allLines += "dnsseed=1"
        $allLines += "dns=1"
        $allLines += "seednode=dnsseed.bitcoin-ii.org:8338"
        $allLines += "seednode=bitcoinII.ddns.net:8338"
        $allLines += "addnode=dnsseed.bitcoin-ii.org:8338"
        $allLines += "addnode=bitcoinII.ddns.net:8338"
    }
    if ($Coin -eq "BCH2") {
        $allLines += "dnsseed=1"
        $allLines += "dns=1"
        $allLines += "addnode=144.202.73.66:8339"
        $allLines += "addnode=108.61.190.83:8339"
        $allLines += "addnode=64.176.215.202:8339"
        $allLines += "addnode=45.32.138.29:8339"
        $allLines += "addnode=139.180.132.24:8339"
        $allLines += "seednode=dnsseed1.bch2.org:8339"
        $allLines += "seednode=dnsseed2.bch2.org:8339"
    }

    try {
        $allLines | Out-File -FilePath $confPath -Encoding ASCII -Force
        Start-Sleep -Milliseconds 500
        $readBack = Get-Content $confPath -Raw -ErrorAction SilentlyContinue
        if ($readBack -and $readBack.Contains("server=1")) {
            Write-Host "  Config written OK: $confPath" -ForegroundColor Green
            Write-Host "    rpcuser=$RpcUser  rpcport=$($cfg.RpcPort)" -ForegroundColor Gray
        } else {
            Write-Host "  Auto-write may have failed - use manual paste below" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  Auto-write failed: $_ " -ForegroundColor Yellow
        Write-Host "  Use manual paste below" -ForegroundColor Yellow
    }

    if ($Coin -eq "BCH2") {
        $altDirs = @(
            "$env:APPDATA\BitcoinCashII",
            "$env:LOCALAPPDATA\BitcoinCashII",
            "$env:APPDATA\Bitcoin Cash II",
            "$env:LOCALAPPDATA\Bitcoin Cash II"
        )
        foreach ($altDir in $altDirs) {
            if ($altDir -eq $DataDir) { continue }
            if (Test-Path $altDir) {
                $altConf = Join-Path $altDir $cfg.ConfName
                try {
                    $allLines | Out-File -FilePath $altConf -Encoding ASCII -Force
                    Write-Host "  BCH2 dual-write: $altConf" -ForegroundColor Green
                } catch {
                    Write-Host "  BCH2 dual-write failed: $altConf" -ForegroundColor Yellow
                }
            }
        }
    }

    $backupDir = Join-Path $InstallDir $Coin
    if (-not (Test-Path $backupDir)) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    }
    if (Test-Path $backupDir) {
        $backupConfPath = Join-Path $backupDir $cfg.ConfName
        try {
            $allLines | Out-File -FilePath $backupConfPath -Encoding ASCII -Force
            Write-Host "  Backup config saved: $backupConfPath" -ForegroundColor Green
        } catch {
            Write-Host "  Could not save backup config to $backupConfPath" -ForegroundColor Yellow
        }
    }

    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host "  $($cfg.Label) CONFIG FILE" -ForegroundColor Cyan
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  File location (open in Notepad):" -ForegroundColor White
    Write-Host "  $confPath" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Copy everything between the dashed lines:" -ForegroundColor White
    Write-Host "  ------------------------------------------" -ForegroundColor Gray
    foreach ($ln in $allLines) {
        Write-Host "  $ln" -ForegroundColor Green
    }
    Write-Host "  ------------------------------------------" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  HOW TO MANUALLY SET THIS UP:" -ForegroundColor White
    Write-Host "  1. Press Win+R, type:  notepad $confPath" -ForegroundColor Gray
    Write-Host "  2. Delete everything in the file" -ForegroundColor Gray
    Write-Host "  3. Paste the green lines above" -ForegroundColor Gray
    Write-Host "  4. Save and close Notepad" -ForegroundColor Gray
    $bkDir = Join-Path $InstallDir $Coin
    $bkFile = Join-Path $bkDir $cfg.ConfName
    if (Test-Path $bkFile) {
        Write-Host "" -ForegroundColor White
        Write-Host "  Or copy the backup config from:" -ForegroundColor White
        Write-Host "  $bkFile" -ForegroundColor Yellow
        Write-Host "  to: $confPath" -ForegroundColor Yellow
    }
    Write-Host ""
}

function Get-LocalIP {
    $ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
        $_.InterfaceAlias -notmatch "Loopback" -and
        $_.IPAddress -notlike "169.254.*" -and
        $_.PrefixOrigin -ne "WellKnown"
    } | Select-Object -First 1).IPAddress

    if (-not $ip) { $ip = "127.0.0.1" }
    return $ip
}

function Create-CoinBatchFile {
    param([string]$Dir, [string]$ServerDir, [int]$Port, [string]$Wallet, [string]$CoinExePath, [string]$Coin, [string]$ConfigFile, [string]$RpcUser, [string]$RpcPass)


    $cfg = $CoinConfig[$Coin]
    $coinLabel = $cfg.Label
    $windowTitle = "$($cfg.ShortLabel) HammerForge - Stratum Server"
    $batchName = "start-mining-$($Coin.ToLower()).bat"
    $envCoin = "MINING_COIN=$Coin"
    $walletEnv = $cfg.WalletEnv
    $webPort = 5000 + ($cfg.StratumPort - 3333)
    $qtExe = $cfg.QtExe
    $daemonExe = $cfg.DaemonExe
    $nodeLabel = $cfg.NodeLabel

    $startBatLines = New-Object System.Collections.ArrayList
    [void]$startBatLines.Add("@echo off")
    [void]$startBatLines.Add("title $windowTitle")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add("set LOCAL_IP=127.0.0.1")
    [void]$startBatLines.Add("for /f ""tokens=2 delims=:"" %%a in ('ipconfig ^| findstr /c:""IPv4""') do set LOCAL_IP=%%a")
    [void]$startBatLines.Add("set LOCAL_IP=%LOCAL_IP: =%")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add("color 0A")
    [void]$startBatLines.Add("mode con cols=72 lines=50")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo  ====================================================================")
    [void]$startBatLines.Add("echo  ^|                                                                  ^|")
    [void]$startBatLines.Add("echo  ^|   SHA-256 SOLO MINER                                            ^|")
    [void]$startBatLines.Add("echo  ^|                                                                  ^|")
    [void]$startBatLines.Add("echo  ^|   Coin:    $($coinLabel.PadRight(50))^|")
    [void]$startBatLines.Add("echo  ^|   Port:    $("$Port".PadRight(50))^|")
    [void]$startBatLines.Add("echo  ^|   Wallet:  $($Wallet.PadRight(50))^|")
    [void]$startBatLines.Add("echo  ^|   LAN IP:  %LOCAL_IP%                                            ^|")
    [void]$startBatLines.Add("echo  ^|   UPnP:    Auto Port Forward (see log below)                    ^|")
    [void]$startBatLines.Add("echo  ^|                                                                  ^|")
    [void]$startBatLines.Add("echo  ====================================================================")
    [void]$startBatLines.Add("echo.")

    if ($CoinExePath -and (Test-Path $CoinExePath)) {
        $dataDir = "$env:APPDATA\$($cfg.DataDirName)"
        $confFile = $cfg.ConfName
        $confFullPath = "$dataDir\$confFile"
        $rpcPort = $cfg.RpcPort
        $p2pPort = $cfg.P2PPort
        $startupDelay = $cfg.StartupDelay
        if (-not $startupDelay) { $startupDelay = 60 }

        $confLines = @(
            "server=1",
            "rpcuser=$RpcUser",
            "rpcpassword=$RpcPass",
            "rpcallowip=127.0.0.1",
            "rpcport=$rpcPort",
            "port=$p2pPort",
            "listen=1",
            "maxconnections=40",
            "debug=0",
            "printtoconsole=0"
        )
        if ($Coin -eq "BC2") {
            $confLines += @(
                "dnsseed=1",
                "dns=1",
                "seednode=dnsseed.bitcoin-ii.org:8338",
                "seednode=bitcoinII.ddns.net:8338",
                "addnode=dnsseed.bitcoin-ii.org:8338",
                "addnode=bitcoinII.ddns.net:8338"
            )
        }
        if ($Coin -eq "BCH2") {
            $confLines += @(
                "dnsseed=1",
                "dns=1",
                "addnode=144.202.73.66:8339",
                "addnode=108.61.190.83:8339",
                "addnode=64.176.215.202:8339",
                "addnode=45.32.138.29:8339",
                "addnode=139.180.132.24:8339",
                "seednode=dnsseed1.bch2.org:8339",
                "seednode=dnsseed2.bch2.org:8339"
            )
        }

        [void]$startBatLines.Add("echo ---- Conf Validation ----")
        [void]$startBatLines.Add("set CONF_PATH=$confFullPath")
        [void]$startBatLines.Add("set CONF_OK=1")
        [void]$startBatLines.Add("set NEED_RESTART=0")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add("if not exist ""%CONF_PATH%"" (")
        [void]$startBatLines.Add("    echo   Conf file not found - will create: %CONF_PATH%")
        [void]$startBatLines.Add("    set CONF_OK=0")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add("if %CONF_OK%==1 (")
        [void]$startBatLines.Add("    findstr /c:""rpcuser=$RpcUser"" ""%CONF_PATH%"" >nul 2>nul")
        [void]$startBatLines.Add("    if errorlevel 1 (")
        [void]$startBatLines.Add("        echo   MISMATCH: rpcuser in conf does not match batch config")
        [void]$startBatLines.Add("        set CONF_OK=0")
        [void]$startBatLines.Add("    )")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("if %CONF_OK%==1 (")
        [void]$startBatLines.Add("    findstr /c:""rpcpassword=$RpcPass"" ""%CONF_PATH%"" >nul 2>nul")
        [void]$startBatLines.Add("    if errorlevel 1 (")
        [void]$startBatLines.Add("        echo   MISMATCH: rpcpassword in conf does not match batch config")
        [void]$startBatLines.Add("        set CONF_OK=0")
        [void]$startBatLines.Add("    )")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("if %CONF_OK%==1 (")
        [void]$startBatLines.Add("    findstr /c:""rpcport=$rpcPort"" ""%CONF_PATH%"" >nul 2>nul")
        [void]$startBatLines.Add("    if errorlevel 1 (")
        [void]$startBatLines.Add("        echo   MISMATCH: rpcport in conf does not match batch config")
        [void]$startBatLines.Add("        set CONF_OK=0")
        [void]$startBatLines.Add("    )")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add("if %CONF_OK%==1 (")
        [void]$startBatLines.Add("    echo   Conf OK: rpcuser, rpcpassword, rpcport all match")
        [void]$startBatLines.Add("    goto confvalidated")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add("echo   Fixing conf file: %CONF_PATH%")
        [void]$startBatLines.Add("if not exist ""$dataDir"" mkdir ""$dataDir""")
        [void]$startBatLines.Add("(")
        foreach ($cl in $confLines) {
            [void]$startBatLines.Add("echo $cl")
        }
        [void]$startBatLines.Add(") > ""%CONF_PATH%""")
        [void]$startBatLines.Add("echo   Conf file written with correct credentials")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add("tasklist /fi ""imagename eq $qtExe"" 2>nul | find /i ""$qtExe"" >nul")
        [void]$startBatLines.Add("if not errorlevel 1 (")
        [void]$startBatLines.Add("    echo.")
        [void]$startBatLines.Add("    echo   NOTE: $nodeLabel is running with old config.")
        [void]$startBatLines.Add("    echo   Close the wallet normally [File - Exit], then re-open it.")
        [void]$startBatLines.Add("    echo   DO NOT force-kill -- it can corrupt the blockchain database.")
        [void]$startBatLines.Add("    echo.")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("tasklist /fi ""imagename eq $daemonExe"" 2>nul | find /i ""$daemonExe"" >nul")
        [void]$startBatLines.Add("if not errorlevel 1 (")
        [void]$startBatLines.Add("    echo.")
        [void]$startBatLines.Add("    echo   NOTE: $nodeLabel daemon is running with old config.")
        [void]$startBatLines.Add("    echo   Close it normally, then re-open it.")
        [void]$startBatLines.Add("    echo.")
        [void]$startBatLines.Add(")")
        [void]$startBatLines.Add("")
        [void]$startBatLines.Add(":confvalidated")
        [void]$startBatLines.Add("echo.")

        [void]$startBatLines.Add("echo Checking if $nodeLabel is running...")
        [void]$startBatLines.Add("tasklist /fi ""imagename eq $qtExe"" 2>nul | find /i ""$qtExe"" >nul")
        [void]$startBatLines.Add("if not errorlevel 1 goto skipstart")
        [void]$startBatLines.Add("tasklist /fi ""imagename eq $daemonExe"" 2>nul | find /i ""$daemonExe"" >nul")
        [void]$startBatLines.Add("if not errorlevel 1 goto skipstart")
        [void]$startBatLines.Add("echo Starting $nodeLabel node...")
        [void]$startBatLines.Add("start """" ""$CoinExePath"" ""-datadir=$dataDir"" ""-conf=$confFile""")
        [void]$startBatLines.Add("echo.")
        [void]$startBatLines.Add("echo Waiting 60 seconds for $nodeLabel to initialize RPC...")
        [void]$startBatLines.Add("set WAIT_LEFT=60")
        [void]$startBatLines.Add(":rpcwait")
        [void]$startBatLines.Add("if %WAIT_LEFT% leq 0 goto rpcdone")
        [void]$startBatLines.Add("echo   %WAIT_LEFT%s remaining...")
        [void]$startBatLines.Add("timeout /t 10 /nobreak >nul")
        [void]$startBatLines.Add("set /a WAIT_LEFT-=10")
        [void]$startBatLines.Add("goto rpcwait")
        [void]$startBatLines.Add(":rpcdone")
        [void]$startBatLines.Add("echo   Node startup wait complete.")
        [void]$startBatLines.Add("goto startdone")
        [void]$startBatLines.Add(":skipstart")
        [void]$startBatLines.Add("echo $nodeLabel is already running.")
        [void]$startBatLines.Add(":startdone")
        [void]$startBatLines.Add("echo.")
    }

    [void]$startBatLines.Add("cd /d ""$ServerDir""")
    [void]$startBatLines.Add("echo Working directory: %CD%")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add("where node >nul 2>nul")
    [void]$startBatLines.Add("if errorlevel 1 goto nonode")
    [void]$startBatLines.Add("echo Node.js found:")
    [void]$startBatLines.Add("call node --version")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("goto nodeok")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add(":nonode")
    [void]$startBatLines.Add("echo ERROR: Node.js is not installed or not in PATH.")
    [void]$startBatLines.Add("echo Please install Node.js from https://nodejs.org")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("goto exitpause")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add(":nodeok")
    [void]$startBatLines.Add("echo Checking dependencies...")
    [void]$startBatLines.Add("call npm install --silent 2>nul")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("call npx tsx --version >nul 2>nul")
    [void]$startBatLines.Add("if not errorlevel 1 goto tsxok")
    [void]$startBatLines.Add("echo Installing tsx...")
    [void]$startBatLines.Add("call npm install tsx")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add(":tsxok")
    [void]$startBatLines.Add("set NODE_ENV=production")
    [void]$startBatLines.Add("set PORT=$webPort")
    [void]$startBatLines.Add("set $envCoin")
    [void]$startBatLines.Add("set $walletEnv=$Wallet")
    [void]$startBatLines.Add("set CONFIG_FILE=$ConfigFile")
    [void]$startBatLines.Add("set ${Coin}_RPC_USER=$RpcUser")
    [void]$startBatLines.Add("set ${Coin}_RPC_PASSWORD=$RpcPass")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo   Config File: %CONFIG_FILE%")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("if exist ""%~dp0..\%CONFIG_FILE%"" (")
    [void]$startBatLines.Add("    type ""%~dp0..\%CONFIG_FILE%""")
    [void]$startBatLines.Add(") else (")
    [void]$startBatLines.Add("    echo   WARNING: Config file not found!")
    [void]$startBatLines.Add("    echo   Expected: %~dp0..\%CONFIG_FILE%")
    [void]$startBatLines.Add(")")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo   Starting stratum on port $Port")
    [void]$startBatLines.Add("echo   Press Ctrl+C to stop")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo   LAN:      stratum+tcp://%LOCAL_IP%:$Port")
    [void]$startBatLines.Add("echo   NiceHash: stratum+tcp://YOUR_PUBLIC_IP:$Port")
    [void]$startBatLines.Add("echo   Worker:   $Wallet.MinerName")
    [void]$startBatLines.Add("echo   Password: x")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo   Configure your miners with the LAN address above.")
    [void]$startBatLines.Add("echo   For NiceHash: select SHA256 algorithm")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo   Monitor:  http://%LOCAL_IP%:$webPort/monitor")
    [void]$startBatLines.Add("echo   Local:    http://localhost:$webPort/monitor")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo Mining monitor will open in your browser automatically.")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("start """" ""http://localhost:$webPort/monitor""")
    [void]$startBatLines.Add("set TAILSCALE_IP=")
    [void]$startBatLines.Add("for /f ""tokens=*"" %%i in ('tailscale ip -4 2^>nul') do set TAILSCALE_IP=%%i")
    [void]$startBatLines.Add("if defined TAILSCALE_IP (")
    [void]$startBatLines.Add("    echo   Remote access: http://%TAILSCALE_IP%:$webPort/monitor")
    [void]$startBatLines.Add(") else (")
    [void]$startBatLines.Add("    echo   Remote access: Install Tailscale for phone/remote access")
    [void]$startBatLines.Add("    echo   Download: https://tailscale.com/download/windows")
    [void]$startBatLines.Add(")")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("call npx tsx server/index.ts")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("echo   Stratum server has stopped.")
    
    [void]$startBatLines.Add("echo ============================================")
    [void]$startBatLines.Add("")
    [void]$startBatLines.Add(":exitpause")
    [void]$startBatLines.Add("echo.")
    [void]$startBatLines.Add("echo Press any key to close this window...")
    [void]$startBatLines.Add("pause >nul")

    $startBat = $startBatLines -join "`r`n"
    $asciiEnc = New-Object System.Text.ASCIIEncoding
    [System.IO.File]::WriteAllText((Join-Path $Dir $batchName), $startBat, $asciiEnc)
    Write-Host "  Created $batchName (port $Port)" -ForegroundColor Green
}

# ========================================
# MAIN
# ========================================

New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
New-Item -ItemType Directory -Path $MiningDir -Force | Out-Null

$legacyCleanup = @(
    "GITHUB-README.md", ".env",
    "start-mining.bat", "stop-mining.bat", "config.json"
)
$legacyDirs = @("node_modules", "logs", "client", "script", "attached_assets", "stratum-server", "cloudflared")
foreach ($coin in $CoinOrder) {
    $cl = $coin.ToLower()
    $legacyCleanup += "install-$cl-core.ps1"
    $legacyCleanup += "INSTALL-$($coin)-CORE.bat"
    $legacyCleanup += "start-mining-$cl.bat"
    $legacyCleanup += "config-$cl.json"
    $legacyCleanup += "config.$cl"
}
$removedCount = 0
foreach ($file in $legacyCleanup) {
    $legacyPath = Join-Path $InstallDir $file
    if (Test-Path $legacyPath) {
        Remove-Item $legacyPath -Force -ErrorAction SilentlyContinue
        $removedCount++
    }
}
foreach ($dir in $legacyDirs) {
    $legacyPath = Join-Path $InstallDir $dir
    if (Test-Path $legacyPath) {
        Remove-Item $legacyPath -Recurse -Force -ErrorAction SilentlyContinue
        $removedCount++
    }
}
$legacyInstallMining = Join-Path $InstallDir "install-mining.ps1"
if (Test-Path $legacyInstallMining) {
    Remove-Item $legacyInstallMining -Force -ErrorAction SilentlyContinue
    $removedCount++
}
$legacyInstallMiningBat = Join-Path $InstallDir "INSTALL-MINING.bat"
if (Test-Path $legacyInstallMiningBat) {
    Remove-Item $legacyInstallMiningBat -Force -ErrorAction SilentlyContinue
    $removedCount++
}
$legacyUninstall = Join-Path $InstallDir "uninstall.ps1"
if (Test-Path $legacyUninstall) {
    Remove-Item $legacyUninstall -Force -ErrorAction SilentlyContinue
    $removedCount++
}
$legacyUninstallBat = Join-Path $InstallDir "UNINSTALL.bat"
if (Test-Path $legacyUninstallBat) {
    Remove-Item $legacyUninstallBat -Force -ErrorAction SilentlyContinue
    $removedCount++
}
if ($removedCount -gt 0) {
    Write-Host "  Cleaned up $removedCount legacy file(s) from previous install" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Solo Mining Setup" -ForegroundColor Yellow
Write-Host "  SHA-256 Multi-Coin HammerForge" -ForegroundColor Yellow
Write-Host "  BC2 | DGB | BTC | BCH | BSV | XEC | FB | PPC | LCC | NITO" -ForegroundColor Yellow
Write-Host "  All coins can run at the same time!" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Stratum Ports:" -ForegroundColor Gray
foreach ($coinKey in $CoinOrder) {
    $cfg = $CoinConfig[$coinKey]
    Write-Host "    $($cfg.ShortLabel.PadRight(4)) -> port $($cfg.StratumPort)" -ForegroundColor Gray
}
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  REMOTE ACCESS (Optional - Tailscale)" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  To monitor mining from your phone or from work," -ForegroundColor White
Write-Host "  install Tailscale BEFORE running this installer:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Download: https://tailscale.com/download/windows" -ForegroundColor Cyan
Write-Host "  2. Install Tailscale and sign in (free account)" -ForegroundColor Gray
Write-Host "  3. Make sure Tailscale is connected (icon in system tray)" -ForegroundColor Gray
Write-Host "  4. Install the Tailscale app on your phone and sign in" -ForegroundColor Gray
Write-Host "     with the same account" -ForegroundColor Gray
Write-Host ""
Write-Host "  If Tailscale is not installed before this setup runs," -ForegroundColor Red
Write-Host "  remote access will NOT be configured." -ForegroundColor Red
Write-Host "  You can re-run this installer after installing Tailscale." -ForegroundColor Yellow
Write-Host ""
Write-Host "  Without Tailscale, the monitor is only accessible" -ForegroundColor Gray
Write-Host "  on your home network (LAN)." -ForegroundColor Gray
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "WARNING: Running without Administrator privileges." -ForegroundColor Red
    Write-Host "  Node.js install and firewall rules will be skipped." -ForegroundColor Yellow
    Write-Host "  Right-click INSTALL-MINING.bat > Run as administrator" -ForegroundColor Yellow
    Write-Host ""
}

# Step 1: Check/Install Node.js
Write-Host "[1/7] Checking for Node.js..." -ForegroundColor Yellow
if (-not (Test-NodeJS)) {
    if (Test-Administrator) {
        $installNode = Install-NodeJS
        if (-not $installNode) {
            Write-Host "  Cannot continue without Node.js." -ForegroundColor Red
            Read-Host "Press Enter to exit"
            exit 1
        }
    } else {
        Write-Host "  ERROR: Node.js not found (admin required for auto-install)." -ForegroundColor Red
        Write-Host "  Download from https://nodejs.org (LTS version)" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
}


Write-Host "`n[1b/7] Checking remote access (Tailscale)..." -ForegroundColor Yellow
$tailscaleAvailable = Check-Tailscale
# Step 2: Check for coin nodes
Write-Host "`n[2/7] Checking for coin nodes..." -ForegroundColor Yellow

$coinExePaths = @{}
$anyNodeFound = $false

foreach ($coinKey in $CoinOrder) {
    $cfg = $CoinConfig[$coinKey]
    $info = Find-CoinExecutable -Coin $coinKey
    if ($info) {
        Write-Host "  $($cfg.NodeLabel) DETECTED at: $($info.Dir)" -ForegroundColor Green
        $coinExePaths[$coinKey] = $info.Exe
        $anyNodeFound = $true

        try {
            $procNames = @(($cfg.QtExe -replace '\.exe$',''), ($cfg.DaemonExe -replace '\.exe$',''))
            $running = Get-Process -Name $procNames -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($running) {
                Write-Host "    Status: RUNNING (PID $($running.Id))" -ForegroundColor Green
            } else {
                Write-Host "    Status: Not currently running" -ForegroundColor Gray
            }
        } catch {}

        $dataCheck = "$env:APPDATA\$($cfg.DataDirName)"
        if (Test-Path $dataCheck) {
            $blocksCheck = Join-Path $dataCheck "blocks"
            if (Test-Path $blocksCheck) {
                Write-Host "    Blockchain: Found (synced or syncing)" -ForegroundColor Green
            } else {
                Write-Host "    Blockchain: Not yet synced" -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host "  $($cfg.NodeLabel) not found (run $($cfg.InstallerBat) first)" -ForegroundColor Yellow
        $coinExePaths[$coinKey] = $null
    }
}

if (-not $anyNodeFound) {
    Write-Host ""
    Write-Host "  WARNING: No coin nodes found." -ForegroundColor Red
    Write-Host "  Install at least one wallet first." -ForegroundColor Yellow
    $continue = Read-Host "  Continue anyway? (y/n)"
    if ($continue -ne "y") {
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Step 3: Get wallet addresses (only for detected nodes)
Write-Host "`n[3/7] Wallet configuration..." -ForegroundColor Yellow

$detectedCoins = @()
foreach ($coinKey in $CoinOrder) {
    if ($coinExePaths[$coinKey]) {
        $detectedCoins += $coinKey
    }
}

if ($detectedCoins.Count -eq 0) {
    Write-Host "  No coin nodes detected. Skipping wallet setup." -ForegroundColor Yellow
} else {
    $coinList = ($detectedCoins | ForEach-Object { $CoinConfig[$_].ShortLabel }) -join ", "
    Write-Host "  Detected nodes: $coinList" -ForegroundColor Green
    Write-Host "  Enter wallet address for each coin. Press Enter to skip." -ForegroundColor Gray
}

$walletAddresses = @{
    BC2 = $BC2WalletAddress
    DGB = $DGBWalletAddress
    BTC = $BTCWalletAddress
    BCH = $BCHWalletAddress
    BSV = $BSVWalletAddress
    XEC = $XECWalletAddress
    FB  = $FBWalletAddress
    PPC  = $PPCWalletAddress
    LCC  = $LCCWalletAddress
    NITO = $NITOWalletAddress
}
$rpcUsers = @{
    BC2 = $BC2RpcUser; DGB = $DGBRpcUser; BTC = $BTCRpcUser
    BCH = $BCHRpcUser; BSV = $BSVRpcUser; XEC = $XECRpcUser
    FB  = $FBRpcUser;  PPC = $PPCRpcUser; LCC = $LCCRpcUser
    NITO = $NITORpcUser
}
$rpcPasswords = @{
    BC2 = $BC2RpcPassword; DGB = $DGBRpcPassword; BTC = $BTCRpcPassword
    BCH = $BCHRpcPassword; BSV = $BSVRpcPassword; XEC = $XECRpcPassword
    FB  = $FBRpcPassword;  PPC = $PPCRpcPassword; LCC = $LCCRpcPassword
    NITO = $NITORpcPassword
}
$setupCoins = @{}
$skipReconfigure = @{}

foreach ($coinKey in $CoinOrder) {
    $cfg = $CoinConfig[$coinKey]
    if (-not $cfg) { continue }

    if (-not $coinExePaths[$coinKey]) {
        $setupCoins[$coinKey] = $false
        continue
    }

    $existingConfigPath = Join-Path $InstallDir "config-$($coinKey.ToLower()).json"
    $existingBatPath = Join-Path $MiningDir "start-mining-$($coinKey.ToLower()).bat"
    if ((Test-Path $existingConfigPath) -and (Test-Path $existingBatPath)) {
        $existingJson = Get-Content $existingConfigPath -Raw -ErrorAction SilentlyContinue
        $existingCfg = $null
        try { $existingCfg = $existingJson | ConvertFrom-Json } catch {}
        if ($existingCfg -and $existingCfg.walletAddress) {
            Write-Host "" -ForegroundColor White
            Write-Host "  --- $($cfg.Label) ---" -ForegroundColor Cyan
            Write-Host "  Already configured (wallet: $($existingCfg.walletAddress))" -ForegroundColor Green
            $reconfigure = Read-Host "  Reconfigure? (y=reconfigure / Enter=keep existing)"
            if ($reconfigure -ne "y") {
                $setupCoins[$coinKey] = $false
                $skipReconfigure[$coinKey] = $true
                Write-Host "  Keeping existing $($cfg.ShortLabel) setup (no changes)" -ForegroundColor Gray
                continue
            }
        }
    }

    if (-not $walletAddresses[$coinKey]) {
        Write-Host ""
        Write-Host "  --- $($cfg.Label) ---" -ForegroundColor Cyan
        Write-Host "  $($cfg.AddrHint)" -ForegroundColor Gray
        $walletAddresses[$coinKey] = Read-Host "  $($cfg.ShortLabel) wallet address"
    }
    if ($walletAddresses[$coinKey]) {
        $setupCoins[$coinKey] = $true
        Write-Host "  $($cfg.ShortLabel) Wallet: $($walletAddresses[$coinKey])" -ForegroundColor Green
    } else {
        $setupCoins[$coinKey] = $false
        Write-Host "  Skipping $($cfg.ShortLabel)" -ForegroundColor Gray
    }
}

$anySetup = $setupCoins.Values | Where-Object { $_ -eq $true }
$anyExisting = $skipReconfigure.Values | Where-Object { $_ -eq $true }
if (-not $anySetup -and -not $anyExisting) {
    Write-Host ""
    Write-Host "  ERROR: At least one wallet address is required." -ForegroundColor Red
    Write-Host "  Install a coin wallet first, then re-run this installer." -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}
if (-not $anySetup -and $anyExisting) {
    Write-Host ""
    Write-Host "  All configured coins kept as-is. No new coins to set up." -ForegroundColor Green
    Write-Host "  Your existing mining setup is preserved." -ForegroundColor Gray
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Green
    Write-Host "  EXISTING SETUP PRESERVED" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  No changes were made to your mining configuration." -ForegroundColor White
    Write-Host "  Your blockchain data, wallet history, and settings are intact." -ForegroundColor Gray
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 0
}

# Step 4: Email notification setup
Write-Host "`n[4/7] Email notifications (optional)..." -ForegroundColor Yellow
Write-Host "  Get notified by email when you find a block!" -ForegroundColor Gray
Write-Host ""
$emailSetup = Read-Host "  Set up email notifications? (y/n)"
$emailEnabled = $false
$emailSmtpHost = ""
$emailSmtpPort = 587
$emailSmtpUser = ""
$emailSmtpPass = ""
$emailTo = ""
$emailUseTls = $true

if ($emailSetup -eq "y") {
    Write-Host ""
    Write-Host "  SMTP Presets:" -ForegroundColor White
    Write-Host "    1. Gmail      (smtp.gmail.com)" -ForegroundColor Gray
    Write-Host "    2. Outlook    (smtp.office365.com)" -ForegroundColor Gray
    Write-Host "    3. Yahoo      (smtp.mail.yahoo.com)" -ForegroundColor Gray
    Write-Host "    4. Custom SMTP server" -ForegroundColor Gray
    Write-Host ""
    $smtpChoice = Read-Host "  Choose (1-4)"
    switch ($smtpChoice) {
        "1" { $emailSmtpHost = "smtp.gmail.com"; $emailSmtpPort = 587 }
        "2" { $emailSmtpHost = "smtp.office365.com"; $emailSmtpPort = 587 }
        "3" { $emailSmtpHost = "smtp.mail.yahoo.com"; $emailSmtpPort = 587 }
        "4" {
            $emailSmtpHost = Read-Host "  SMTP host"
            $portInput = Read-Host "  SMTP port (default 587)"
            if ($portInput) { $emailSmtpPort = [int]$portInput }
        }
        default { $emailSmtpHost = "smtp.gmail.com"; $emailSmtpPort = 587 }
    }

    $emailSmtpUser = Read-Host "  Email address (login)"
    $emailSmtpPass = Read-Host "  App password"
    $emailToInput = Read-Host "  Send notifications to (default: same as login)"
    if ($emailToInput) {
        $emailTo = $emailToInput
    } else {
        $emailTo = $emailSmtpUser
    }

    if ($emailSmtpUser -and $emailSmtpPass -and $emailSmtpHost) {
        $emailEnabled = $true
        Write-Host "  Email notifications enabled!" -ForegroundColor Green
        Write-Host "  Notifications will be sent to: $emailTo" -ForegroundColor Gray
    } else {
        Write-Host "  Incomplete email config -- skipping." -ForegroundColor Yellow
    }
} else {
    Write-Host "  Skipping email notifications." -ForegroundColor Gray
}

# Step 5: Configure RPC for each coin
Write-Host "`n[5/7] Configuring RPC..." -ForegroundColor Yellow

$runningWallets = @()
$runningProcs = @{}
foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }
    if ($skipReconfigure[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    if ($cfg -and $cfg.ExeNames) {
        foreach ($exeName in $cfg.ExeNames) {
            $proc = Get-Process -Name ($exeName -replace ".exe$","") -ErrorAction SilentlyContinue
            if ($proc) {
                $runningWallets += $cfg.ShortLabel
                $runningProcs[$coinKey] = $proc
                break
            }
        }
    }
}
if ($runningWallets.Count -gt 0) {
    $walletList = $runningWallets -join ", "
    Write-Host "" -ForegroundColor Red
    Write-Host "  ============================================" -ForegroundColor Red
    Write-Host "  IMPORTANT: Running wallets detected!" -ForegroundColor Red
    Write-Host "  ============================================" -ForegroundColor Red
    Write-Host "  Running: $walletList" -ForegroundColor Yellow
    Write-Host "" -ForegroundColor Yellow
    Write-Host "  These wallets MUST be closed so the installer" -ForegroundColor Yellow
    Write-Host "  can write matching RPC credentials." -ForegroundColor Yellow
    Write-Host "" -ForegroundColor Yellow
    Write-Host "  The batch file will restart them automatically." -ForegroundColor Gray
    Write-Host "" -ForegroundColor Gray
    $closeChoice = Read-Host "  Close them now automatically? (y/n)"
    if ($closeChoice -eq "y") {
        foreach ($coinKey in $runningProcs.Keys) {
            $proc = $runningProcs[$coinKey]
            $procName = $proc.Name
            Write-Host "  Closing $procName..." -ForegroundColor Yellow
            $proc | ForEach-Object { $_.CloseMainWindow() | Out-Null }
            Start-Sleep -Seconds 3
            $stillRunning = Get-Process -Name $procName -ErrorAction SilentlyContinue
            if ($stillRunning) {
                $stillRunning | Stop-Process -Force -ErrorAction SilentlyContinue
                Write-Host "  Force-closed $procName" -ForegroundColor Yellow
            } else {
                Write-Host "  $procName closed" -ForegroundColor Green
            }
        }
        Start-Sleep -Seconds 2
    } else {
        Write-Host "  Please close the wallets manually, then press Enter." -ForegroundColor Yellow
        Read-Host "  Press Enter after closing the wallet(s)"
    }
}
$asciiEnc = New-Object System.Text.ASCIIEncoding

foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }

    $cfg = $CoinConfig[$coinKey]
    $rpcUser = $rpcUsers[$coinKey]
    $rpcPass = $rpcPasswords[$coinKey]

    if (-not $rpcUser) { $rpcUser = $cfg.DefaultRpcUser }
    if (-not $rpcPass) {
        $dataDir = Find-CoinDataDir -Coin $coinKey
        $existingConf = Join-Path $dataDir $cfg.ConfName
        if (Test-Path $existingConf) {
            $confContent = Get-Content $existingConf -ErrorAction SilentlyContinue
            foreach ($line in $confContent) {
                if ($line -match '^\s*rpcuser\s*=\s*(.+)$') {
                    $existingUser = $matches[1].Trim()
                    if ($existingUser) { $rpcUser = $existingUser }
                }
                if ($line -match '^\s*rpcpassword\s*=\s*(.+)$') {
                    $existingPass = $matches[1].Trim()
                    if ($existingPass) { $rpcPass = $existingPass }
                }
            }
            if ($rpcPass) {
                Write-Host "  $($cfg.ShortLabel): Reusing existing RPC credentials from $existingConf" -ForegroundColor Gray
            }
        }
        if (-not $rpcPass) {
            $rpcPass = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 24 | ForEach-Object { [char]$_ })
        }
    }
    $rpcUsers[$coinKey] = $rpcUser
    $rpcPasswords[$coinKey] = $rpcPass

    $dataDir = Find-CoinDataDir -Coin $coinKey
    Configure-CoinNode -DataDir $dataDir -RpcUser $rpcUser -RpcPassword $rpcPass -Coin $coinKey

    $cfgHash = @{
        walletAddress = $walletAddresses[$coinKey]
        stratumPort = $cfg.StratumPort
        rpcHost = "127.0.0.1"
        rpcPort = $cfg.RpcPort
        rpcUser = $rpcUser
        rpcPassword = $rpcPass
        coin = $coinKey
        dataDir = $dataDir
    }
    if ($emailEnabled) {
        $cfgHash["email"] = @{
            enabled = $true
            smtpHost = $emailSmtpHost
            smtpPort = $emailSmtpPort
            smtpUser = $emailSmtpUser
            smtpPass = $emailSmtpPass
            to = $emailTo
            useTls = $emailUseTls
        }
    }
    $jsonCfg = $cfgHash | ConvertTo-Json -Depth 3
    $configFileName = "config-$($coinKey.ToLower()).json"
    $configFilePath = Join-Path $InstallDir $configFileName
    if (Test-Path $configFilePath) { Remove-Item $configFilePath -Force -ErrorAction SilentlyContinue }
    Write-Host "    DEBUG: Writing rpcPort=$($cfg.RpcPort) for $coinKey" -ForegroundColor Magenta
    [System.IO.File]::WriteAllText($configFilePath, $jsonCfg, $asciiEnc)
    Write-Host "  $($cfg.ShortLabel) config saved: $configFilePath" -ForegroundColor Green
    Write-Host "    Stratum port: $($cfg.StratumPort), RPC port: $($cfg.RpcPort), P2P port: $($cfg.P2PPort)" -ForegroundColor Gray
    $verifyJson = Get-Content $configFilePath -Raw -ErrorAction SilentlyContinue
    if ($verifyJson -match "rpcPort.*$($cfg.RpcPort)") {
        Write-Host "    Verified: rpcPort=$($cfg.RpcPort) in JSON" -ForegroundColor Green
    } else {
        Write-Host "    WARNING: rpcPort may be wrong in $configFilePath" -ForegroundColor Red
        Write-Host "    Expected rpcPort=$($cfg.RpcPort). File contents:" -ForegroundColor Red
        Write-Host $verifyJson -ForegroundColor Yellow
    }
}

$restartNeeded = @()
foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    foreach ($exeName in $cfg.ExeNames) {
        $proc = Get-Process -Name ($exeName -replace '\.exe$','') -ErrorAction SilentlyContinue
        if ($proc) {
            $restartNeeded += $cfg.ShortLabel
            break
        }
    }
}
if ($restartNeeded.Count -gt 0) {
    $restartList = $restartNeeded -join ", "
    Write-Host ""
    Write-Host "  *** IMPORTANT: Restart these wallets to load new RPC settings ***" -ForegroundColor Red
    Write-Host "  Running nodes: $restartList" -ForegroundColor Yellow
    Write-Host "  Close them now, then press Enter. They will auto-start with mining." -ForegroundColor Yellow
    Read-Host "  Press Enter after closing"
}

# Step 5: Install npm dependencies
Write-Host "`n[6/7] Installing stratum server dependencies..." -ForegroundColor Yellow
Write-Host "  Directory: $InstallDir" -ForegroundColor Gray

$savedNodeEnv = $env:NODE_ENV
$env:NODE_ENV = $null
Push-Location $InstallDir
$npmOutput = & npm install 2>&1
$npmExit = $LASTEXITCODE
Pop-Location
$env:NODE_ENV = $savedNodeEnv

if ($npmExit -ne 0) {
    Write-Host "  WARNING: npm install returned exit code $npmExit" -ForegroundColor Yellow
    $npmOutput | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
    Write-Host "  Retrying npm install..." -ForegroundColor Yellow
    Push-Location $InstallDir
    & npm install 2>&1 | Out-Null
    Pop-Location
} else {
    Write-Host "  Dependencies installed successfully" -ForegroundColor Green
}

Push-Location $InstallDir
$tsxCheck = & npx tsx --version 2>&1
Pop-Location
if ($LASTEXITCODE -ne 0) {
    Write-Host "  tsx not found, installing explicitly..." -ForegroundColor Yellow
    Push-Location $InstallDir
    & npm install tsx 2>&1 | Out-Null
    Pop-Location
    Write-Host "  tsx installed" -ForegroundColor Green
} else {
    Write-Host "  tsx verified: $tsxCheck" -ForegroundColor Green
}

# Step 6: Firewall, batch files, shortcuts
Write-Host "`n[7/7] Firewall, batch files, desktop shortcuts..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path "$InstallDir\logs" -Force | Out-Null

if (Test-Administrator) {
    foreach ($coinKey in $CoinOrder) {
        if (-not $setupCoins[$coinKey]) { continue }
        $cfg = $CoinConfig[$coinKey]
        $ruleName = "HammerForge $($cfg.ShortLabel) Stratum (Port $($cfg.StratumPort))"
        $existingRule = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
        if ($existingRule) { Remove-NetFirewallRule -DisplayName $ruleName }
        New-NetFirewallRule -DisplayName $ruleName `
            -Direction Inbound -Protocol TCP -LocalPort $cfg.StratumPort `
            -Action Allow -Profile Private,Domain `
            -Description "Allow miners and NiceHash to connect to $($cfg.ShortLabel) stratum" | Out-Null
        Write-Host "  Firewall: Allow TCP $($cfg.StratumPort) ($($cfg.ShortLabel))" -ForegroundColor Green
    }

    $monitorRuleName = "HammerForge Mining Monitor (Ports 5000-5011)"
    $existingMonitor = Get-NetFirewallRule -DisplayName $monitorRuleName -ErrorAction SilentlyContinue
    if ($existingMonitor) { Remove-NetFirewallRule -DisplayName $monitorRuleName }
    New-NetFirewallRule -DisplayName $monitorRuleName `
        -Direction Inbound -Protocol TCP -LocalPort 5000-5011 `
        -Action Allow -Profile Any `
        -Description "Allow remote access to HammerForge web mining monitors (one per coin)" | Out-Null
    Write-Host "  Firewall: Allow TCP 5000-5011 (Mining Monitors - one per coin)" -ForegroundColor Green
} else {
    Write-Host "  Skipping firewall (requires Administrator)" -ForegroundColor Gray
}

$desktopPath = [Environment]::GetFolderPath("Desktop")
$shell = New-Object -ComObject WScript.Shell

$shortcutsCreated = 0
foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    if (-not $cfg) {
        Write-Host "  Skipping unknown coin: $coinKey" -ForegroundColor Yellow
        continue
    }
    $configFileName = "config-$($coinKey.ToLower()).json"

    Create-CoinBatchFile -Dir $MiningDir -ServerDir $InstallDir -Port $cfg.StratumPort -Wallet $walletAddresses[$coinKey] -CoinExePath $coinExePaths[$coinKey] -Coin $coinKey -ConfigFile $configFileName -RpcUser $rpcUsers[$coinKey] -RpcPass $rpcPasswords[$coinKey]

    $batchPath = Join-Path $MiningDir "start-mining-$($coinKey.ToLower()).bat"
    if (-not (Test-Path $batchPath)) {
        Write-Host "  ERROR: Batch file not created for $coinKey" -ForegroundColor Red
        continue
    }

    try {
        $shortcutPath = Join-Path $desktopPath "$($cfg.ShortLabel) HammerForge.lnk"
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $batchPath
        $shortcut.WorkingDirectory = $InstallDir
        $shortcut.Description = "Start $($cfg.ShortLabel) Solo Mining (port $($cfg.StratumPort))"
        $shortcut.Save()
        $shortcutsCreated++
        Write-Host "  Desktop shortcut: $($cfg.ShortLabel) HammerForge" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR creating shortcut for $coinKey : $_" -ForegroundColor Red
    }
}
if ($shortcutsCreated -eq 0) {
    Write-Host "  WARNING: No desktop shortcuts were created!" -ForegroundColor Red
    Write-Host "  Make sure you entered at least one wallet address." -ForegroundColor Yellow
} else {
    Write-Host "  $shortcutsCreated desktop shortcut(s) created" -ForegroundColor Green
}

foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    if (-not $cfg) { continue }
    try {
        $monitorUrlPath = Join-Path $desktopPath "$($cfg.ShortLabel) Monitor.url"
        $coinWebPort = 5000 + ($cfg.StratumPort - 3333)
        $urlContent = "[InternetShortcut]`r`nURL=http://localhost:$coinWebPort/monitor`r`nIconIndex=0`r`n"
        [System.IO.File]::WriteAllText($monitorUrlPath, $urlContent)
        Write-Host "  Desktop shortcut: $($cfg.ShortLabel) Monitor" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR creating monitor shortcut for $coinKey : $_" -ForegroundColor Red
    }

    $oldLnk = Join-Path $desktopPath "$($cfg.ShortLabel) Monitor.lnk"
    if (Test-Path $oldLnk) { Remove-Item $oldLnk -Force }
}

# Done
$localIP = Get-LocalIP

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  MINING SETUP COMPLETE" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  All coins can run AT THE SAME TIME!" -ForegroundColor White
Write-Host "  Each has its own stratum port and process." -ForegroundColor Gray
Write-Host ""

foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey] -and -not $skipReconfigure[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    if ($skipReconfigure[$coinKey]) {
        Write-Host "  --- $($cfg.Label) [KEPT] ---" -ForegroundColor Green
        Write-Host "  Existing setup preserved (no changes made)" -ForegroundColor Gray
        Write-Host "" 
        continue
    }
    Write-Host "  --- $($cfg.Label) ---" -ForegroundColor Cyan
    Write-Host "  Shortcut:   $($cfg.ShortLabel) HammerForge" -ForegroundColor White
    Write-Host "  Monitor:    $($cfg.ShortLabel) Monitor (desktop shortcut)" -ForegroundColor White
    Write-Host "  LAN:        stratum+tcp://${localIP}:$($cfg.StratumPort)" -ForegroundColor White
    Write-Host "  NiceHash:   stratum+tcp://YOUR_PUBLIC_IP:$($cfg.StratumPort)" -ForegroundColor White
    $coinWebPort = 5000 + ($cfg.StratumPort - 3333)
    Write-Host "  Monitor:    http://${localIP}:${coinWebPort}/monitor" -ForegroundColor White
    Write-Host "  Worker:     $($walletAddresses[$coinKey]).MinerName" -ForegroundColor White
    Write-Host "  Password:   x" -ForegroundColor White
    Write-Host "  Algorithm:  SHA256 (select on NiceHash)" -ForegroundColor White
    Write-Host ""
}

Write-Host "  HOW TO START:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Make sure your coin nodes are running and synced" -ForegroundColor White
Write-Host "  2. Double-click the desktop shortcuts" -ForegroundColor White
Write-Host "     You can start ALL coins at the same time!" -ForegroundColor Green
Write-Host "  3. Your browser will open the mining monitor automatically" -ForegroundColor White
Write-Host "     Each coin has its own monitor port (5000-5011)" -ForegroundColor Cyan
    Write-Host "     Remote (Tailscale): If installed, URL shown in console when mining starts" -ForegroundColor Green
Write-Host "  4. Point your miners at the correct port:" -ForegroundColor White
foreach ($coinKey in $CoinOrder) {
    if (-not $setupCoins[$coinKey]) { continue }
    $cfg = $CoinConfig[$coinKey]
    Write-Host "     $($cfg.ShortLabel) miners  -> port $($cfg.StratumPort)" -ForegroundColor Cyan
}
Write-Host ""
Write-Host "  For NiceHash: port forward each stratum port on your router" -ForegroundColor Gray
Write-Host ""

Read-Host "Press Enter to exit"
