# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# DigiByte Core Wallet Installer
# Downloads and installs DigiByte Core from GitHub
# Double-click INSTALL-DGB-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "8.26.2"
$GithubRepo = "DigiByte-Core/digibyte"
$AssetPattern = "win64-setup\.exe$"
$DGBDefaultInstallDir = "$env:ProgramFiles\DigiByte"
$DGBDefaultDataDir = "$env:APPDATA\DigiByte"

Write-Host ""
Write-Host "  Default install location: $DGBDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Default data directory:   $DGBDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
$customInstall = Read-Host "  Use default locations? (Y=yes, N=choose custom) [Y]"
if ($customInstall -eq 'N' -or $customInstall -eq 'n') {
      $newInstallDir = Read-Host "  Enter install path (e.g. D:\Mining\DGB)"
      if ($newInstallDir -and $newInstallDir.Trim() -ne '') {
          $DGBDefaultInstallDir = $newInstallDir.Trim()
          Write-Host "  Install path set to: $DGBDefaultInstallDir" -ForegroundColor Green
      }
      $newDataDir = Read-Host "  Enter data directory (e.g. D:\MiningData\DGB) [press Enter for default]"
      if ($newDataDir -and $newDataDir.Trim() -ne '') {
          $DGBDefaultDataDir = $newDataDir.Trim()
          Write-Host "  Data directory set to: $DGBDefaultDataDir" -ForegroundColor Green
      }
  }

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Windows installer found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-DGBExecutable {
    $exeNames = @("digibyte-qt.exe", "digibyted.exe")
    $searchDirs = @(
        "$env:ProgramFiles\DigiByte",
        "${env:ProgramFiles(x86)}\DigiByte",
        "$env:LOCALAPPDATA\DigiByte",
        "$env:LOCALAPPDATA\Programs\DigiByte",
        "$env:APPDATA\DigiByte",
        "C:\DigiByte",
        "$env:ProgramFiles\DigiByte Core",
        "${env:ProgramFiles(x86)}\DigiByte Core",
        "$env:LOCALAPPDATA\Programs\DigiByte Core"
    )
    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = (Split-Path $binPath -Parent); Exe = $binPath }
            }
            $daemonPath = Join-Path $dir "daemon\$exe"
            if (Test-Path $daemonPath) {
                return @{ Dir = (Split-Path $daemonPath -Parent); Exe = $daemonPath }
            }
        }
    }

    $proc = Get-Process -Name "digibyte-qt","digibyted" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path) {
        return @{ Dir = (Split-Path $proc.Path -Parent); Exe = $proc.Path }
    }

    foreach ($drive in @("C","D","E")) {
        $searchRoot = "${drive}:\"
        if (-not (Test-Path $searchRoot)) { continue }
        $found = Get-ChildItem -Path $searchRoot -Filter "digibyte-qt.exe" -Recurse -Depth 4 -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            return @{ Dir = $found.DirectoryName; Exe = $found.FullName }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  DigiByte Core Wallet Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-DGB-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing DigiByte installation..." -ForegroundColor Yellow
$existing = Find-DGBExecutable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  DigiByte Core already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  DigiByte Core not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~5 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain (~40+ GB)." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "digibyte-$FallbackVersion-win64-setup.exe"
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading DigiByte Core $useTag..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "dgbsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $exePath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $exePath)
        $sizeMB = [math]::Round((Get-Item $exePath).Length / 1MB, 1)
        Write-Host "  Downloaded DigiByte Core ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download DigiByte Core." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://github.com/$GithubRepo/releases" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Running DigiByte Core installer..." -ForegroundColor Yellow
    Write-Host "  The DigiByte installer window will open." -ForegroundColor Gray
    Write-Host "  Follow the prompts to complete installation." -ForegroundColor Gray
    Write-Host ""

    try {
        $proc = Start-Process -FilePath $exePath -PassThru -Wait
        if ($proc.ExitCode -eq 0) {
            Write-Host "  DigiByte Core installer completed successfully." -ForegroundColor Green
        } else {
            Write-Host "  DigiByte installer exited with code: $($proc.ExitCode)" -ForegroundColor Yellow
            Write-Host "  Installation may still be OK -- checking..." -ForegroundColor Gray
        }
    } catch {
        Write-Host "  ERROR: Failed to run installer." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Try running the installer manually:" -ForegroundColor Yellow
        Write-Host "  $exePath" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $exePath -ErrorAction SilentlyContinue
    }

    $installed = Find-DGBExecutable
    if ($installed) {
        $foundExe = $installed.Exe
        Write-Host "  Found DigiByte at: $($installed.Dir)" -ForegroundColor Green
    } else {
        Write-Host "  Could not locate DigiByte after install." -ForegroundColor Yellow
        Write-Host "  It may have installed to a custom location." -ForegroundColor Gray
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $DGBDefaultDataDir)) {
    New-Item -ItemType Directory -Path $DGBDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $DGBDefaultDataDir" -ForegroundColor Green
}

$confPath = Join-Path $DGBDefaultDataDir "digibyte.conf"
if (Test-Path $confPath) {
    $backup = "$confPath.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    Copy-Item $confPath $backup -Force -ErrorAction SilentlyContinue
    Write-Host "  Found existing config: $confPath" -ForegroundColor Gray
    Write-Host "  Backed up to: $backup" -ForegroundColor Gray
}
if ($pruneEnabled) {
    $pruneValue = "prune=5000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in digibyte.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing digibyte.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created digibyte.conf with pruning enabled (~5 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "DigiByte Core.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "DigiByte Core Wallet"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: DigiByte Core" -ForegroundColor Green
}

$firewallRuleName = "DigiByte Core P2P (Port 12024)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 12024 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow DigiByte Core peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 12024" -ForegroundColor Green

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  DigiByte Core READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
if ($foundExe) {
    Write-Host "  Installed at: $(Split-Path $foundExe -Parent)" -ForegroundColor Cyan
}
Write-Host "  Data folder:  $DGBDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NOTE: This server mines DigiByte using the SHA-256" -ForegroundColor White
Write-Host "  algorithm only. DGB has 5 algorithms but this solo" -ForegroundColor White
Write-Host "  miner targets SHA-256 blocks exclusively." -ForegroundColor White
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Open DigiByte Core from your Desktop or Start Menu" -ForegroundColor Yellow
Write-Host "     to start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for DGB SHA-256 solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from DigiByte Core:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host "       (Address will start with D, S, or dgb1q)" -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start DigiByte Core now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting DigiByte Core..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$DGBDefaultDataDir`"", "-conf=digibyte.conf"
    Write-Host "  DigiByte Core is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
