@echo off
echo ============================================
echo   DigiByte Core - Node Setup
echo ============================================
echo.
echo This will set up DigiByte Core for HammerForge mining.
echo If the node is already installed, only the config file
echo will be updated. No data will be deleted.
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0..\Mining\install-coin-core.ps1" -Coin DGB

pause
