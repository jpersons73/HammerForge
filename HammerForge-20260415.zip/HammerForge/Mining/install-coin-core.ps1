param([string]$Coin)

$CoinConfig = @{
    BC2  = @{ Label = "BC2 (BitcoinII)"; ShortLabel = "BC2"; ExeNames = @("bitcoinII-qt.exe", "bitcoin-qt.exe", "bitcoinIId.exe", "bitcoind.exe"); QtExe = "bitcoinII-qt.exe"; DaemonExe = "bitcoinIId.exe"; NodeLabel = "BitcoinII-Core"; DataDirName = "BitcoinII"; ConfName = "bitcoinII.conf"; RpcPort = 8232; P2PPort = 8338; DefaultRpcUser = "bc2rpc"; DownloadUrl = "https://github.com/Bitcoin-II/BitcoinII-Core/releases"; DownloadNote = "Download from GitHub: https://github.com/Bitcoin-II/BitcoinII-Core/releases"; GithubRepo = "Bitcoin-II/BitcoinII-Core" }
    DGB  = @{ Label = "DGB (DigiByte)"; ShortLabel = "DGB"; ExeNames = @("digibyte-qt.exe", "digibyted.exe"); QtExe = "digibyte-qt.exe"; DaemonExe = "digibyted.exe"; NodeLabel = "DigiByte Core"; DataDirName = "DigiByte"; ConfName = "digibyte.conf"; RpcPort = 14022; P2PPort = 12024; DefaultRpcUser = "dgbrpc"; DownloadUrl = "https://github.com/DigiByte-Core/digibyte/releases"; DownloadNote = "Download from: https://github.com/DigiByte-Core/digibyte/releases"; GithubRepo = "DigiByte-Core/digibyte" }
    BTC  = @{ Label = "BTC (Bitcoin)"; ShortLabel = "BTC"; ExeNames = @("bitcoin-qt.exe", "bitcoind.exe"); QtExe = "bitcoin-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin Core"; DataDirName = "Bitcoin"; ConfName = "bitcoin.conf"; RpcPort = 8332; P2PPort = 8333; DefaultRpcUser = "btcrpc"; DownloadUrl = "https://bitcoincore.org/en/download/"; DownloadNote = "Download from: https://bitcoincore.org/en/download/"; GithubRepo = "" }
    BCH  = @{ Label = "BCH (Bitcoin Cash)"; ShortLabel = "BCH"; ExeNames = @("bitcoin-cash-node-qt.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-cash-node-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin Cash Node"; DataDirName = "BitcoinCash"; ConfName = "bitcoin.conf"; RpcPort = 8432; P2PPort = 8433; DefaultRpcUser = "bchrpc"; DownloadUrl = "https://bitcoincashnode.org/"; DownloadNote = "Download from: https://bitcoincashnode.org/"; GithubRepo = "" }
    BSV  = @{ Label = "BSV (Bitcoin SV)"; ShortLabel = "BSV"; ExeNames = @("bitcoin-sv.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-sv.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Bitcoin SV Node"; DataDirName = "BitcoinSV"; ConfName = "bitcoin.conf"; RpcPort = 8532; P2PPort = 8533; DefaultRpcUser = "bsvrpc"; DownloadUrl = "https://github.com/bitcoin-sv/bitcoin-sv/releases"; DownloadNote = "Download from: https://github.com/bitcoin-sv/bitcoin-sv/releases"; GithubRepo = "bitcoin-sv/bitcoin-sv" }
    XEC  = @{ Label = "XEC (eCash)"; ShortLabel = "XEC"; ExeNames = @("bitcoin-abc-qt.exe", "bitcoind.exe", "bitcoin-qt.exe"); QtExe = "bitcoin-abc-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "eCash (Bitcoin ABC)"; DataDirName = "BitcoinABC"; ConfName = "bitcoin.conf"; RpcPort = 8632; P2PPort = 8633; DefaultRpcUser = "xecrpc"; DownloadUrl = "https://www.bitcoinabc.org/"; DownloadNote = "Download from: https://www.bitcoinabc.org/"; GithubRepo = "" }
    FB   = @{ Label = "FB (Fractal Bitcoin)"; ShortLabel = "FB"; ExeNames = @("bitcoin-qt.exe", "bitcoind.exe"); QtExe = "bitcoin-qt.exe"; DaemonExe = "bitcoind.exe"; NodeLabel = "Fractal Bitcoin"; DataDirName = "FractalBitcoin"; ConfName = "bitcoin.conf"; RpcPort = 8732; P2PPort = 8733; DefaultRpcUser = "fbrpc"; DownloadUrl = "https://github.com/nicheofcrypto/fractal-bitcoin/releases"; DownloadNote = "Download from: https://github.com/nicheofcrypto/fractal-bitcoin/releases"; GithubRepo = "nicheofcrypto/fractal-bitcoin" }
    PPC  = @{ Label = "PPC (Peercoin)"; ShortLabel = "PPC"; ExeNames = @("peercoin-qt.exe", "peercoind.exe"); QtExe = "peercoin-qt.exe"; DaemonExe = "peercoind.exe"; NodeLabel = "Peercoin"; DataDirName = "Peercoin"; ConfName = "peercoin.conf"; RpcPort = 9902; P2PPort = 9901; DefaultRpcUser = "ppcrpc"; DownloadUrl = "https://www.peercoin.net/wallet"; DownloadNote = "Download from: https://www.peercoin.net/wallet"; GithubRepo = "" }
    LCC  = @{ Label = "LCC (Litecoin Cash)"; ShortLabel = "LCC"; ExeNames = @("litecoincash-qt.exe", "litecoincashd.exe"); QtExe = "litecoincash-qt.exe"; DaemonExe = "litecoincashd.exe"; NodeLabel = "Litecoin Cash"; DataDirName = "LitecoinCash"; ConfName = "litecoincash.conf"; RpcPort = 62457; P2PPort = 62458; DefaultRpcUser = "lccrpc"; DownloadUrl = "https://github.com/nicheofcrypto/Litecoin-Cash-Source/releases"; DownloadNote = "Download from: https://github.com/nicheofcrypto/Litecoin-Cash-Source/releases"; GithubRepo = "nicheofcrypto/Litecoin-Cash-Source" }
    NITO = @{ Label = "NITO (NitoCoin)"; ShortLabel = "NITO"; ExeNames = @("nito-qt.exe", "nitod.exe"); QtExe = "nito-qt.exe"; DaemonExe = "nitod.exe"; NodeLabel = "NitoCoin"; DataDirName = "Nito"; ConfName = "nito.conf"; RpcPort = 8821; P2PPort = 8820; DefaultRpcUser = "nitorpc"; DownloadUrl = "https://github.com/nicheofcrypto/NitoCoin/releases"; DownloadNote = "Download from: https://github.com/nicheofcrypto/NitoCoin/releases"; GithubRepo = "nicheofcrypto/NitoCoin" }
    BCH2 = @{ Label = "BCH2 (Bitcoin Cash II)"; ShortLabel = "BCH2"; ExeNames = @("bitcoincashII-qt.exe", "bitcoincashIId.exe"); QtExe = "bitcoincashII-qt.exe"; DaemonExe = "bitcoincashIId.exe"; NodeLabel = "Bitcoin Cash II"; DataDirName = "BitcoinCashII"; ConfName = "bitcoincashII.conf"; RpcPort = 8342; P2PPort = 8339; DefaultRpcUser = "bch2rpc"; DownloadUrl = "https://github.com/BitcoincashII/bitcoincashII-core/releases"; DownloadNote = "Download v27.0.2+ from: https://github.com/BitcoincashII/bitcoincashII-core/releases"; GithubRepo = "BitcoincashII/bitcoincashII-core" }
    XRO  = @{ Label = "XRO (XeroCoin)"; ShortLabel = "XRO"; ExeNames = @("xero-qt.exe", "xerod.exe"); QtExe = "xero-qt.exe"; DaemonExe = "xerod.exe"; NodeLabel = "XeroCoin"; DataDirName = "Xero"; ConfName = "xero.conf"; RpcPort = 25169; P2PPort = 25170; DefaultRpcUser = "xrorpc"; DownloadUrl = "https://github.com/nicheofcrypto/XeroCoin/releases"; DownloadNote = "Download from: https://github.com/nicheofcrypto/XeroCoin/releases"; GithubRepo = "nicheofcrypto/XeroCoin" }
}

function Download-LatestFromGithub {
    param($coinCfg)
    if (-not $coinCfg.GithubRepo) { return $false }
    $repo = $coinCfg.GithubRepo
    $apiUrl = "https://api.github.com/repos/$repo/releases/latest"
    try {
        Write-Host "  Fetching latest release from $repo..." -ForegroundColor Cyan
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $release = Invoke-RestMethod -Uri $apiUrl -UseBasicParsing -TimeoutSec 30
        $tagName = $release.tag_name
        Write-Host "  Latest version: $tagName" -ForegroundColor Green

        $setupAsset = $release.assets | Where-Object { $_.name -match "win64.*setup.*\.exe$" -or $_.name -match "win.*setup.*\.exe$" } | Select-Object -First 1
        $zipAsset = $release.assets | Where-Object { $_.name -match "win64.*\.zip$" -or $_.name -match "win.*\.zip$" } | Select-Object -First 1
        $asset = if ($setupAsset) { $setupAsset } elseif ($zipAsset) { $zipAsset } else { $null }

        if (-not $asset) {
            Write-Host "  No Windows installer found in release assets" -ForegroundColor Yellow
            Write-Host "  Available files:" -ForegroundColor Gray
            foreach ($a in $release.assets) {
                Write-Host "    - $($a.name)" -ForegroundColor Gray
            }
            return $false
        }

        $downloadUrl = $asset.browser_download_url
        $fileName = $asset.name
        $downloadDir = Join-Path $env:USERPROFILE "Downloads"
        $downloadPath = Join-Path $downloadDir $fileName

        Write-Host "  Downloading: $fileName" -ForegroundColor Cyan
        Write-Host "  Size: $([math]::Round($asset.size / 1MB, 1)) MB" -ForegroundColor Gray
        Write-Host "  Saving to: $downloadPath" -ForegroundColor Gray
        Write-Host ""

        $webClient = New-Object System.Net.WebClient
        $webClient.Headers.Add("User-Agent", "HammerForge-Installer")
        $webClient.DownloadFile($downloadUrl, $downloadPath)

        Write-Host "  Download complete!" -ForegroundColor Green

        if ($fileName -match "\.exe$") {
            Write-Host "  Launching installer: $fileName" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "  IMPORTANT: Close the wallet FIRST (File > Exit) before installing!" -ForegroundColor Yellow
            Write-Host ""
            Start-Process -FilePath $downloadPath
            Write-Host "  Installer launched. Follow the prompts to install/update." -ForegroundColor Green
        } elseif ($fileName -match "\.zip$") {
            Write-Host "  Downloaded ZIP: $downloadPath" -ForegroundColor Green
            Write-Host "  Extract it to C:\Program Files\$($coinCfg.NodeLabel)\ and replace existing files." -ForegroundColor White
            Write-Host ""
            Write-Host "  IMPORTANT: Close the wallet FIRST (File > Exit) before replacing files!" -ForegroundColor Yellow
        }
        return $true
    } catch {
        Write-Host "  GitHub API error: $_" -ForegroundColor Red
        return $false
    }
}

function Find-DataDirs {
    param($dirName)
    $dirs = @()
    $roaming = "$env:APPDATA\$dirName"
    $local = "$env:LOCALAPPDATA\$dirName"
    if (Test-Path $roaming) { $dirs += $roaming }
    if (Test-Path $local) { $dirs += $local }
    return $dirs
}

if (-not $Coin) {
    Write-Host "ERROR: No coin specified. Usage: install-coin-core.ps1 -Coin BTC" -ForegroundColor Red
    exit 1
}

$Coin = $Coin.ToUpper()
$cfg = $CoinConfig[$Coin]
if (-not $cfg) {
    Write-Host "ERROR: Unknown coin '$Coin'" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  $($cfg.Label) Node Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$nodeFound = $false
$nodeExePath = ""

foreach ($exeName in $cfg.ExeNames) {
    $found = Get-ChildItem -Path "C:\Program Files","C:\Program Files (x86)","$env:LOCALAPPDATA","$env:APPDATA" -Filter $exeName -Recurse -ErrorAction SilentlyContinue -Depth 4 | Select-Object -First 1
    if ($found) {
        $nodeExePath = $found.FullName
        $nodeFound = $true
        break
    }

    $whereResult = & where.exe $exeName 2>$null
    if ($whereResult) {
        $nodeExePath = $whereResult | Select-Object -First 1
        $nodeFound = $true
        break
    }
}

$existingDirs = Find-DataDirs $cfg.DataDirName
if ($existingDirs.Count -gt 0) {
    $dataDir = $existingDirs[0]
    Write-Host "  Found existing data directory: $dataDir" -ForegroundColor Green
} else {
    $dataDir = "$env:APPDATA\$($cfg.DataDirName)"
}

$rpcUser = $cfg.DefaultRpcUser
$rpcPass = ""
$hammerDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$configJsonPath = Join-Path $hammerDir "config-$($Coin.ToLower()).json"
if (-not (Test-Path $configJsonPath)) {
    $configJsonPath = Join-Path $PSScriptRoot "..\config-$($Coin.ToLower()).json"
}

if (Test-Path $configJsonPath) {
    try {
        $jsonContent = Get-Content $configJsonPath -Raw | ConvertFrom-Json
        if ($jsonContent.rpcUser) { $rpcUser = $jsonContent.rpcUser }
        if ($jsonContent.rpcPassword) { $rpcPass = $jsonContent.rpcPassword }
        Write-Host "  Read existing credentials from config-$($Coin.ToLower()).json" -ForegroundColor Green
    } catch {
        Write-Host "  Could not read config JSON, using defaults" -ForegroundColor Yellow
    }
}

if (-not $rpcPass) {
    $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    $rpcPass = -join (1..24 | ForEach-Object { $chars[(Get-Random -Minimum 0 -Maximum $chars.Length)] })
    Write-Host "  Generated new RPC password ($($rpcPass.Length) chars)" -ForegroundColor Yellow
}

if ($nodeFound) {
    Write-Host "  $($cfg.NodeLabel) is ALREADY INSTALLED" -ForegroundColor Green
    Write-Host "  Location: $nodeExePath" -ForegroundColor Gray
    Write-Host ""
    $updateChoice = Read-Host "  Download latest update from GitHub? (y/n)"
    if ($updateChoice -eq "y" -or $updateChoice -eq "Y") {
        Write-Host ""
        $result = Download-LatestFromGithub $cfg
        if (-not $result) {
            Write-Host "  Please download manually from:" -ForegroundColor Yellow
            Write-Host "  $($cfg.DownloadUrl)" -ForegroundColor Cyan
        }
        Write-Host ""
        Read-Host "  Press Enter after you have finished installing the update"
        Write-Host ""
    } else {
        Write-Host "  Skipping download - updating config only..." -ForegroundColor Cyan
        Write-Host ""
    }
} else {
    Write-Host "  $($cfg.NodeLabel) is NOT installed" -ForegroundColor Yellow
    Write-Host ""
    $result = Download-LatestFromGithub $cfg
    if ($result) {
        Write-Host ""
        Read-Host "  Press Enter after you have finished installing"
        Write-Host ""
    } else {
        Write-Host "  Please download and install it from:" -ForegroundColor White
        Write-Host "  $($cfg.DownloadNote)" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  After installing, run this script again to configure it." -ForegroundColor White
        Write-Host ""
        $response = Read-Host "  Continue to set up config anyway? (y/n)"
        if ($response -ne "y" -and $response -ne "Y") {
            Write-Host "  Setup cancelled. Install the node first, then re-run this script." -ForegroundColor Yellow
            exit 0
        }
    }
}

Write-Host "  ---- Config File Update ----" -ForegroundColor Cyan

$confLines = @(
    "server=1",
    "rpcuser=$rpcUser",
    "rpcpassword=$rpcPass",
    "rpcallowip=127.0.0.1",
    "rpcport=$($cfg.RpcPort)",
    "port=$($cfg.P2PPort)",
    "listen=1",
    "txindex=1",
    "maxconnections=40",
    "debug=0",
    "printtoconsole=0"
)
if ($Coin -eq "BC2") {
    $confLines += @(
        "dnsseed=1",
        "dns=1",
        "seednode=dnsseed.bitcoin-ii.org:8338",
        "seednode=bitcoinII.ddns.net:8338",
        "addnode=dnsseed.bitcoin-ii.org:8338",
        "addnode=bitcoinII.ddns.net:8338"
    )
}
if ($Coin -eq "BCH2") {
    $confLines += @(
        "dnsseed=1",
        "dns=1",
        "addnode=144.202.73.66:8339",
        "addnode=108.61.190.83:8339",
        "addnode=64.176.215.202:8339",
        "addnode=45.32.138.29:8339",
        "addnode=139.180.132.24:8339",
        "seednode=dnsseed1.bch2.org:8339",
        "seednode=dnsseed2.bch2.org:8339"
    )
}

$allDataDirs = @()
$roamingDir = "$env:APPDATA\$($cfg.DataDirName)"
$localDir = "$env:LOCALAPPDATA\$($cfg.DataDirName)"
if (Test-Path $roamingDir) { $allDataDirs += $roamingDir }
if (Test-Path $localDir) { $allDataDirs += $localDir }
if ($allDataDirs.Count -eq 0) {
    if (-not (Test-Path $roamingDir)) {
        New-Item -ItemType Directory -Path $roamingDir -Force | Out-Null
        Write-Host "  Created data directory: $roamingDir" -ForegroundColor Green
    }
    $allDataDirs += $roamingDir
}

Write-Host "  Writing config to $($allDataDirs.Count) data directory location(s):" -ForegroundColor Cyan

foreach ($dir in $allDataDirs) {
    $confPath = Join-Path $dir $cfg.ConfName
    Write-Host "    -> $confPath" -ForegroundColor Gray

    $confNeedsUpdate = $true
    if (Test-Path $confPath) {
        $existingConf = Get-Content $confPath -Raw -ErrorAction SilentlyContinue
        $userMatch = $existingConf -match "rpcuser=$([regex]::Escape($rpcUser))"
        $passMatch = $existingConf -match "rpcpassword=$([regex]::Escape($rpcPass))"
        $portMatch = $existingConf -match "rpcport=$($cfg.RpcPort)"

        if ($userMatch -and $passMatch -and $portMatch) {
            Write-Host "       Already has correct credentials - no changes needed" -ForegroundColor Green
            $confNeedsUpdate = $false
        } else {
            if (-not $userMatch) { Write-Host "       MISMATCH: rpcuser" -ForegroundColor Yellow }
            if (-not $passMatch) { Write-Host "       MISMATCH: rpcpassword" -ForegroundColor Yellow }
            if (-not $portMatch) { Write-Host "       MISMATCH: rpcport" -ForegroundColor Yellow }
        }
    }

    if ($confNeedsUpdate) {
        if (Test-Path $confPath) {
            $backup = "$confPath.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Copy-Item $confPath $backup -Force -ErrorAction SilentlyContinue
            Write-Host "       Backed up existing config to: $backup" -ForegroundColor Gray
        }

        try {
            $confLines | Out-File -FilePath $confPath -Encoding ASCII -Force
            Start-Sleep -Milliseconds 500
            $readBack = Get-Content $confPath -Raw -ErrorAction SilentlyContinue
            if ($readBack -and $readBack.Contains("server=1")) {
                Write-Host "       Config written OK" -ForegroundColor Green
            } else {
                Write-Host "       Auto-write may have failed" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "       Auto-write failed: $_" -ForegroundColor Red
        }
    }
}

$nodeRunning = $false
foreach ($exeName in $cfg.ExeNames) {
    $proc = Get-Process -Name ($exeName -replace '\.exe$','') -ErrorAction SilentlyContinue
    if ($proc) { $nodeRunning = $true; break }
}

if ($nodeRunning) {
    Write-Host ""
    Write-Host "  IMPORTANT: $($cfg.NodeLabel) is currently running." -ForegroundColor Yellow
    Write-Host "  The config file has been updated. To apply changes:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  1. Close the $($cfg.NodeLabel) wallet window normally (File > Exit)" -ForegroundColor White
    Write-Host "  2. Wait for it to shut down completely" -ForegroundColor White
    Write-Host "  3. Re-open the wallet from your Start Menu or desktop shortcut" -ForegroundColor White
    Write-Host ""
    Write-Host "  DO NOT use Task Manager to kill the node - this can corrupt" -ForegroundColor Red
    Write-Host "  the blockchain database and force a full re-sync." -ForegroundColor Red
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "  Config updated. Start $($cfg.NodeLabel) normally from your" -ForegroundColor Green
    Write-Host "  Start Menu or desktop shortcut to use the new settings." -ForegroundColor Green
    Write-Host ""
}

$primaryConfPath = Join-Path $allDataDirs[0] $cfg.ConfName
Write-Host ""
Write-Host "  ============================================" -ForegroundColor Cyan
Write-Host "  $($cfg.Label) CONFIG" -ForegroundColor Cyan
Write-Host "  ============================================" -ForegroundColor Cyan
Write-Host "  File: $primaryConfPath" -ForegroundColor Yellow
if ($allDataDirs.Count -gt 1) {
    Write-Host "  Also written to: $(Join-Path $allDataDirs[1] $cfg.ConfName)" -ForegroundColor Yellow
}
Write-Host "  ------------------------------------------" -ForegroundColor Gray
foreach ($ln in $confLines) {
    Write-Host "  $ln" -ForegroundColor Green
}
Write-Host "  ------------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "  Setup complete for $($cfg.Label)!" -ForegroundColor Green
Write-Host ""
