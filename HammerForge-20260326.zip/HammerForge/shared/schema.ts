// Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
// Proprietary and confidential. See LICENSE file for details.

import { z } from "zod";

export type CoinType = "BC2" | "DGB" | "BTC" | "BCH" | "BSV" | "XEC" | "FB" | "PPC" | "LCC" | "NITO";

export interface EmailConfig {
  enabled: boolean;
  smtpHost: string;
  smtpPort: number;
  smtpUser: string;
  smtpPass: string;
  to: string;
  useTls: boolean;
}

export interface MiningConfig {
  walletAddress: string;
  stratumPort: number;
  rpcHost: string;
  rpcPort: number;
  rpcUser: string;
  rpcPassword: string;
  coin: CoinType;
  email?: EmailConfig;
}

export interface Worker {
  id: string;
  name: string;
  minerType: string;
  ipAddress: string;
  connected: boolean;
  connectedAt: number;
  lastShareAt: number;
  sharesAccepted: number;
  sharesRejected: number;
  hashrate1m: number;
  hashrate5m: number;
  hashrate1hr: number;
  hashrate1d: number;
  bestDifficulty: number;
  bestDifficultyShare: string;
  colorIndex: number;
}

export interface ShareEntry {
  id: string;
  workerId: string;
  workerName: string;
  difficulty: number;
  targetDifficulty: number;
  accepted: boolean;
  timestamp: number;
  hash: string;
}

export interface NetworkStats {
  blockHeight: number;
  networkDifficulty: number;
  networkHashrate: number;
  coinPrice: number;
  bestShare: number;
  totalAccepted: number;
  totalRejected: number;
  uptime: number;
  connectedWorkers: number;
  totalHashrate: number;
}

export interface StratumStatus {
  running: boolean;
  port: number;
  connections: number;
  startedAt: number;
}

export interface DashboardData {
  workers: Worker[];
  recentShares: ShareEntry[];
  networkStats: NetworkStats;
  stratumStatus: StratumStatus;
}

export interface HashrateSnapshot {
  timestamp: number;
  hashrate: number;
  workers: number;
  accepted: number;
  rejected: number;
  bestShare: number;
}

export interface BestShareEntry {
  timestamp: number;
  difficulty: number;
}

export interface BlockFoundEntry {
  coin: string;
  height: number;
  hash: string;
  reward: string;
  difficulty: string;
  worker: string;
  workerIp: string;
  timestamp: string;
  status: string;
}

export interface MonitorData {
  config: {
    coin: string;
    walletAddress: string;
    stratumPort: number;
    algoNote: string;
  };
  workers: Worker[];
  recentShares: ShareEntry[];
  networkStats: NetworkStats;
  stratumStatus: StratumStatus;
  hashrateHistory: HashrateSnapshot[];
  bestShareHistory: BestShareEntry[];
  blocksFound: BlockFoundEntry[];
}

export const miningConfigSchema = z.object({
  walletAddress: z.string().min(1, "Wallet address is required"),
  stratumPort: z.number().min(1024).max(65535).default(3333),
  rpcHost: z.string().default("127.0.0.1"),
  rpcPort: z.number().default(8332),
  rpcUser: z.string().default("bc2rpc"),
  rpcPassword: z.string().default("bc2rpcpassword"),
  coin: z.enum(["BC2", "DGB", "BTC", "BCH", "BSV", "XEC", "FB", "PPC", "LCC", "NITO"]).default("BC2"),
});

export type MiningConfigInput = z.infer<typeof miningConfigSchema>;

export const addWorkerSchema = z.object({
  name: z.string().min(1, "Worker name is required").max(50),
  minerType: z.string().min(1, "Miner type is required").max(30),
  ipAddress: z.string().default("manual"),
});

export type AddWorkerInput = z.infer<typeof addWorkerSchema>;

export const renameWorkerSchema = z.object({
  name: z.string().min(1, "Worker name is required").max(50),
});

export type RenameWorkerInput = z.infer<typeof renameWorkerSchema>;
