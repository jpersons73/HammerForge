@echo off
echo ============================================
echo   NitoCoin Wallet Installer
echo ============================================
echo.
echo This will download and install NitoCoin
echo from github.com/NitoNetwork/Nito-core
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-nito-core.ps1"

pause
