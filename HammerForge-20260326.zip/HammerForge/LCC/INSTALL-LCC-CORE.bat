@echo off
echo ============================================
echo   Litecoin Cash Wallet Installer
echo ============================================
echo.
echo This will download and install Litecoin Cash
echo from github.com/litecoincash-project/litecoincash
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-lcc-core.ps1"

pause
