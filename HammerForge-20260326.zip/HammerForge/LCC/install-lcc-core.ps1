# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Litecoin Cash Wallet Installer
# Downloads and installs Litecoin Cash from GitHub
# Double-click INSTALL-LCC-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "0.16.3"
$FallbackZipName = "litecoincash-0.16.3-win64.zip"
$GithubRepo = "litecoincash-project/litecoincash"
$AssetPattern = "win64\.zip$"
$LCCDefaultInstallDir = "$env:ProgramFiles\LitecoinCash"
$LCCDefaultDataDir = "$env:APPDATA\LitecoinCash"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern -and $asset.name -notmatch "setup") {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Windows zip found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-LCCExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\LitecoinCash",
        "${env:ProgramFiles(x86)}\LitecoinCash",
        "$env:LOCALAPPDATA\LitecoinCash",
        "C:\LitecoinCash",
        "$env:ProgramFiles\Litecoin Cash"
    )
    $exeNames = @("litecoincash-qt.exe", "litecoincashd.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Litecoin Cash Wallet Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-LCC-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing Litecoin Cash installation..." -ForegroundColor Yellow
$existing = Find-LCCExecutable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Litecoin Cash already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Litecoin Cash not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~2 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = $FallbackZipName
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading Litecoin Cash $useTag..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "lccsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $zipPath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $zipPath)
        $sizeMB = [math]::Round((Get-Item $zipPath).Length / 1MB, 1)
        Write-Host "  Downloaded Litecoin Cash ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download Litecoin Cash." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://github.com/$GithubRepo/releases" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Installing Litecoin Cash..." -ForegroundColor Yellow
    $extractDir = Join-Path $tempDir "lcc-extract"

    try {
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
        Write-Host "  Extracting archive..." -ForegroundColor Gray
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

        $innerDir = Get-ChildItem $extractDir | Select-Object -First 1
        $sourceDir = $innerDir.FullName

        if (Test-Path $LCCDefaultInstallDir) {
            $backup = "$LCCDefaultInstallDir.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Write-Host "  Backing up existing install to: $backup" -ForegroundColor Gray
            Rename-Item $LCCDefaultInstallDir $backup
        }

        New-Item -ItemType Directory -Path $LCCDefaultInstallDir -Force | Out-Null
        Copy-Item "$sourceDir\*" $LCCDefaultInstallDir -Recurse -Force

        $exeNames = @("litecoincash-qt.exe", "litecoincashd.exe")
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $LCCDefaultInstallDir $exe
            if (Test-Path $testPath) { $foundExe = $testPath; break }
            $binPath = Join-Path $LCCDefaultInstallDir "bin\$exe"
            if (Test-Path $binPath) { $foundExe = $binPath; break }
        }

        if ($foundExe) {
            Write-Host "  Installed to: $LCCDefaultInstallDir" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Files extracted but executable not found in expected location." -ForegroundColor Yellow
            Write-Host "  Check: $LCCDefaultInstallDir" -ForegroundColor Gray
        }
    } catch {
        Write-Host "  ERROR: Failed to extract Litecoin Cash." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $zipPath -ErrorAction SilentlyContinue
        Remove-Item $extractDir -Recurse -ErrorAction SilentlyContinue
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $LCCDefaultDataDir)) {
    New-Item -ItemType Directory -Path $LCCDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $LCCDefaultDataDir" -ForegroundColor Green
}

if ($pruneEnabled) {
    $confPath = Join-Path $LCCDefaultDataDir "litecoincash.conf"
    $pruneValue = "prune=2000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in litecoincash.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing litecoincash.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created litecoincash.conf with pruning enabled (~2 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "LitecoinCash P2P (Port 62458)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 62458 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Litecoin Cash peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 62458" -ForegroundColor Green

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "LitecoinCash.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "Litecoin Cash Wallet"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: LitecoinCash" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Litecoin Cash READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to: $LCCDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Data folder:  $LCCDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Double-click 'LitecoinCash' on your Desktop" -ForegroundColor Yellow
Write-Host "     to open the wallet and start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from Litecoin Cash:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start Litecoin Cash now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting Litecoin Cash..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$LCCDefaultDataDir`"", "-conf=litecoincash.conf"
    Write-Host "  Litecoin Cash is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
