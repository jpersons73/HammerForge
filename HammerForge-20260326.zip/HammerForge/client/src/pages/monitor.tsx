import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Activity, Cpu, HardDrive, Clock, Zap, TrendingUp, Users, CheckCircle2, XCircle,
  ArrowLeft, RefreshCw, Wifi, WifiOff, Copy, Check, Mail, Heart, X, Globe, QrCode
} from "lucide-react";
import { SiBitcoin, SiBitcoincash, SiLitecoin, SiEthereum } from "react-icons/si";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend
} from "recharts";
import type { MonitorData, Worker, ShareEntry, HashrateSnapshot, BestShareEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import * as QRCode from "qrcode";

function formatHashrate(h: number): string {
  if (h <= 0) return "0 H/s";
  if (h >= 1e18) return (h / 1e18).toFixed(2) + " EH/s";
  if (h >= 1e15) return (h / 1e15).toFixed(2) + " PH/s";
  if (h >= 1e12) return (h / 1e12).toFixed(2) + " TH/s";
  if (h >= 1e9) return (h / 1e9).toFixed(2) + " GH/s";
  if (h >= 1e6) return (h / 1e6).toFixed(2) + " MH/s";
  if (h >= 1e3) return (h / 1e3).toFixed(2) + " KH/s";
  return h.toFixed(0) + " H/s";
}

function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h < 24) return `${h}h ${m}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m}m`;
}

function formatDifficulty(d: number): string {
  if (d >= 1e12) return (d / 1e12).toFixed(2) + " T";
  if (d >= 1e9) return (d / 1e9).toFixed(2) + " G";
  if (d >= 1e6) return (d / 1e6).toFixed(2) + " M";
  if (d >= 1e3) return (d / 1e3).toFixed(2) + " K";
  return d.toLocaleString();
}

function timeAgo(ts: number): string {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 5) return "just now";
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

const COIN_COLORS: Record<string, string> = {
  BC2: "#f59e0b",
  DGB: "#3b82f6",
  BTC: "#f97316",
  BCH: "#22c55e",
  BSV: "#eab308",
  XEC: "#a855f7",
  FB: "#14b8a6",
  PPC: "#84cc16",
  LCC: "#f43f5e",
  NITO: "#06b6d4",
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
      data-testid="button-copy-wallet"
    >
      {copied ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
    </button>
  );
}

function HashrateChart({ data, coin }: { data: HashrateSnapshot[]; coin: string }) {
  const color = COIN_COLORS[coin] || "#f59e0b";

  const maxH = Math.max(...data.map(s => s.hashrate), 1);
  let unit = "H/s";
  let divisor = 1;
  if (maxH >= 1e18) { unit = "EH/s"; divisor = 1e18; }
  else if (maxH >= 1e15) { unit = "PH/s"; divisor = 1e15; }
  else if (maxH >= 1e12) { unit = "TH/s"; divisor = 1e12; }
  else if (maxH >= 1e9) { unit = "GH/s"; divisor = 1e9; }
  else if (maxH >= 1e6) { unit = "MH/s"; divisor = 1e6; }
  else if (maxH >= 1e3) { unit = "KH/s"; divisor = 1e3; }

  const windowSize = 8;
  const scaled = data.map((s, i) => {
    const start = Math.max(0, i - windowSize + 1);
    const window = data.slice(start, i + 1);
    const avg = window.reduce((sum, w) => sum + w.hashrate, 0) / window.length;
    return {
      time: new Date(s.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      hashrate: s.hashrate / divisor,
      movingAvg: avg / divisor,
      workers: s.workers,
    };
  });

  if (scaled.length === 0) {
    return (
      <div className="h-[250px] flex items-center justify-center text-muted-foreground text-sm">
        No hashrate data yet. Data starts collecting when miners connect.
      </div>
    );
  }

  const xInterval = Math.max(Math.floor(scaled.length / 8) - 1, 0);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload || payload.length === 0) return null;
    const hr = payload[0]?.value ?? 0;
    const avg = payload[1]?.value ?? 0;
    const wk = payload[0]?.payload?.workers ?? 0;
    return (
      <div className="bg-[#1a1a2e] border border-[#444] rounded-lg px-3 py-2 shadow-xl text-xs">
        <p className="text-muted-foreground mb-1.5 font-medium">{label}</p>
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2 h-2 rounded-full bg-[#2dd4bf] inline-block" />
          <span className="text-[#ccc]">Hashrate:</span>
          <span className="text-white font-bold">{hr.toFixed(2)} {unit}</span>
        </div>
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2 h-2 rounded-full bg-[#f59e0b] inline-block" />
          <span className="text-[#ccc]">Moving Avg:</span>
          <span className="text-white font-bold">{avg.toFixed(2)} {unit}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#888] inline-block" />
          <span className="text-[#ccc]">Workers:</span>
          <span className="text-white font-bold">{wk}</span>
        </div>
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={250}>
      <AreaChart data={scaled}>
        <defs>
          <linearGradient id="hrGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.6} />
            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0.1} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis dataKey="time" tick={{ fill: "#888", fontSize: 10 }} interval={xInterval} />
        <YAxis tick={{ fill: "#888", fontSize: 10 }} tickFormatter={(v) => v.toFixed(1)} label={{ value: unit, position: "insideLeft", angle: -90, fill: "#888", fontSize: 11 }} />
        <Tooltip content={<CustomTooltip />} cursor={{ stroke: "#555", strokeWidth: 1, strokeDasharray: "4 4" }} />
        <Area type="monotone" dataKey="hashrate" stroke="#2dd4bf" strokeWidth={1.5} fill="url(#hrGrad)" name="Hashrate" />
        <Area type="monotone" dataKey="movingAvg" stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="5 3" fill="none" name="Moving Avg" />
        <Legend
          verticalAlign="bottom"
          height={24}
          iconType="circle"
          iconSize={8}
          wrapperStyle={{ fontSize: 11, color: "#888" }}
          formatter={(value: string) => <span style={{ color: "#aaa", fontSize: 11 }}>{value}</span>}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function BestShareChart({ data }: { data: BestShareEntry[] }) {
  if (data.length === 0) return (
    <div className="flex items-center justify-center h-[200px] text-muted-foreground text-sm">
      Waiting for best share data (recorded every 5 min)
    </div>
  );

  const chartData = data.map(s => ({
    time: new Date(s.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    difficulty: s.difficulty,
  }));

  const xInterval = Math.max(Math.floor(chartData.length / 6) - 1, 0);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload || payload.length === 0) return null;
    const val = payload[0]?.value ?? 0;
    return (
      <div className="bg-[#1a1a2e] border border-[#444] rounded-lg px-3 py-2 shadow-xl text-xs">
        <p className="text-muted-foreground mb-1 font-medium">{label}</p>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#3b82f6] inline-block" />
          <span className="text-[#ccc]">Best Share:</span>
          <span className="text-white font-bold">{formatDifficulty(val)}</span>
        </div>
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={chartData} barCategoryGap="2%" barGap={0}>
        <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
        <XAxis dataKey="time" tick={{ fill: "#888", fontSize: 9 }} interval={xInterval} />
        <YAxis
          scale="log"
          domain={["auto", "auto"]}
          allowDataOverflow
          tick={{ fill: "#888", fontSize: 9 }}
          tickFormatter={(v) => formatDifficulty(v)}
        />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.05)" }} />
        <Bar dataKey="difficulty" fill="#3b82f6" name="Best Share" radius={[1, 1, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function DgbIcon({ className }: { className?: string }) { return <img src="/images/dgb-logo.png" alt="DGB" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function UsdcIcon({ className }: { className?: string }) { return <img src="/images/usdc-logo.png" alt="USDC" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function XecIcon({ className }: { className?: string }) { return <img src="/images/xec-logo.png" alt="XEC" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function XrpIcon({ className }: { className?: string }) { return <img src="/images/xrp-logo.png" alt="XRP" className={`w-5 h-5 rounded-full ${className || ""}`} />; }

const donateAddresses = [
  { ticker: "BCH", name: "Bitcoin Cash", address: "qrqtvrm6vvvzq6w8jcu9alcv599lmsgpfv7a87edaa", icon: SiBitcoincash, color: "text-green-500", bgColor: "bg-green-500/10 border-green-500/30" },
  { ticker: "BTC", name: "Bitcoin", address: "bc1qczmq77nrrqsxn3uk8p007r9pf07uzq2t96w3g5", icon: SiBitcoin, color: "text-orange-500", bgColor: "bg-orange-500/10 border-orange-500/30" },
  { ticker: "DGB", name: "DigiByte", address: "DNi4NsZKH93QxBWn1RfQYizGtrKVhJcz6q", icon: DgbIcon, color: "text-blue-400", bgColor: "bg-blue-400/10 border-blue-400/30" },
  { ticker: "ETH", name: "Ethereum", address: "0x996c85e9137a9020C2a3d9b4889aA6a35185d368", icon: SiEthereum, color: "text-indigo-400", bgColor: "bg-indigo-400/10 border-indigo-400/30" },
  { ticker: "LTC", name: "Litecoin", address: "Lcnv6pvW4PPBfz2LSyf9GytSDvxUWwaiSB", icon: SiLitecoin, color: "text-gray-400", bgColor: "bg-gray-400/10 border-gray-400/30" },
  { ticker: "USDC", name: "USD Coin (ERC20)", address: "0x996c85e9137a9020C2a3d9b4889aA6a35185d368", icon: UsdcIcon, color: "text-blue-500", bgColor: "bg-blue-500/10 border-blue-500/30" },
  { ticker: "XEC", name: "eCash", address: "ecash:qrqtvrm6vvvzq6w8jcu9alcv599lmsgpfv8sn4zh", icon: XecIcon, color: "text-blue-400", bgColor: "bg-blue-400/10 border-blue-400/30" },
  { ticker: "XRP", name: "Ripple", address: "rJZxqccCyj93RBLBGqCqzxFgr5bURGJrrm", icon: XrpIcon, color: "text-white", bgColor: "bg-gray-600/10 border-gray-600/30" },
];

function SupportDevelopment() {
  const [showDonate, setShowDonate] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState<string | null>(null);
  const { toast } = useToast();

  const copyAddress = (address: string, ticker: string) => {
    navigator.clipboard.writeText(address).then(() => {
      setCopiedAddr(address);
      toast({ title: `${ticker} address copied!`, description: address.slice(0, 30) + "..." });
      setTimeout(() => setCopiedAddr(null), 3000);
    });
  };

  return (
    <div>
      {!showDonate ? (
        <button
          onClick={() => setShowDonate(true)}
          className="group w-full relative px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500/10 via-orange-500/15 to-amber-500/10 border-2 border-amber-500/40 hover:border-amber-400/70 hover:from-amber-500/25 hover:via-orange-500/25 hover:to-amber-500/25 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/20"
          data-testid="button-show-donate-monitor"
        >
          <div className="flex items-center justify-center gap-3">
            <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center group-hover:bg-amber-500/30 transition-colors animate-pulse">
              <Heart className="w-5 h-5 text-amber-500 fill-amber-500" />
            </div>
            <div className="text-left">
              <p className="text-sm font-bold text-amber-400">Support HammerForge Development</p>
              <p className="text-[11px] text-amber-500/70">Tap to donate crypto and keep this project going</p>
            </div>
          </div>
        </button>
      ) : (
        <div className="rounded-xl border-2 border-amber-500/30 bg-gradient-to-b from-amber-500/5 to-transparent p-5 relative shadow-lg shadow-amber-500/5">
          <button
            onClick={() => setShowDonate(false)}
            className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-close-donate-monitor"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-2">
            <Heart className="w-6 h-6 text-amber-500 fill-amber-500" />
            <h3 className="text-xl font-bold text-foreground">Support Development</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Tap any address to copy it to your clipboard.</p>
          <div className="space-y-2">
            {donateAddresses.map((d) => {
              const IconComp = d.icon;
              const isCopied = copiedAddr === d.address;
              return (
                <div
                  key={d.ticker}
                  onClick={() => copyAddress(d.address, d.ticker)}
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${d.bgColor}`}
                  data-testid={`donate-monitor-${d.ticker.toLowerCase()}`}
                >
                  <div className={`w-9 h-9 rounded-full bg-background/50 flex items-center justify-center ${d.color}`}>
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`font-bold text-sm ${d.color}`}>{d.ticker}</span>
                      <span className="text-xs text-muted-foreground">{d.name}</span>
                    </div>
                    <p className="text-xs font-mono text-foreground/80 truncate">{d.address}</p>
                  </div>
                  <div className="flex-shrink-0 text-muted-foreground">
                    {isCopied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function WorkerRow({ worker }: { worker: Worker }) {
  return (
    <tr className="border-b border-border/30 hover:bg-muted/20 transition-colors" data-testid={`row-worker-${worker.id}`}>
      <td className="py-4 px-5">
        <span className="font-semibold text-foreground text-[15px]">{worker.name || "unnamed"}</span>
      </td>
      <td className="py-4 px-5 text-[15px] text-foreground">{formatHashrate(worker.hashrate1hr)}</td>
      <td className="py-4 px-5 text-[15px] text-foreground">{worker.sharesAccepted.toLocaleString()}</td>
      <td className="py-4 px-5 text-[15px] text-foreground">{formatDifficulty(worker.bestDifficulty)}</td>
      <td className="py-4 px-5 text-[15px] text-muted-foreground">{worker.lastShareAt ? timeAgo(worker.lastShareAt) : "never"}</td>
    </tr>
  );
}

function ShareRow({ share }: { share: ShareEntry }) {
  return (
    <tr className="border-b border-border/20 hover:bg-muted/20 transition-colors text-xs" data-testid={`row-share-${share.id}`}>
      <td className="py-2 px-3">
        {share.accepted ? (
          <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
        ) : (
          <XCircle className="w-3.5 h-3.5 text-red-500" />
        )}
      </td>
      <td className="py-2 px-3 text-muted-foreground">{share.workerName}</td>
      <td className="py-2 px-3 font-mono text-foreground">{formatDifficulty(share.difficulty)}</td>
      <td className="py-2 px-3 font-mono text-muted-foreground">{formatDifficulty(share.targetDifficulty)}</td>
      <td className="py-2 px-3 text-muted-foreground font-mono truncate max-w-[200px]">{share.hash.slice(0, 16)}...</td>
      <td className="py-2 px-3 text-muted-foreground">{timeAgo(share.timestamp)}</td>
    </tr>
  );
}

export default function MonitorPage() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showQR, setShowQR] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  const { toast } = useToast();

  const isDemo = typeof window !== "undefined" && window.location.search.includes("demo=true");
  const apiUrl = isDemo ? "/api/monitor-demo" : "/api/monitor";

  const { data, isLoading, refetch } = useQuery<MonitorData>({
    queryKey: [apiUrl],
    refetchInterval: autoRefresh ? (isDemo ? 10000 : 5000) : false,
    staleTime: 3000,
  });

  const { data: tunnelData } = useQuery<{ url: string | null }>({
    queryKey: ["/api/tunnel-url"],
    refetchInterval: 30000,
    staleTime: 15000,
  });

  const coin = data?.config?.coin || "---";
  const wallet = data?.config?.walletAddress || "";
  const port = data?.config?.stratumPort || 0;
  const algoNote = data?.config?.algoNote || "";
  const coinColor = COIN_COLORS[coin] || "#f59e0b";

  const workers = data?.workers || [];
  const shares = data?.recentShares || [];
  const stats = data?.networkStats || { blockHeight: 0, networkDifficulty: 0, networkHashrate: 0, coinPrice: 0, bestShare: 0, totalAccepted: 0, totalRejected: 0, uptime: 0, connectedWorkers: 0, totalHashrate: 0 };
  const stratum = data?.stratumStatus || { running: false, port: 0, connections: 0, startedAt: 0 };
  const hashrateHistory = data?.hashrateHistory || [];
  const bestShareHistory = data?.bestShareHistory || [];
  const blocksFound = data?.blocksFound || [];

  const connectedWorkers = workers.filter(w => w.connected);
  const displayShares = shares.slice(0, 10);
  const rejectRate = stats.totalAccepted + stats.totalRejected > 0
    ? ((stats.totalRejected / (stats.totalAccepted + stats.totalRejected)) * 100).toFixed(1)
    : "0.0";

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <RefreshCw className="w-8 h-8 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground">Loading mining data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background" data-testid="monitor-page">
      <div className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-1.5" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4" />
                Home
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAHdElNRQfqAxoNNwMC2T2yAAAajUlEQVRo3u16WYyl13FeVZ3zb3fr29231+nu6Z6Fw+FspDjiTkuyGSWxLSgGAmRxpDhGnAXwSxAgCJKH5DVI8pIACeLAiAEntgHbiQJtNiAzokVa4iYOOUPODGef6b3vvvzLWarycHs4JE1SQ0mIX/IDjb4X6D5/fVV1qr5aEH4aDyIiIgCIiIj8VP7yfl/9E/4/EYrAB0RBLJfLSVKK40hrjYDOuzwvRqNROhoByAfBALP8BQAYK5KZx1+jOF5eXllbW11aXJiuV+NQEwAIgDAikiJA5QVyY1vd/p2NzWvXr9+5fdsUxV0t0HtH/b8A8N77lFKHjhw9ffKhlYVZ5U2nudvc2+v3e8PUOvYsAqhFRKEQQqiplET1ifrM7OzE9IzX0a2N7XNvnr965d2xAX88GPhpFT9+WRTHp06fPnPieAndnRvXt7a2Muurk5NxpV6uTZ04Us1dlNv4+EFOTXB72wP4ojCDfr/Xafc7zbzfrcT6wIGl+aWVgcc3Llw8f+6ctfb9r/jpAxgfjYinTp85e+YkZp13L77T6ucLKwvVxoFarfHZB91Ot9rs0cGpvcyVu3n12MLWMIs2u5OBZkTyrOanWSm+dNO3mlu7G7cGzZ3ZWnn1gWOZKr3+5tsX377waTHgp1L83PzC0089UcP80vnzPYOzK6szc0uPHc17efXWDk5EbQ/V1FdtPlBKVSYandaGUuFEvWFMwd4DUr008s4UrhIEeHw5f/Wyu3lra/P6lYVaePTEya0R/9kPXum0mvcPA+9f+tMPP3L66Mr21Xc2mr3a4tpzj9X3htODTNB1wiDKZDrUfmkhObxcbtSwmnCsfBCGCGw9FE4Nc2oP6crNwcZOmuW+EjvldztptVqJV2aLP/n++s6Na6tzE1MHj71+6ca7F9+5Twx4P9JHYfT4k08cKMOlC+dhYmZp9YEgiEqyHkbVncFEkugjK8FTp8ozpVGv1Vy/0769NWx13WDk08JFgYpCSiJamC0tLVRXlhvl+nQ7L//gwujcxQ4ALdSNz3e2h9MMsrt+HXo7K0ceuNXjc2/80Dn3IzHgj5S+Uq0++fhj0Wj73Rvr9YMnnnuYtrqlvWFQGAw0/9zj9c8esq2tzRdf3b5ww+1lCQSVpFKLkzhJYqWU916YjbXDwbBIR8oP56v2zJHosYdnGgvLr1zV335xqyh8tRLNVosSdV94R/ze9cMrC3sw8cYbb+R5/skY8JOlr9ZqT3z2rDRv3OmMlh84CaDJd+tltT2oP/uZ6C+f9pffvvG1Fzq3e7Xy9FyjUa/XSoEmEAERHgdHRAEEAEUogNZzb5Dt7rSy7u6xmewXf2ZyZe3At8+pl97KGlFrr++CeArQb1+/tFSP09L8G29eyLL0EzDgJ0hfKlfOfuZM0Ll1owtPP75yeMaeu13Z6UK1jP/gFyLurP+3r+/dGDTmlxdnpiqakJnZCxIhjjMdiTAiBSgsYgWEefxKpRUDbu32tu+sn5rtf/Xnp/t69je+mWcFLM/AsZnu25vhOxe31+rcjRbeOv9OUXysHdTHSR+G4ZnTp6L++u0Bz64cyUYZm+5mOzqyEvzj57LvPn/5P/8R6JkjqyszcUDWWOvc+HwRRgABGWclzx6BhcU6BhDvPbMYY4s8L8Vqbn56M6387+/uzuD2Lz9XutlS23tpNursdMOgOrPb7MypYdRYarVazPyR6lYfZ5djx483uL3etYurqzFlqQ0ubwY/80j4Sye6//a3br3WXDz6wEqkwBjHnpEQEdn7sZKEmYVBhL0HAMfimAGE2YuI9977/Q95npdCqjemX7wMNy+v/9pzsDkKX74SJXFQDnKV1Jqt7oGS9+VGt9P+SFHVn1c/ACwdXF2tyq2tTml+jTj37PuZ+tIT+qm55r/6rVY+cXhptlJkBQsAgjAL3HOPsfezH3M01OC8Z8cMzCzMYz9j9t6zdyJinXfWTk8md0bll17e+nvPWojjKxugIbfWumgi7zTnJ+KBhNloNBbvYwGMnadcnXhwqZG1tg8cXVYAmcFBpj93Cp6cbf7r3xnGC4cnEioKBwjMsn+eeEJAHCvdAwgioDCgBMABOIViWUD82CYg7L1nAZZ9TMbYcoQDqr30WusrT+QdF1zZUlpBJcTKRFy0dmv1qfYwd9Z+CMJHWODQ2mo139mFejV2jbLZ7AZHF92Xj/X+ze+navZgorx1jAgigAjMTIjGovfoHRRWtEZmyHLxnvPcpw48KGcgM1wUXFjIjc8Lj0hjX/Ms7D0zW+djJamuvXm+85Un7NV20M9ouTYwJt3L43k1ysNav9f/2Cg0Vv9kY/b0QqnbG2aVeW+cAlepxv/kZ9Pf/lbvtlqeKinnhQiJiEghAgCFin/1y/NJEhrL9Wr421/bmJ7Uv/iFuVbPVSp6/VafGdeO1Hv9rJyEUYC5Md7LH39v79zVPApQARf73FXYM6K0R3wm3vj5p5N//3x5NMqQlA6jSrYbl5K3t9Nhv/v+iPQBCyilV5dm1aibzNTPHobc6U6q/+7T7t2L3Zeas9MVbRwToYzrKRAQAISssL2tC7/0FBxZyJ//xmvnbge9Tnc1uv7FpyPXvv0/v3b53Xc3nznafeoM3rp45YXvvGX3Np55KL+xNXrnThBoYWa3bwf2zN75JIQr3WgJu4eX4MJ2UolIk7OopyUtwnKvP3x/PKX3393KRH1GFSMJuxm0ms00zY4tmLrtfPtKebIWGuMRxI99VoRZPDOICKoXL8YbO8Wgm3/9LZ1isjEqf+ct5qJ4/WL2wp2Jl3fqL180XNg/eX34H79D/+J38//0u5srdWusY+bCemYRYRYWERYw1teqwdcuVQ6Fg8ONvJ95dtYBtq2aDV1crn6gONm/hCKINF0r+3xkwvIwo1duVNqp+oUHs2/9kH1cFme9sHXe30Uw/uWcI4DFubp4652dnaw6w8AwOZE4mwcBLcxOLM9PlktBNhrVqsnawQM/8+xDVzuTv/mHG3EE1nnZV8q+RjSxQhFr06D04mX1+dUhs7escwN7LqyCqVdL7weg3/sUlsozkR9lcHjJMMSXNsMTi8Z00wudalJl68ekAFhACRLJuK4URCBE8ey8NfbRUzOrtm4dH6pBlmbAbKwDFO+8ye3sdHzqxPxffyx79bz6zWuzh+vOOxBhQnBexoawvP8hCfCVvcpnltvH5sylrfDAJNRLkDWlEcleFLsi/zCAcimJJW9DfO56PlU2gNWzi/lLl5HDSJgFUAAAKSbxIs6PcxcCoXiP4p01xuDnjnYV9hDRejccefFOmBkE2A9TOHVAnT24M11LXzHp3NQUM7OAQiBhx1IiSIC3jSgAEQH2GQVvrgefmcve3gq8GV3r2JDCxZKL42T4IQBIqh5rb9MCSkkpaWa80igmIb/UrgTxuBQhL4IIDoABBYEBcNwZQfTCtnDg1b/8Dzevblnr5K8+Vvlnv7poCiPsBVWRm5Cir/+f3d/4VvfvPJnkSdWzE0H2PG6yeGYvMhQZM5BxIg+VnNuLfvlAf7ZibnfjUCdOmDitxsGwh+MGxz4AFYT1kDODa418tqb+7Fp4ZKq4uQ0DCMsgLADeExKgzxmJcOxOiEiIgl6BeM9FalStobjEln2U5lkujoG9ILDnIisyiWrLh795rZcQl2bQWS8ABQuIBCAFs/FCAMw87hoRcMsGvQGtThTtYensimkOXDaUqRC2dSDO3AMQhGEJ3R6rXtMM+o6lvlq1b13XguPjcKxmRCQCZhFAIhQRQQDEwosx3lohCitxmBNoyrPUsgdhLBiAOU19gDhXiidmw0HunbeeBRE0iGGZSaiZCTD7MRdhYREE8YhXWsFqw77KvL4zbGU0oYOJiJUOnDP38kClXFlIuO3Cvo3aWVQr8Wcb+SvrcYaaPky65W4CFEAQAAL5h18MDk8XKHzmeOP8NffgIn31C4gunZuJq5XasUX17Aljs2JtKcEgeu2qJU0axDIkJIUXEOkX3gl4AREGABYBEAJxIujl4bn83G6wlyapD7WiRui2M7SmuGeBJEDnpRqZpSl1sx3Wo8IZaRtFIXseZ4lxS1BAEBCAAAViDalHAPuN529+CyVESrCZFkvNovi9399FFQbQbeZ7Va3+8GLWKaga9K4NQ6UPCEvGQiCTIfUNMwshOM+LZUwttjKvEBSCZyGAttHeQTVyImq57gvjRCQOKL13iZFCAkLZ7HGrXxRIU4n0MigE47tdQ0QQERAUFAQkRo+YOkFAy/D929WApLA8pYPGHF3tBj9oVmequtc3QRLVQpwFuplRPeYu66RqONAIEIJ0M0ciMwnupEIgvZwzJwjCAsLsWDTC0EJmcSr2ewO/0x4WXk1NqEghAALIPoCAxLE4TJAS66EW+kFOfr+G2ucOhOhEJmPNIgPrI0UBYsFCiPONigKPOpqbquX9QS2hhbVp42F5ihWRJ3As8xa88LwOdHWi12mD+CDSzZQThf2CRdgyGC8E++WojAUUcQxpQeXAG089qFkvAkWo9pU6BoAKxQssVG09wUu7KgAuHHpmZhQQRCIEL0JEfeMBgBBYwPE+hZ6aml5YmJ9uNFqX37k8zMpJXFHSY2kbPDSJOwNvhKZCsKI7g/T0wWV15lR/d3tjc12nfQ9UWF9WqEmGTjIWENEIKFKIEIgXyCzGigH4QG1cT4jG/Yt4lwuBiIjm1OUDEEZh6+FuhxYA9iv0cZgWEc/AwjkLMzempxrTk3G5PLp2+a2XX62FFBL3jFgr1QhDwQkUb/zQSMDMml7+7guycSfTSVJrzDXqWWGtQN+J9Wz2CZFYFsNjU4AAOBkrSrqDvNnPPQvttwrGUYhUoxxGxJc6Qb8IreDRKScOM4wzOy6sZPzDvE8d5qq6lfozDTowM7XVt6Mi1zsbV944F1RLh+pJx9NEiSrs50KwuatpIYVZ4eNEA/Nmatyta1rTTmZSK48uJMplexkXAiz7FdL+9EAAQayHoxOmEL7eCTyGI6cPlPzQU3toAESN78BUOSwr7nIch7pwcnDCxkCv7qpQ490zQSFMxFQ4AQDLIgLGut2RH1lXsnnvytU2UrU+kYqKCCPvJ2NRuS9yd5aKlSpypEeFE8+k8E53NDPs+mqtl+fd1GaFMYz3mL0ICICAAAOAYzg+abpWtgbhfA0QZCrknqXuyAAIjf/BCgDAfDmfK6WEnFoINYc0VsV+XmQR78WzeOas8Aqh5/TQODTFkvQfOT5bS6JKpBdjUcaUyQWj4hCYZxLzs3OYDIt57efE1gNhhlNz1bNnFqfSXeVsr7ADCbUiwf1ooVB47DuCIoAikZKRQY3+QDKcL2UgYFnGfjG+A1J40AS7PbvedszQLTDWTMLvub4AeJZ27iMChUCESMqzj4Cjzt7Ndvvkwdrff2olKAo09nDCi+xOsz1O+PiqPPyPzJNHcNb6wLrBXvZggn/zqTVR7tp2q9xthQjeWQBEGVcZUrixBcZFggQkRDIoIHf46oa+1kRNklsBeQ+AcG5FoQhGGFQUUSeFULFG9ixjYgIiY2eKgCPCNM8Ho1GoiLrtjWF+qyP//cVrfVf8rUdm61k2Ze1Jsb/y6/KFZw1tGTxTfvjRHK8NT4b5V4/Cl88uvbGx8wcvrW+mcLs7CvqdINDpaJTlOcK4VtyfWgmAFygr1sTtFEONQRgnYYiEueOxBe46ngoWy9g3oBQTwMjIiRm/O9J9S3Q3YDFgrDBlUQCjNOv2B5GzzWHqldaEJSOd7mBqrvzMwYloOJgZ2Ue+EngTBpd7tb/xOByfOUZXFoPEzC584+rW2xf2qqU4Keu2l2Gao3OD0UgjgtLjK7Af/UQcw4GSm6ua1zaDUiCL1aKkRCHd6TM7ew8Ao5qtKBZp5aQIUyOHprwWvD1UgRqfiIjoRUDQMDvvvXPDwlIQzFTjKApigkrmNluDFsVferayNpfjmbXkoaj8OOCDf1svn6nUb3z/zeS/fH/3ZLtXBr0bBVEQDCXQigZpVgiiCsJAj6eG+0UiiHFyctqN2L/bDABob+DqATPpzZ4B8fe4EDvXN0E99JupZkEEvN6FByac2glYSO7ehHFPRkAqYQDM3ksQBmGkpxLVHagh4K80ANZa//V7tV//0tKhv/JrgKsAVwEehXe/+7V/h9+80/7nT4+u/bH6UwcdY7oqTkqJsSpC1AyiVKiREIfOK0QQYJAQZbbsX9tBAFQKDceVyO5kAuw/WJGxa+UwMwH12K1Ow2YPrzTp0TluxNw0oO5qZZzdmTl1jgFIESH0jYyKohxHaw89dIn8alUGs/p/vK6O/tPnw6Uj4ArES/3LV8+36mpu4nKZf/gAxKOi1utplps7exqlsA6QiNQgc4pQAEKCgGCvkNUyK+1vdSnSyAyx8rGGVsZj9X+AKIdJ+ewcbg9NITC0YWrkrz1k0yz8080g1nfzHqIwT9Qq1WqNvQeEQClCjLQepelOpyOkTCHVCLyAzS3aApHGU8EwUuxkYCBOkIRnJmqlODrz4DEhnRnTGwy7g8HmxnqnPwJEASGA3MnPLZuMzfPXwiQKHMtS2U+X8OUNBzaXD/WFvEAlDqoabg6jRhk8Y7/gRxf4ZluZu7kMAQCxKEyapYU11tq8MKM0641Gg1GqEDVCHIAAaIIo0mEpCeMwjEOtQUSQIAkAmVGg3R+kRbG0spxZt9tur29sbN6+OUpzQQIQBPAC0xGfnjcv3ARFulGWwsNa1W+l1B0W7w3M7xX14O3mKH64QZOh8dYjxne61LHu9Iz/3ibEAQkgi2gCZ7Oddq4IdRBEURiFodZamAFREDwCjisSDwB+TMUBcNwJk/0wKVEYOOd/5w/+l7AQAAIwogqCJEalFIJYJ2eW3PrAt0ZBEoGzxVyMSMHWkFG8fGRvtPA4VdIRyu1hqBU6j72cH1vmja5KPSKACCgUApcaQUTnnDEmLwrnHIAopcbD6v3KYTyrv0tseFxbIwISiHjPwozOKERB9EhAqIiU0kqR8bJU4eOz5jtXQTAgUq2UDlZk4PV2z4DwxzR3hQsIj05KK8dyhNWYNzpQL/HxabrYRE0gANZLakCNa3rCcZvSOpcXxhSFCCsdANzlMu/dsvEXRO9cmqajNE3TLM8Lw+AEnMBsLQiU9qC0IgAhgb90yL6166+19GxVKpEkGhdreGEXvMs/qTude6zEwUzkc7aDTASD9S6fXuQS0c0+hGp8CwQQiYgQERAQCEkRWs9FYci7IIzlLoEV2edmiJiORp1e31h714GREIlIK+WFBBUSacLcyecPsgH73SsYhaFxaF3x4CRsjvRuv3i/+j+qvS6+78Ojk3CzzZnE5Qitl42ef3ZNRhntpKAViuyPwMZNaiJShIWTagBH6yorbM4QBoG8rw2AhHmWq2K0MqFSj4ZRq3FoV0prrRSSAsRAYWbl7LwsTZlvviPlOIxCzL2qh1BL6MKugDM/esTkPFsMTzRwaKUWmdxSc6iG1n3+EOwNVDuXYN+BxhwDFWHucakCzyzq3MntATuGOI72U8fdknowHDnmY1P6REM3cxlaikJFpBQRESFhoDA1cnpGTi/ab7zjO1kwV+PJxDuHp+bgzV3KslxA7mPIJ9w3NFXWE6q43MIwCKfKcqslubjPr0FnRM1MQvVeUIWRg+N1+OKKutpxr207J6gVhVG0T8fuXmVTFIWT7ZE0SvjMgbBrsJlTpAkAiJAQMiOPLMCpA/bbF30n1aU47OfQT91DM3BnqDe7FsXd95BP3F6u16Z0rEhr5xx7DNZbknr3hcPoLG0ORBESoWN4bBafmYcfbBZv7PLYtyqVMhF9aPBDhNYYD7Q9kpDg6SXNgLsZBAodizB8blVWpuy3L/qtnlqdoakSd3N1ZBId6Hd2PfpC7mfI976A5Pby4OQcNvt2OwvigGZreKsFO0P35CrMl2mjJ7mXQOHJur+wV7y241lksRZH5Ypj8G6/Db/fhfceEaMoBObCujsDHyLMlvHGAKyHuTI8d1QAzR9d5EGhoyjMDRfWHaxBOdY/3GJ0ufw4qwakKqXkyQNyqSmZ93MVt94LuyNfi/3njtBcOfjhOl5sSlYYZJck8SNnTo2yvN8fIJG8V4mO6fHdUreUJKU4unDxUprlAKpeCR9ZxNVpvrBlX78NUaAOz8LOgFoj9cCkrZfVa5vAJuePXzVQn7TqIWKc3831mTn0zl1vg5OgVlKO4e1Nn3l/YhEemMJhxt0cdBAGYdBqNp33Sin29ywgwsAMAEWRD4ZDIBoOR8h+pQ6fO4KM7vnL7nqLtNZaa2HrGY41sJqoVzeA7SdJD/e1L4SUxMmjCzIq5N0OzpRdJ6PcoXM+VP7YLMxXQBHd6cBbm/a9GnXMWz/iLAJmPr2gD89gK+WrLdnsIpKaqWKocXugInIPz/KQg/PbAu5HSA/3v/BEQXxmXpWVu7Rr2zYsBXCg7nf72B5wGPDyJNRiaA95vOjhPBRu3KmFcRdME4QaQg0sYD1ohb0c2ykEisox5U4ByHRsQ6XWpuh6l260HHFxP/uM97tyhgiC4WI9OD4tuyNZ7/uJyLXy0DGVQ98esoiUQqlGUI0h1hIqDBUQwrgvUjixjCMD/RxSA56xXqZRQUg4X/V7I62R12o+CvX5PRykFsXe59LZp9mZAxBUURQ+0FCNyK/33MZQBwHWQtdMFQJEmoe5WCdRAADivBDu57FQU2YYEUNNLJAEOF+1O0M9MGo6KpYnqJoE17twp8PgzZj13eej4NM9ws7tDKRt1GxVH5uhCFw/59wrK1AKvGMdBLQyKZHGkQ2mK+hBJSEtT7LhAJCiQIwn64E91yN4cEZNldVuqt7elc7AIhuBT7cH++PsjeJ4toG6nOiFKs6UMNLQy7id8tBS5qAWmtTSwOha5HKnBGAqNgMTEFKspR5DPUZNknncHeHekK11CO7HW0T+8VeP70YZRVpPJDRdpskYYy0AkBVOAInIelaEiOCdj0OlCJ3AyEAng3YqqfHgHcJPtHv8k+5O3zMIEBBpRXFASYChRq32Y6oXME4KJ5kV44S9B2EA/shA+xcA4M/Z5L1j33/4PjXF9335/w8AwP8Folm1SNxVDmgAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjYtMDMtMjFUMTU6NTI6MTMrMDA6MDCvr4+UAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDI2LTAzLTIxVDE1OjUyOjEzKzAwOjAw3vI3KAAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyNi0wMy0yNlQxMzo1NTowMyswMDowMPqNKrgAAAAASUVORK5CYII=" alt="HF" className="w-7 h-7 rounded-full border border-white/15" />
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: coinColor }} />
              <span className="font-bold text-lg" style={{ color: coinColor }} data-testid="text-coin-label">{coin}</span>
              <span className="text-muted-foreground text-sm">Solo Mining Monitor</span>
              {isDemo && <Badge variant="outline" className="text-xs border-amber-500/50 text-amber-500">DEMO DATA</Badge>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant={stratum.running ? "default" : "destructive"}
              className="text-xs"
              data-testid="badge-stratum-status"
            >
              {stratum.running ? "Stratum Active" : "Stratum Offline"}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={autoRefresh ? "text-green-500" : "text-muted-foreground"}
              data-testid="button-toggle-refresh"
            >
              <RefreshCw className={`w-4 h-4 ${autoRefresh ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {wallet && (
          <div className="flex items-center gap-2 bg-muted/30 rounded-lg px-4 py-2 text-sm" data-testid="text-wallet-address">
            <span className="text-muted-foreground">Wallet:</span>
            <span className="font-mono text-foreground truncate">{wallet}</span>
            <CopyButton text={wallet} />
            <span className="text-muted-foreground ml-auto">Port: {port}</span>
          </div>
        )}

        {tunnelData?.url && (
          <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-2 text-sm" data-testid="text-remote-url">
            <Globe className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="text-emerald-600 dark:text-emerald-400 font-medium">Remote Access:</span>
            <a href={tunnelData.url} target="_blank" rel="noopener noreferrer" className="font-mono text-emerald-600 dark:text-emerald-400 hover:underline truncate">{tunnelData.url}</a>
            <CopyButton text={tunnelData.url} />
            <button
              onClick={() => {
                const url = tunnelData?.url || window.location.href;
                QRCode.toDataURL(url, { width: 200, margin: 2 }).then((dataUrl: string) => {
                  setQrDataUrl(dataUrl);
                  setShowQR(true);
                });
              }}
              className="text-xs border border-emerald-500/30 text-emerald-500 rounded px-2 py-0.5 hover:bg-emerald-500/10 shrink-0"
              data-testid="button-qr-code"
            >
              QR Code
            </button>
          </div>
        )}

        {showQR && qrDataUrl && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center" onClick={() => setShowQR(false)}>
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 text-center max-w-xs" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-foreground font-semibold mb-1">Scan to Open Monitor</h3>
              <p className="text-muted-foreground text-xs mb-4">Open this on your phone</p>
              <img
                src={qrDataUrl}
                alt="QR Code"
                className="w-48 h-48 rounded-lg bg-white p-3 mx-auto"
              />
              <p className="text-zinc-600 text-xs font-mono mt-3 break-all">{tunnelData?.url || window.location.href}</p>
              <button
                onClick={() => setShowQR(false)}
                className="mt-4 bg-zinc-800 border border-zinc-700 rounded-md text-foreground px-5 py-1.5 text-sm hover:bg-zinc-700"
              >
                Close
              </button>
            </div>
          </div>
        )}

        <SupportDevelopment />

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <Card className="border-border/50" data-testid="stat-hashrate">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                <Activity className="w-3.5 h-3.5" />
                Hashrate
              </div>
              <p className="text-lg font-bold text-foreground">{formatHashrate(stats.totalHashrate)}</p>
            </CardContent>
          </Card>

          <Card className="border-border/50" data-testid="stat-workers">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                <Users className="w-3.5 h-3.5" />
                Workers
              </div>
              <p className="text-lg font-bold text-foreground">{connectedWorkers.length}<span className="text-muted-foreground text-sm">/{workers.length}</span></p>
            </CardContent>
          </Card>

          <Card className="border-border/50" data-testid="stat-shares">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Shares
              </div>
              <p className="text-lg font-bold">
                <span className="text-green-500">{stats.totalAccepted.toLocaleString()}</span>
                <span className="text-muted-foreground text-sm"> / </span>
                <span className="text-red-500">{stats.totalRejected.toLocaleString()}</span>
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50" data-testid="stat-best-share">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                <TrendingUp className="w-3.5 h-3.5" />
                Best Share
              </div>
              <p className="text-lg font-bold text-foreground">{formatDifficulty(stats.bestShare)}</p>
            </CardContent>
          </Card>

          <Card className="border-border/50" data-testid="stat-uptime">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
                <Clock className="w-3.5 h-3.5" />
                Uptime
              </div>
              <p className="text-lg font-bold text-foreground">{formatUptime(stats.uptime)}</p>
            </CardContent>
          </Card>

        </div>

        <Card className="border-border/50" data-testid="card-hashrate-chart">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="w-4 h-4" style={{ color: coinColor }} />
              Hashrate last 24h
            </CardTitle>
          </CardHeader>
          <CardContent>
            <HashrateChart data={hashrateHistory} coin={coin} />
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="border-border/50" data-testid="card-network-stats">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-primary" />
                Network Stats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Block Height</span>
                <span className="font-mono text-foreground">{stats.blockHeight > 0 ? stats.blockHeight.toLocaleString() : "---"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{algoNote ? `${algoNote.trim()} Difficulty` : "Network Difficulty"}</span>
                <span className="font-mono text-foreground">{stats.networkDifficulty > 0 ? formatDifficulty(stats.networkDifficulty) : "---"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{algoNote ? `${algoNote.trim()} Hashrate` : "Network Hashrate"}</span>
                <span className="font-mono text-foreground">{stats.networkHashrate > 0 ? formatHashrate(stats.networkHashrate) : "---"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Coin Price</span>
                <span className="font-mono text-foreground">{stats.coinPrice > 0 ? `$${stats.coinPrice.toFixed(stats.coinPrice < 1 ? 4 : 2)}` : "---"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reject Rate</span>
                <span className={`font-mono ${parseFloat(rejectRate) > 5 ? "text-red-500" : "text-green-500"}`}>{rejectRate}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stratum Port</span>
                <span className="font-mono text-foreground">{port || "---"}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50" data-testid="card-best-share">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                Best share
              </CardTitle>
            </CardHeader>
            <CardContent>
              <BestShareChart data={bestShareHistory} />
            </CardContent>
          </Card>
        </div>

        <Card className="border-border/50" data-testid="card-workers">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Cpu className="w-4 h-4 text-primary" />
              Workers
              <Badge variant="secondary" className="text-xs ml-1">{connectedWorkers.length} online</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {workers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No workers connected yet.</p>
                <p className="text-xs mt-1">Point your miner to <code className="bg-muted px-1 rounded">stratum+tcp://YOUR_IP:{port}</code></p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-border/50 text-xs text-muted-foreground uppercase tracking-wider">
                      <th className="py-3 px-5 font-medium">Rig</th>
                      <th className="py-3 px-5 font-medium">Hash 60min</th>
                      <th className="py-3 px-5 font-medium">Valid Submits</th>
                      <th className="py-3 px-5 font-medium">Best Share</th>
                      <th className="py-3 px-5 font-medium">Last Seen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workers.map(w => <WorkerRow key={w.id} worker={w} />)}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {blocksFound.length > 0 && (
          <Card className="border-border/50" data-testid="card-blocks-found">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-500" />
                Blocks Found
                <Badge variant="default" className="ml-1 text-xs bg-amber-500">{blocksFound.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-border/50 text-xs text-muted-foreground uppercase tracking-wider">
                      <th className="py-2 px-3 font-medium">Coin</th>
                      <th className="py-2 px-3 font-medium">Height</th>
                      <th className="py-2 px-3 font-medium">Reward</th>
                      <th className="py-2 px-3 font-medium">Status</th>
                      <th className="py-2 px-3 font-medium">Worker</th>
                      <th className="py-2 px-3 font-medium">Hash</th>
                      <th className="py-2 px-3 font-medium">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {blocksFound.map((b, i) => (
                      <tr key={i} className="border-b border-border/20 hover:bg-muted/20 text-xs" data-testid={`row-block-${i}`}>
                        <td className="py-2 px-3 font-bold" style={{ color: COIN_COLORS[b.coin] || "#fff" }}>{b.coin}</td>
                        <td className="py-2 px-3 font-mono">{b.height.toLocaleString()}</td>
                        <td className="py-2 px-3 font-mono text-green-500">{b.reward}</td>
                        <td className="py-2 px-3">
                          <Badge variant={b.status.includes("ACCEPTED") ? "default" : "destructive"} className="text-[10px]">
                            {b.status}
                          </Badge>
                        </td>
                        <td className="py-2 px-3 text-muted-foreground">{b.worker}</td>
                        <td className="py-2 px-3 font-mono text-muted-foreground truncate max-w-[150px]">{b.hash.slice(0, 16)}...</td>
                        <td className="py-2 px-3 text-muted-foreground">{b.timestamp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-border/50" data-testid="card-recent-shares">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              Recent Shares
              <span className="text-xs text-muted-foreground font-normal">(last 10)</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {shares.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground text-sm">
                No shares submitted yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-border/50 text-xs text-muted-foreground uppercase tracking-wider">
                      <th className="py-2 px-3 font-medium w-8"></th>
                      <th className="py-2 px-3 font-medium">Worker</th>
                      <th className="py-2 px-3 font-medium">Difficulty</th>
                      <th className="py-2 px-3 font-medium">Target</th>
                      <th className="py-2 px-3 font-medium">Hash</th>
                      <th className="py-2 px-3 font-medium">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayShares.map(s => <ShareRow key={s.id} share={s} />)}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="text-center py-4 text-xs text-muted-foreground">
          <p>HammerForge Solo Mining Monitor &middot; {coin} &middot; Port {port}</p>
          <p className="mt-1">Auto-refresh: {autoRefresh ? "ON (5s)" : "OFF"} &middot; Data since {stats.uptime > 0 ? formatUptime(stats.uptime) : "---"} ago</p>
        </div>
      </div>
    </div>
  );
}
