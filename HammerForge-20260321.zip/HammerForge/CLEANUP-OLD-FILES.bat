@echo off
echo ============================================
echo   HammerForge - Legacy File Cleanup
echo   Removes old files from previous versions
echo ============================================
echo.
echo This will remove old loose files that were
echo left over from a previous HammerForge install.
echo.
echo Your coin wallets and blockchain data are
echo NOT affected.
echo.
echo Files in subfolders (BC2, DGB, Mining, etc.)
echo will NOT be touched.
echo.

set /p confirm="Proceed with cleanup? (y/n): "
if /i not "%confirm%"=="y" (
    echo Cancelled.
    pause
    exit /b
)

echo.
echo Cleaning up legacy files...
echo.

set count=0

for %%F in (
    GITHUB-README.md
    .env
    start-mining.bat
    stop-mining.bat
    config.json
    install-mining.ps1
    INSTALL-MINING.bat
    uninstall.ps1
    UNINSTALL.bat
    install-bc2-core.ps1
    INSTALL-BC2-CORE.bat
    install-dgb-core.ps1
    INSTALL-DGB-CORE.bat
    install-btc-core.ps1
    INSTALL-BTC-CORE.bat
    install-bch-core.ps1
    INSTALL-BCH-CORE.bat
    install-bsv-core.ps1
    INSTALL-BSV-CORE.bat
    install-xec-core.ps1
    INSTALL-XEC-CORE.bat
    install-fb-core.ps1
    INSTALL-FB-CORE.bat
    install-ppc-core.ps1
    INSTALL-PPC-CORE.bat
    start-mining-bc2.bat
    start-mining-dgb.bat
    start-mining-btc.bat
    start-mining-bch.bat
    start-mining-bsv.bat
    start-mining-xec.bat
    start-mining-fb.bat
    start-mining-ppc.bat
    config-bc2.json
    config-dgb.json
    config-btc.json
    config-bch.json
    config-bsv.json
    config-xec.json
    config-fb.json
    config-ppc.json
    config.bc2
    config.dgb
    config.btc
    config.bch
    config.bsv
    config.xec
    config.fb
    config.ppc
) do (
    if exist "%~dp0%%F" (
        del /f /q "%~dp0%%F" >nul 2>&1
        echo   Removed: %%F
        set /a count+=1
    )
)

for %%D in (node_modules logs client script attached_assets stratum-server windows) do (
    if exist "%~dp0%%D\" (
        rmdir /s /q "%~dp0%%D" >nul 2>&1
        echo   Removed folder: %%D\
        set /a count+=1
    )
)

echo.
if %count% gtr 0 (
    echo Cleaned up %count% legacy item(s).
) else (
    echo No legacy files found. Folder is already clean!
)
echo.
echo Done. You can now run Mining\INSTALL-MINING.bat
echo.
pause
