@echo off
echo ============================================
echo   Fractal Bitcoin Node Installer
echo ============================================
echo.
echo This will download and install Fractal Bitcoin
echo from github.com/fractal-bitcoin/fractal
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-fb-core.ps1"

pause
