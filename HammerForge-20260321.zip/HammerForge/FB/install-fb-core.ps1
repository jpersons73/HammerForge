# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Fractal Bitcoin Node Installer
# Downloads and installs Fractal Bitcoin Node
# Double-click INSTALL-FB-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "0.3.0"
$GithubRepo = "fractal-bitcoin/fractald-release"
$AssetPattern = "linux.*\.tar\.gz$"
$FBDefaultInstallDir = "$env:ProgramFiles\FractalBitcoin"
$FBDefaultDataDir = "$env:APPDATA\FractalBitcoin"
$FBSourceRepo = "https://github.com/fractal-bitcoin/fractal"
$FBReleaseRepo = "https://github.com/fractal-bitcoin/fractald-release"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Linux tarball found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-FBExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\FractalBitcoin",
        "${env:ProgramFiles(x86)}\FractalBitcoin",
        "$env:LOCALAPPDATA\FractalBitcoin",
        "C:\FractalBitcoin",
        "$env:ProgramFiles\Fractal Bitcoin"
    )
    $exeNames = @("fractald.exe", "bitcoin-qt.exe", "bitcoind.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Fractal Bitcoin Node Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-FB-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/3] Checking for existing Fractal Bitcoin installation..." -ForegroundColor Yellow
$existing = Find-FBExecutable
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Fractal Bitcoin already installed at: $($existing.Dir)" -ForegroundColor Green
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Fractal Bitcoin not found. Will guide setup." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~5 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/3] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "fractald-$FallbackVersion-x86_64-linux-gnu.tar.gz"
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n  Fractal Bitcoin Setup..." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  NOTE: Fractal Bitcoin currently provides Linux-only releases." -ForegroundColor Yellow
    Write-Host "  The official node daemon (fractald) must be compiled from source" -ForegroundColor Yellow
    Write-Host "  or run via WSL (Windows Subsystem for Linux)." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Latest release: $useTag" -ForegroundColor Cyan
    Write-Host "  Source code:    $FBSourceRepo" -ForegroundColor Cyan
    Write-Host "  Releases:       $FBReleaseRepo" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Option 1: Use WSL (Recommended)" -ForegroundColor White
    Write-Host "    1. Install WSL: wsl --install" -ForegroundColor Gray
    Write-Host "    2. Download in WSL:" -ForegroundColor Gray
    Write-Host "       wget $useUrl" -ForegroundColor DarkGray
    Write-Host "       tar xzf $useFileName" -ForegroundColor DarkGray
    Write-Host "    3. Run fractald in WSL" -ForegroundColor Gray
    Write-Host "    4. RPC is accessible from Windows at 127.0.0.1:8732" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Option 2: Build from source" -ForegroundColor White
    Write-Host "    1. Clone: git clone $FBSourceRepo" -ForegroundColor Gray
    Write-Host "    2. Follow Bitcoin Core build instructions for Windows" -ForegroundColor Gray
    Write-Host "    3. Install to: $FBDefaultInstallDir" -ForegroundColor Gray
    Write-Host ""

    $wslInstall = Read-Host "  Would you like to install WSL now? (y/n)"
    if ($wslInstall -eq "y") {
        Write-Host ""
        Write-Host "  Installing WSL..." -ForegroundColor Yellow
        Write-Host "  A system restart may be required after this step." -ForegroundColor Gray
        try {
            Start-Process -FilePath "wsl" -ArgumentList "--install" -Wait -NoNewWindow
            Write-Host "  WSL install command completed." -ForegroundColor Green
            Write-Host "  You may need to restart your computer." -ForegroundColor Yellow
        } catch {
            Write-Host "  Could not run WSL install automatically." -ForegroundColor Yellow
            Write-Host "  Open PowerShell as Admin and run: wsl --install" -ForegroundColor Gray
        }
    }
}

Write-Host "`n[3/3] Setting up directories and firewall..." -ForegroundColor Yellow

if (-not (Test-Path $FBDefaultDataDir)) {
    New-Item -ItemType Directory -Path $FBDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $FBDefaultDataDir" -ForegroundColor Green
}

if ($pruneEnabled) {
    $confPath = Join-Path $FBDefaultDataDir "bitcoin.conf"
    $pruneValue = "prune=5000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoin.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoin.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoin.conf with pruning enabled (~5 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "Fractal Bitcoin P2P (Port 8733)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8733 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Fractal Bitcoin peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8733" -ForegroundColor Green

$firewallRuleName2 = "Fractal Bitcoin RPC (Port 8732)"
$existingRule2 = Get-NetFirewallRule -DisplayName $firewallRuleName2 -ErrorAction SilentlyContinue
if ($existingRule2) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName2
}
New-NetFirewallRule -DisplayName $firewallRuleName2 `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8732 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Fractal Bitcoin RPC connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8732" -ForegroundColor Green

if ($existing) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "Fractal Bitcoin.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $existing.Exe
    $shortcut.Arguments = "-datadir=`"$FBDefaultDataDir`""
    $shortcut.WorkingDirectory = (Split-Path $existing.Exe)
    $shortcut.Description = "Fractal Bitcoin Node"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: Fractal Bitcoin" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Fractal Bitcoin Setup Complete" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Data folder:  $FBDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Install Fractal Bitcoin node using WSL or build from source" -ForegroundColor Yellow
Write-Host "     Source: $FBSourceRepo" -ForegroundColor Gray
Write-Host ""
Write-Host "  2. Start the node and let it sync the blockchain" -ForegroundColor Yellow
Write-Host ""
Write-Host "  3. Configure RPC in bitcoin.conf:" -ForegroundColor Yellow
Write-Host "       rpcuser=fbrpc" -ForegroundColor Gray
Write-Host "       rpcpassword=fbrpcpassword" -ForegroundColor Gray
Write-Host "       rpcport=8732" -ForegroundColor Gray
Write-Host "       server=1" -ForegroundColor Gray
Write-Host ""
Write-Host "  4. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address:" -ForegroundColor White
Write-Host "       ./fractald-cli getnewaddress" -ForegroundColor Gray
Write-Host ""

if ($existing) {
    $startNow = Read-Host "  Start Fractal Bitcoin now? (y/n)"
    if ($startNow -eq "y") {
        Write-Host ""
        Write-Host "  Starting Fractal Bitcoin..." -ForegroundColor Yellow
        Start-Process $existing.Exe -ArgumentList "-datadir=`"$FBDefaultDataDir`"", "-conf=bitcoin.conf"
        Write-Host "  Fractal Bitcoin is starting. Let it sync fully before mining." -ForegroundColor Green
    }
}

Write-Host ""
Read-Host "Press Enter to exit"
