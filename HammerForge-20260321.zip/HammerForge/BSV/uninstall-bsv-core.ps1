# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Bitcoin SV Node Uninstaller

$ErrorActionPreference = "Continue"

$CoinName = "Bitcoin SV Node"
$ProcessNames = @("bitcoin-qt", "bitcoind", "bitcoin-sv")
$InstallDirs = @(
    "$env:ProgramFiles\BitcoinSV",
    "${env:ProgramFiles(x86)}\BitcoinSV",
    "$env:LOCALAPPDATA\BitcoinSV",
    "$env:ProgramFiles\Bitcoin SV",
    "${env:ProgramFiles(x86)}\Bitcoin SV"
)
$DataDir = "$env:APPDATA\BitcoinSV"
$ShortcutName = "Bitcoin SV Node"
$FirewallRules = @(
    "Bitcoin SV Node P2P (Port 8533)",
    "Bitcoin SV RPC (Port 8532)"
)

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  $CoinName Uninstaller" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This uninstaller requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click UNINSTALL-BSV-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "  This will remove:" -ForegroundColor White
Write-Host "    - $CoinName program files" -ForegroundColor Gray
Write-Host "    - Desktop shortcut" -ForegroundColor Gray
Write-Host "    - Firewall rules" -ForegroundColor Gray
Write-Host ""
Write-Host "  You will be asked about blockchain data separately." -ForegroundColor White
Write-Host ""

$confirm = Read-Host "  Proceed with uninstall? (y/n)"
if ($confirm -ne "y") {
    Write-Host "  Cancelled." -ForegroundColor Gray
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 0
}

Write-Host ""
Write-Host "[1/4] Stopping $CoinName..." -ForegroundColor Yellow
foreach ($proc in $ProcessNames) {
    $running = Get-Process -Name $proc -ErrorAction SilentlyContinue
    if ($running) {
        Stop-Process -Name $proc -Force -ErrorAction SilentlyContinue
        Write-Host "  Stopped $proc" -ForegroundColor Green
    }
}
Start-Sleep -Seconds 2

Write-Host "`n[2/4] Removing program files..." -ForegroundColor Yellow
foreach ($dir in $InstallDirs) {
    if (Test-Path $dir) {
        Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  Removed: $dir" -ForegroundColor Green
    }
}

Write-Host "`n[3/4] Removing shortcuts and firewall rules..." -ForegroundColor Yellow
$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktopPath "$ShortcutName.lnk"
if (Test-Path $shortcutPath) {
    Remove-Item $shortcutPath -Force -ErrorAction SilentlyContinue
    Write-Host "  Removed desktop shortcut: $ShortcutName" -ForegroundColor Green
} else {
    Write-Host "  No desktop shortcut found (skipped)" -ForegroundColor Gray
}

foreach ($rule in $FirewallRules) {
    $existing = Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue
    if ($existing) {
        Remove-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue
        Write-Host "  Removed firewall rule: $rule" -ForegroundColor Green
    }
}

Write-Host "`n[4/4] Blockchain data..." -ForegroundColor Yellow
if (Test-Path $DataDir) {
    $dataSizeMB = [math]::Round((Get-ChildItem $DataDir -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1MB, 0)
    Write-Host ""
    Write-Host "  Blockchain data found at: $DataDir" -ForegroundColor White
    Write-Host "  Size: approximately $dataSizeMB MB" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  WARNING: This includes your wallet file(s)!" -ForegroundColor Red
    Write-Host "  Make sure you have backed up your wallet before deleting." -ForegroundColor Yellow
    Write-Host ""
    $deleteData = Read-Host "  Delete blockchain data and wallet? (y/n)"
    if ($deleteData -eq "y") {
        $doubleConfirm = Read-Host "  Are you SURE? This cannot be undone. (yes/no)"
        if ($doubleConfirm -eq "yes") {
            Remove-Item $DataDir -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "  Removed: $DataDir" -ForegroundColor Green
        } else {
            Write-Host "  Keeping blockchain data." -ForegroundColor Gray
        }
    } else {
        Write-Host "  Keeping blockchain data." -ForegroundColor Gray
    }
} else {
    Write-Host "  No blockchain data found at $DataDir (skipped)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  $CoinName Uninstall Complete" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to exit"
