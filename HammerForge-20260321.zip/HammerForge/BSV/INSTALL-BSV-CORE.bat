@echo off
echo ============================================
echo   Bitcoin SV Node Installer
echo ============================================
echo.
echo This will download and install Bitcoin SV Node
echo from GitHub (https://github.com/bitcoin-sv/bitcoin-sv)
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-bsv-core.ps1"

pause
