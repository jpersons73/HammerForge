# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Bitcoin Cash Node Wallet Installer
# Downloads and installs Bitcoin Cash Node from GitHub
# Double-click INSTALL-BCH-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "29.0.0"
$GithubRepo = "bitcoin-cash-node/bitcoin-cash-node"
$AssetPattern = "win64\.zip$"
$AssetExclude = "debug"
$BCHDefaultInstallDir = "$env:ProgramFiles\BitcoinCash"
$BCHDefaultDataDir = "$env:APPDATA\BitcoinCash"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern -and $asset.name -notmatch $AssetExclude) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Windows asset found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-BCHExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\BitcoinCash",
        "${env:ProgramFiles(x86)}\BitcoinCash",
        "$env:LOCALAPPDATA\BitcoinCash",
        "C:\BitcoinCash",
        "$env:ProgramFiles\Bitcoin Cash Node",
        "${env:ProgramFiles(x86)}\Bitcoin Cash Node",
        "C:\Bitcoin Cash Node"
    )
    $exeNames = @("bitcoin-cash-node-qt.exe", "bitcoin-qt.exe", "bitcoind.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Bitcoin Cash Node Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-BCH-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing Bitcoin Cash Node installation..." -ForegroundColor Yellow
$existing = Find-BCHExecutable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Bitcoin Cash Node already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Bitcoin Cash Node not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~10 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain (~200+ GB)." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "bitcoin-cash-node-$FallbackVersion-win64.zip"
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading Bitcoin Cash Node $useTag..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "bchsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $zipPath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $zipPath)
        $sizeMB = [math]::Round((Get-Item $zipPath).Length / 1MB, 1)
        Write-Host "  Downloaded Bitcoin Cash Node ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download Bitcoin Cash Node." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://github.com/$GithubRepo/releases" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Installing Bitcoin Cash Node..." -ForegroundColor Yellow
    $extractDir = Join-Path $tempDir "bch-extract"

    try {
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
        Write-Host "  Extracting archive..." -ForegroundColor Gray
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

        $innerDir = Get-ChildItem $extractDir | Select-Object -First 1
        $sourceDir = $innerDir.FullName

        if (Test-Path $BCHDefaultInstallDir) {
            $backup = "$BCHDefaultInstallDir.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Write-Host "  Backing up existing install to: $backup" -ForegroundColor Gray
            Rename-Item $BCHDefaultInstallDir $backup
        }

        New-Item -ItemType Directory -Path $BCHDefaultInstallDir -Force | Out-Null
        Copy-Item "$sourceDir\*" $BCHDefaultInstallDir -Recurse -Force

        $exeNames = @("bitcoin-cash-node-qt.exe", "bitcoin-qt.exe", "bitcoind.exe")
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $BCHDefaultInstallDir $exe
            if (Test-Path $testPath) { $foundExe = $testPath; break }
            $binPath = Join-Path $BCHDefaultInstallDir "bin\$exe"
            if (Test-Path $binPath) { $foundExe = $binPath; break }
        }

        if ($foundExe) {
            Write-Host "  Installed to: $BCHDefaultInstallDir" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Files extracted but executable not found in expected location." -ForegroundColor Yellow
            Write-Host "  Check: $BCHDefaultInstallDir" -ForegroundColor Gray
        }
    } catch {
        Write-Host "  ERROR: Failed to extract Bitcoin Cash Node." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $zipPath -ErrorAction SilentlyContinue
        Remove-Item $extractDir -Recurse -ErrorAction SilentlyContinue
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $BCHDefaultDataDir)) {
    New-Item -ItemType Directory -Path $BCHDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $BCHDefaultDataDir" -ForegroundColor Green
}

$confPath = Join-Path $BCHDefaultDataDir "bitcoin.conf"
if (Test-Path $confPath) {
    $backup = "$confPath.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    Copy-Item $confPath $backup -Force -ErrorAction SilentlyContinue
    Write-Host "  Backed up existing config to: $backup" -ForegroundColor Gray
}

if ($pruneEnabled) {
    $pruneValue = "prune=10000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoin.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoin.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoin.conf with pruning enabled (~10 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "Bitcoin Cash Node P2P (Port 8433)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8433 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow Bitcoin Cash Node peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8433" -ForegroundColor Green

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "Bitcoin Cash Node.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.Arguments = "-datadir=`"$BCHDefaultDataDir`""
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "Bitcoin Cash Node Wallet"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: Bitcoin Cash Node" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Bitcoin Cash Node READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to: $BCHDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Data folder:  $BCHDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Double-click 'Bitcoin Cash Node' on your Desktop" -ForegroundColor Yellow
Write-Host "     to open the wallet and start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from Bitcoin Cash Node:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start Bitcoin Cash Node now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting Bitcoin Cash Node..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$BCHDefaultDataDir`"", "-conf=bitcoin.conf"
    Write-Host "  Bitcoin Cash Node is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
