@echo off
echo ============================================
echo   Bitcoin Cash Node Installer
echo ============================================
echo.
echo This will download and install Bitcoin Cash Node
echo from GitHub (https://github.com/bitcoin-cash-node/bitcoin-cash-node)
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-bch-core.ps1"

pause
