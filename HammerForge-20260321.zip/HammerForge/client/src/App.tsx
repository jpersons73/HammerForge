import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import DownloadPage from "@/pages/dashboard";
import MonitorPage from "@/pages/monitor";

function Router() {
  return (
    <Switch>
      <Route path="/" component={DownloadPage} />
      <Route path="/monitor" component={MonitorPage} />
      <Route path="/miner" component={MonitorPage} />
      <Route path="/miner/:coin" component={MonitorPage} />
      <Route path="/miner/:coin/:wallet" component={MonitorPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
