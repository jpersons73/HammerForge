import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Shield, HardDrive, Cpu, Wifi, CheckCircle2, ExternalLink, Server, Zap, Globe, ChevronDown, ChevronUp, Terminal, Pickaxe, Trash2, Monitor, Router, Heart, X, Copy, Check, Mail, Activity } from "lucide-react";
import { SiBitcoin, SiGithub, SiBitcoincash, SiLitecoin, SiEthereum } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

function DgbIcon({ className }: { className?: string }) { return <img src="/images/dgb-logo.png" alt="DGB" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function UsdcIcon({ className }: { className?: string }) { return <img src="/images/usdc-logo.png" alt="USDC" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function XecIcon({ className }: { className?: string }) { return <img src="/images/xec-logo.png" alt="XEC" className={`w-5 h-5 rounded-full ${className || ""}`} />; }
function XrpIcon({ className }: { className?: string }) { return <img src="/images/xrp-logo.png" alt="XRP" className={`w-5 h-5 rounded-full ${className || ""}`} />; }

const donateAddresses = [
  { ticker: "BCH", name: "Bitcoin Cash", address: "qrqtvrm6vvvzq6w8jcu9alcv599lmsgpfv7a87edaa", icon: SiBitcoincash, color: "text-green-500", bgColor: "bg-green-500/10 border-green-500/30" },
  { ticker: "BTC", name: "Bitcoin", address: "bc1qczmq77nrrqsxn3uk8p007r9pf07uzq2t96w3g5", icon: SiBitcoin, color: "text-orange-500", bgColor: "bg-orange-500/10 border-orange-500/30" },
  { ticker: "DGB", name: "DigiByte", address: "DNi4NsZKH93QxBWn1RfQYizGtrKVhJcz6q", icon: DgbIcon, color: "text-blue-400", bgColor: "bg-blue-400/10 border-blue-400/30" },
  { ticker: "ETH", name: "Ethereum", address: "0x996c85e9137a9020C2a3d9b4889aA6a35185d368", icon: SiEthereum, color: "text-indigo-400", bgColor: "bg-indigo-400/10 border-indigo-400/30" },
  { ticker: "LTC", name: "Litecoin", address: "Lcnv6pvW4PPBfz2LSyf9GytSDvxUWwaiSB", icon: SiLitecoin, color: "text-gray-400", bgColor: "bg-gray-400/10 border-gray-400/30" },
  { ticker: "USDC", name: "USD Coin (ERC20)", address: "0x996c85e9137a9020C2a3d9b4889aA6a35185d368", icon: UsdcIcon, color: "text-blue-500", bgColor: "bg-blue-500/10 border-blue-500/30" },
  { ticker: "XEC", name: "eCash", address: "ecash:qrqtvrm6vvvzq6w8jcu9alcv599lmsgpfv8sn4zh", icon: XecIcon, color: "text-blue-400", bgColor: "bg-blue-400/10 border-blue-400/30" },
  { ticker: "XRP", name: "Ripple", address: "rJZxqccCyj93RBLBGqCqzxFgr5bURGJrrm", icon: XrpIcon, color: "text-white", bgColor: "bg-gray-600/10 border-gray-600/30" },
];

const coins = [
  { key: "BC2", label: "BC2 (BitcoinII)", stratum: 3333, rpc: 8332, p2p: 8333, addr: "1..., 3..., bc1q...", color: "text-primary", bgColor: "bg-primary/10 border-primary/30", github: "https://github.com/Bitcoin-II/BitcoinII-Core", githubLabel: "BitcoinII-Core", installer: "INSTALL-BC2-CORE.bat", dataDir: "BitcoinII", nodeLabel: "BitcoinII Core", coinbaseTag: "/BC2Solo/" },
  { key: "DGB", label: "DGB (DigiByte)", stratum: 3334, rpc: 14022, p2p: 12024, addr: "D..., S..., dgb1q...", color: "text-blue-500", bgColor: "bg-blue-500/10 border-blue-500/30", note: "SHA-256 (1 of 5 DGB algos)", github: "https://github.com/DigiByte-Core/digibyte", githubLabel: "DigiByte Core", installer: "INSTALL-DGB-CORE.bat", dataDir: "DigiByte", nodeLabel: "DigiByte Core", coinbaseTag: "/DGBSolo/" },
  { key: "BTC", label: "BTC (Bitcoin)", stratum: 3335, rpc: 8332, p2p: 8333, addr: "1..., 3..., bc1q...", color: "text-orange-500", bgColor: "bg-orange-500/10 border-orange-500/30", github: "https://bitcoincore.org", githubLabel: "Bitcoin Core", installer: "INSTALL-BTC-CORE.bat", dataDir: "Bitcoin", nodeLabel: "Bitcoin Core", coinbaseTag: "/BTCSolo/" },
  { key: "BCH", label: "BCH (Bitcoin Cash)", stratum: 3336, rpc: 8432, p2p: 8433, addr: "bitcoincash:q..., 1...", color: "text-green-500", bgColor: "bg-green-500/10 border-green-500/30", github: "https://github.com/bitcoin-cash-node/bitcoin-cash-node", githubLabel: "Bitcoin Cash Node", installer: "INSTALL-BCH-CORE.bat", dataDir: "BitcoinCash", nodeLabel: "Bitcoin Cash Node", coinbaseTag: "/BCHSolo/" },
  { key: "BSV", label: "BSV (Bitcoin SV)", stratum: 3337, rpc: 8532, p2p: 8533, addr: "1..., 3...", color: "text-yellow-500", bgColor: "bg-yellow-500/10 border-yellow-500/30", github: "https://github.com/bitcoin-sv/bitcoin-sv", githubLabel: "Bitcoin SV", installer: "INSTALL-BSV-CORE.bat", dataDir: "BitcoinSV", nodeLabel: "Bitcoin SV Node", coinbaseTag: "/BSVSolo/" },
  { key: "XEC", label: "XEC (eCash)", stratum: 3338, rpc: 8632, p2p: 8633, addr: "ecash:q..., 1...", color: "text-purple-500", bgColor: "bg-purple-500/10 border-purple-500/30", github: "https://github.com/Bitcoin-ABC/bitcoin-abc", githubLabel: "Bitcoin ABC", installer: "INSTALL-XEC-CORE.bat", dataDir: "BitcoinABC", nodeLabel: "Bitcoin ABC", coinbaseTag: "/XECSolo/" },
  { key: "FB", label: "FB (Fractal Bitcoin)", stratum: 3339, rpc: 8732, p2p: 8733, addr: "1..., 3..., bc1q...", color: "text-teal-500", bgColor: "bg-teal-500/10 border-teal-500/30", github: "https://github.com/fractal-bitcoin/fractal", githubLabel: "Fractal Bitcoin", installer: "INSTALL-FB-CORE.bat", dataDir: "FractalBitcoin", nodeLabel: "Fractal Bitcoin", coinbaseTag: "/FBSolo/" },
  { key: "PPC", label: "PPC (Peercoin)", stratum: 3340, rpc: 9902, p2p: 9901, addr: "P..., p..., pc1q...", color: "text-lime-500", bgColor: "bg-lime-500/10 border-lime-500/30", github: "https://github.com/peercoin/peercoin", githubLabel: "Peercoin", installer: "INSTALL-PPC-CORE.bat", dataDir: "Peercoin", nodeLabel: "Peercoin", coinbaseTag: "/PPCSolo/" },
];

function CoinPanel({ coin, isExpanded, onToggle }: { coin: typeof coins[0]; isExpanded: boolean; onToggle: () => void }) {
  return (
    <div
      className={`border rounded-lg transition-all duration-200 hover:shadow-md ${isExpanded ? coin.bgColor : 'border-border/50 hover:border-border'}`}
      data-testid={`panel-coin-${coin.key.toLowerCase()}`}
    >
      <div
        className="flex items-center justify-between p-3 cursor-pointer"
        onClick={(e) => { e.stopPropagation(); onToggle(); }}
      >
        <div className="flex items-center gap-3">
          <HardDrive className={`w-5 h-5 ${coin.color}`} />
          <div>
            <span className="font-medium text-sm text-foreground">{coin.label}</span>
            <span className="text-xs text-muted-foreground ml-2">Port {coin.stratum}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[10px] font-mono">SHA-256</Badge>
          {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </div>

      {isExpanded && (
        <div className="px-3 pb-3 space-y-3 border-t border-border/30 pt-3">
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <p className="text-muted-foreground">Wallet Installer</p>
              <code className="block px-2 py-1 bg-muted rounded font-mono text-foreground text-[11px]">{coin.installer}</code>
            </div>
            <div className="space-y-1">
              <p className="text-muted-foreground">Data Directory</p>
              <code className="block px-2 py-1 bg-muted rounded font-mono text-foreground text-[11px]">%APPDATA%\{coin.dataDir}</code>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="bg-muted/50 rounded p-2 text-center">
              <p className="text-muted-foreground text-[10px]">Stratum</p>
              <p className="font-mono text-foreground font-medium">:{coin.stratum}</p>
            </div>
            <div className="bg-muted/50 rounded p-2 text-center">
              <p className="text-muted-foreground text-[10px]">RPC</p>
              <p className="font-mono text-foreground font-medium">:{coin.rpc}</p>
            </div>
            <div className="bg-muted/50 rounded p-2 text-center">
              <p className="text-muted-foreground text-[10px]">P2P</p>
              <p className="font-mono text-foreground font-medium">:{coin.p2p}</p>
            </div>
          </div>

          <div className="text-xs space-y-1">
            <p className="text-muted-foreground">Addresses: <span className="text-foreground font-mono">{coin.addr}</span></p>
            <p className="text-muted-foreground">Coinbase Tag: <span className="text-foreground font-mono">{coin.coinbaseTag}</span></p>
            {coin.note && <p className="text-muted-foreground">{coin.note}</p>}
          </div>

          <div className="flex items-center gap-2">
            <a
              href={coin.github}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-primary hover:underline"
              data-testid={`link-github-${coin.key.toLowerCase()}`}
            >
              <SiGithub className="w-3 h-3" />
              {coin.githubLabel}
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          <div className="bg-muted/30 rounded p-2">
            <p className="text-[11px] text-muted-foreground font-mono">
              stratum+tcp://YOUR_LAN_IP:{coin.stratum}
            </p>
            <p className="text-[11px] text-muted-foreground font-mono">
              Worker: YOUR_WALLET.MinerName
            </p>
            <p className="text-[11px] text-muted-foreground font-mono">
              Pass: <span className="text-foreground">x</span> <span className="text-muted-foreground/60">or</span> <span className="text-foreground">notif=you@gmail.com</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function InstallerCard({ icon, title, filename, description, steps, isExpanded, onToggle, testId, accentClass }: {
  icon: React.ReactNode;
  title: string;
  filename: string;
  description: string;
  steps: string[];
  isExpanded: boolean;
  onToggle: () => void;
  testId: string;
  accentClass: string;
}) {
  return (
    <div
      className={`border rounded-lg transition-all duration-200 hover:shadow-md ${isExpanded ? accentClass : 'border-border/50 hover:border-border'}`}
      data-testid={testId}
    >
      <div
        className="flex items-center justify-between p-4 cursor-pointer"
        onClick={(e) => { e.stopPropagation(); onToggle(); }}
      >
        <div className="flex items-center gap-3">
          {icon}
          <div>
            <p className="font-medium text-sm text-foreground">{title}</p>
            <code className="text-[11px] font-mono text-muted-foreground">{filename}</code>
          </div>
        </div>
        {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </div>

      {isExpanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-border/30 pt-3">
          <p className="text-xs text-muted-foreground">{description}</p>
          <div className="space-y-1.5">
            {steps.map((step, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                <span className="text-muted-foreground">{step}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function DonateSection() {
  const [showDonate, setShowDonate] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState<string | null>(null);
  const { toast } = useToast();

  const copyAddress = (addr: string, ticker: string) => {
    navigator.clipboard.writeText(addr).then(() => {
      setCopiedAddr(addr);
      toast({ title: `${ticker} address copied!`, description: addr });
      setTimeout(() => setCopiedAddr(null), 2000);
    });
  };

  return (
    <div className="mb-8">
      {!showDonate ? (
        <div className="flex justify-center">
          <button
            onClick={() => setShowDonate(true)}
            className="group relative px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 border-2 border-amber-500/40 hover:border-amber-400/70 hover:from-amber-500/30 hover:via-orange-500/30 hover:to-amber-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/20 hover:scale-[1.02]"
            data-testid="button-show-donate"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center group-hover:bg-amber-500/30 transition-colors">
                <Heart className="w-5 h-5 text-amber-500 fill-amber-500" />
              </div>
              <div className="text-left">
                <p className="text-sm font-bold text-amber-400">Support Development</p>
                <p className="text-[11px] text-amber-500/70">Donate crypto to keep this project going</p>
              </div>
            </div>
          </button>
        </div>
      ) : (
        <div className="rounded-xl border-2 border-amber-500/30 bg-gradient-to-b from-amber-500/5 to-transparent p-5 relative shadow-lg shadow-amber-500/5">
          <button
            onClick={() => setShowDonate(false)}
            className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-close-donate"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <Heart className="w-6 h-6 text-amber-500 fill-amber-500" />
            <h3 className="text-xl font-bold text-foreground">Support Development</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Tap any address to copy it to your clipboard.</p>

          <div className="space-y-2">
            {donateAddresses.map((d) => {
              const IconComp = d.icon;
              const isCopied = copiedAddr === d.address;
              return (
                <div
                  key={d.ticker}
                  onClick={() => copyAddress(d.address, d.ticker)}
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${d.bgColor}`}
                  data-testid={`donate-${d.ticker.toLowerCase()}`}
                >
                  <div className={`w-9 h-9 rounded-full bg-background/50 flex items-center justify-center ${d.color}`}>
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`font-bold text-sm ${d.color}`}>{d.ticker}</span>
                      <span className="text-xs text-muted-foreground">{d.name}</span>
                    </div>
                    <p className="text-xs font-mono text-foreground/80 truncate">{d.address}</p>
                  </div>
                  <div className="flex-shrink-0 text-muted-foreground">
                    {isCopied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default function DownloadPage() {
  const [downloading, setDownloading] = useState(false);
  const [expandedCoins, setExpandedCoins] = useState<Set<string>>(new Set());
  const [expandedInstallers, setExpandedInstallers] = useState<Set<string>>(new Set());
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["installers"]));

  const handleDownload = () => {
    setDownloading(true);
    window.location.href = "/api/download";
    setTimeout(() => setDownloading(false), 3000);
  };

  const toggleCoin = (key: string) => {
    setExpandedCoins(prev => {
      if (prev.has(key)) {
        return new Set();
      }
      return new Set([key]);
    });
  };

  const toggleInstaller = (key: string) => {
    setExpandedInstallers(prev => {
      if (prev.has(key)) {
        return new Set();
      }
      return new Set([key]);
    });
  };

  const toggleSection = (key: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">

        <DonateSection />

        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <SiBitcoin className="w-8 h-8 text-primary" />
            </div>
            <div className="text-left">
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground" data-testid="text-title">
                HammerForge
              </h1>
              <p className="text-muted-foreground text-sm">your home node solution</p>
            </div>
          </div>

          <p className="text-base text-muted-foreground max-w-2xl mx-auto mb-3" data-testid="text-description">
            Solo mine 8 SHA-256 coins with your home miners and NiceHash rentals.
            All coins run simultaneously. No pool fees. 100% block rewards.
          </p>

          <div className="flex items-center justify-center gap-2 flex-wrap mb-6">
            {coins.map(c => (
              <Badge
                key={c.key}
                variant="secondary"
                className="text-xs"
                data-testid={`badge-${c.key.toLowerCase()}`}
              >
                {c.key} :{c.stratum}
              </Badge>
            ))}
          </div>

          <Button
            size="lg"
            onClick={handleDownload}
            disabled={downloading}
            className="text-lg gap-3"
            data-testid="button-download"
          >
            <Download className="w-5 h-5" />
            {downloading ? "Downloading..." : "Download HammerForge"}
          </Button>

          <div className="flex items-center gap-3 mt-3">
            <Link href="/monitor">
              <Button variant="outline" size="sm" className="gap-2 text-sm" data-testid="button-goto-monitor">
                <Activity className="w-4 h-4" />
                Go to miner page
              </Button>
            </Link>
          </div>

          <p className="text-xs text-muted-foreground mt-2">
            ZIP package with all installers included — click items below to explore
          </p>
        </div>

        <div className="space-y-6">

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("installers"); }}
              data-testid="section-installers"
            >
              <Terminal className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">What's in the Package</h2>
              {expandedSections.has("installers") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("installers") && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                {coins.map(c => (
                  <InstallerCard
                    key={c.key}
                    icon={<HardDrive className={`w-5 h-5 ${c.color}`} />}
                    title={`${c.key} Wallet Installer`}
                    filename={c.installer}
                    description={`Downloads and installs ${c.nodeLabel} wallet with mining-ready configuration. Sets up RPC credentials and firewall rules automatically.`}
                    steps={[
                      `Double-click ${c.installer} (Run as Admin)`,
                      `${c.nodeLabel} is downloaded and installed`,
                      `RPC config created in %APPDATA%\\${c.dataDir}`,
                      `Firewall rules added for ports ${c.rpc} and ${c.p2p}`,
                      "Open wallet and let blockchain sync fully",
                    ]}
                    isExpanded={expandedInstallers.has(c.key)}
                    onToggle={() => toggleInstaller(c.key)}
                    testId={`installer-${c.key.toLowerCase()}`}
                    accentClass={c.bgColor}
                  />
                ))}

                <InstallerCard
                  icon={<Pickaxe className="w-5 h-5 text-primary" />}
                  title="Mining Setup (All Coins)"
                  filename="INSTALL-MINING.bat"
                  description="Sets up the stratum mining server for all 8 coins. Enter your wallet address for each coin you want to mine. Creates individual desktop shortcuts."
                  steps={[
                    "Double-click INSTALL-MINING.bat (Run as Admin)",
                    "Enter wallet addresses for coins you want to mine (press Enter to skip any)",
                    "Node.js is installed automatically if needed",
                    "Config files created for each coin (config-bc2.json, config-dgb.json, etc.)",
                    "Desktop shortcuts created — one per coin",
                    "Double-click a shortcut to start solo mining that coin",
                  ]}
                  isExpanded={expandedInstallers.has("mining")}
                  onToggle={() => toggleInstaller("mining")}
                  testId="installer-mining"
                  accentClass="bg-primary/10 border-primary/30"
                />

                <InstallerCard
                  icon={<Trash2 className="w-5 h-5 text-red-500" />}
                  title="Clean Uninstaller"
                  filename="UNINSTALL.bat"
                  description="Removes the stratum mining server, desktop shortcuts, and firewall rules. Your blockchain data and wallets are never touched."
                  steps={[
                    "Double-click UNINSTALL.bat (Run as Admin)",
                    "Stratum server files removed",
                    "Firewall rules cleaned up",
                    "Desktop shortcuts removed",
                    "Blockchain data and wallets stay safe",
                  ]}
                  isExpanded={expandedInstallers.has("uninstall")}
                  onToggle={() => toggleInstaller("uninstall")}
                  testId="installer-uninstall"
                  accentClass="bg-red-500/10 border-red-500/30"
                />
              </div>
            )}
          </div>

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("coins"); }}
              data-testid="section-coins"
            >
              <SiBitcoin className="w-5 h-5 text-orange-500" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">Supported Coins</h2>
              <Badge variant="secondary" className="text-[10px]">8 coins</Badge>
              {expandedSections.has("coins") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("coins") && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                {coins.map(c => (
                  <CoinPanel
                    key={c.key}
                    coin={c}
                    isExpanded={expandedCoins.has(c.key)}
                    onToggle={() => toggleCoin(c.key)}
                  />
                ))}
              </div>
            )}
          </div>

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("features"); }}
              data-testid="section-features"
            >
              <Zap className="w-5 h-5 text-amber-500" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">Features</h2>
              {expandedSections.has("features") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("features") && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-stratum">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Server className="w-4 h-4 text-primary" />
                      Stratum Server
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    8 coins on ports 3333-3340. All run simultaneously. Real block templates from each node for actual block winning.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-upnp">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Router className="w-4 h-4 text-primary" />
                      UPnP Auto Port Forward
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Automatically opens stratum ports on your router via UPnP. No manual port forwarding needed for NiceHash.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-nicehash">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Globe className="w-4 h-4 text-amber-500" />
                      NiceHash Ready
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Rent SHA-256 hashpower on NiceHash and point it at your stratum server to boost solo mining for any coin.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-nodejs">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-primary" />
                      Auto Node.js Install
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Installs Node.js automatically using the official MSI installer if not already on your system.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-firewall">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Shield className="w-4 h-4 text-primary" />
                      Firewall + RPC Config
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Opens firewall ports for stratum and P2P. Configures secure RPC credentials automatically per coin.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-shortcuts">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Wifi className="w-4 h-4 text-primary" />
                      Per-Coin Shortcuts
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Separate desktop shortcuts for each coin. Each connects to its own node and port. All run at the same time.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-blockpopup">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Monitor className="w-4 h-4 text-green-500" />
                      Block Found Popup
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    When you find a block, a popup window launches with full details — height, hash, reward, worker, and acceptance status.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-email">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Mail className="w-4 h-4 text-green-500" />
                      Email Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Get emailed when you find a block! Set your email in the miner password field: <code className="text-foreground bg-muted px-1 rounded">notif=you@gmail.com</code>
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-vardiff">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-500" />
                      Variable Difficulty
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Automatically adjusts share difficulty to match your miner's hashrate. Works with tiny Bitaxe to rented NiceHash TH/s.
                  </CardContent>
                </Card>

                <Card className="border-border/50 hover:shadow-md transition-shadow" data-testid="card-feature-uninstall">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      Clean Uninstall
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    Includes uninstaller that removes the stratum server and firewall rules. Blockchain data stays safe.
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("nicehash"); }}
              data-testid="section-nicehash"
            >
              <Globe className="w-5 h-5 text-amber-500" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">NiceHash Setup</h2>
              {expandedSections.has("nicehash") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("nicehash") && (
              <Card className="border-amber-500/30 bg-amber-500/5" data-testid="card-nicehash">
                <CardContent className="pt-4 text-xs text-muted-foreground space-y-3">
                  <p>
                    Rent SHA-256 hashpower on NiceHash and point it at your stratum server to boost your solo mining chances.
                    UPnP automatically opens the ports on your router.
                  </p>
                  <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                    <p className="font-medium text-foreground text-sm">NiceHash Configuration:</p>
                    <ol className="list-decimal list-inside space-y-1.5">
                      <li>Start mining for any coin — UPnP auto-forwards the port</li>
                      <li>On NiceHash, select <strong>SHA256</strong> algorithm</li>
                      <li>Set pool to <code className="px-1.5 py-0.5 bg-background rounded text-foreground font-mono">stratum+tcp://YOUR_PUBLIC_IP:PORT</code></li>
                      <li>Your public IP is shown in the mining CMD window via UPnP</li>
                      <li>Worker: <code className="px-1.5 py-0.5 bg-background rounded text-foreground font-mono">YOUR_WALLET.NiceHash</code> / Password: <code className="px-1.5 py-0.5 bg-background rounded text-foreground font-mono">x</code> (or <code className="px-1.5 py-0.5 bg-background rounded text-foreground font-mono">notif=you@gmail.com</code>)</li>
                    </ol>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 mt-2">
                      {coins.map(c => (
                        <div key={c.key} className="text-center p-1 rounded bg-background/50">
                          <span className={`font-medium ${c.color}`}>{c.key}</span>
                          <span className="block text-muted-foreground font-mono">:{c.stratum}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("miners"); }}
              data-testid="section-miners"
            >
              <Cpu className="w-5 h-5 text-green-500" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">Supported Miners</h2>
              {expandedSections.has("miners") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("miners") && (
              <Card className="border-border/50" data-testid="card-miners">
                <CardContent className="pt-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { name: "MagicMiner (all models)", desc: "LAN-connected ASIC" },
                      { name: "Luckyminer (LV06, etc.)", desc: "LAN-connected ASIC" },
                      { name: "Avalon Nano 3S", desc: "USB miner" },
                      { name: "Bitaxe", desc: "Open-source miner" },
                      { name: "NiceHash SHA-256 rentals", desc: "Rented hashpower" },
                      { name: "Any SHA-256 stratum miner", desc: "Standard protocol" },
                    ].map((m, i) => (
                      <div key={i} className="flex items-center gap-2 p-2 rounded hover:bg-muted/50 transition-colors">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <div>
                          <span className="text-sm text-foreground">{m.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">{m.desc}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <div
              className="flex items-center gap-2 mb-3 cursor-pointer group"
              onClick={(e) => { e.stopPropagation(); toggleSection("requirements"); }}
              data-testid="section-requirements"
            >
              <Shield className="w-5 h-5 text-blue-500" />
              <h2 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">Requirements</h2>
              {expandedSections.has("requirements") ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>

            {expandedSections.has("requirements") && (
              <Card className="border-border/50" data-testid="card-requirements">
                <CardContent className="pt-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      "Windows 10 or 11 (64-bit)",
                      "Internet connection for initial download",
                      "Administrator access",
                      "Sufficient disk space for blockchain data",
                    ].map((req, i) => (
                      <div key={i} className="flex items-center gap-2 p-2 rounded">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{req}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border/30 text-center">
          <Button
            size="lg"
            onClick={handleDownload}
            disabled={downloading}
            className="text-base gap-2 mb-4"
            data-testid="button-download-bottom"
          >
            <Download className="w-5 h-5" />
            {downloading ? "Downloading..." : "Download HammerForge"}
          </Button>

          <div className="flex items-center justify-center gap-3 flex-wrap mt-4">
            {coins.map(c => (
              <a
                key={c.key}
                href={c.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                data-testid={`link-github-bottom-${c.key.toLowerCase()}`}
              >
                <SiGithub className="w-3 h-3" />
                {c.githubLabel}
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">Solo mining. No pool fees. 100% of block rewards go to you.</p>
        </div>
      </div>
    </div>
  );
}
