@echo off
echo ============================================
echo   Solo Mining Setup
echo   SHA-256 Multi-Coin HammerForge
echo   BC2 / DGB / BTC / BCH / BSV / XEC / FB / PPC
echo ============================================
echo.
echo This will set up stratum servers for solo
echo mining with home miners and NiceHash rentals.
echo.
echo All coins can run at the same time!
echo Each gets its own port and process.
echo.
echo Make sure your coin wallets are installed
echo and synced before running this.
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-mining.ps1"

pause
