@echo off
echo ============================================
echo   Peercoin Wallet Installer
echo ============================================
echo.
echo This will download and install Peercoin
echo from github.com/peercoin/peercoin
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-ppc-core.ps1"

pause
