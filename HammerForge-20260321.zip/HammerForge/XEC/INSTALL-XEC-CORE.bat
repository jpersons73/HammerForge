@echo off
echo ============================================
echo   eCash (Bitcoin ABC) Node Installer
echo ============================================
echo.
echo This will download and install Bitcoin ABC
echo from GitHub (https://github.com/Bitcoin-ABC/bitcoin-abc)
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-xec-core.ps1"

pause
