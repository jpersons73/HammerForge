# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# eCash (Bitcoin ABC) Node Installer
# Downloads and installs Bitcoin ABC from GitHub
# Double-click INSTALL-XEC-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "0.32.10"
$GithubRepo = "Bitcoin-ABC/bitcoin-abc"
$AssetPattern = "win64-setup.*\.exe$"
$XECDefaultInstallDir = "$env:ProgramFiles\BitcoinABC"
$XECDefaultDataDir = "$env:APPDATA\BitcoinABC"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Windows asset found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-XECExecutable {
    $searchDirs = @(
        "$env:ProgramFiles\BitcoinABC",
        "${env:ProgramFiles(x86)}\BitcoinABC",
        "$env:LOCALAPPDATA\BitcoinABC",
        "$env:LOCALAPPDATA\Programs\BitcoinABC",
        "C:\BitcoinABC",
        "$env:ProgramFiles\Bitcoin ABC",
        "${env:ProgramFiles(x86)}\Bitcoin ABC",
        "$env:LOCALAPPDATA\Bitcoin ABC",
        "$env:LOCALAPPDATA\Programs\Bitcoin ABC",
        "$env:ProgramFiles\eCash",
        "${env:ProgramFiles(x86)}\eCash",
        "$env:LOCALAPPDATA\eCash",
        "$env:APPDATA\BitcoinABC"
    )
    $exeNames = @("bitcoin-abc-qt.exe", "bitcoin-qt.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = (Split-Path $binPath -Parent); Exe = $binPath }
            }
            $daemonPath = Join-Path $dir "daemon\$exe"
            if (Test-Path $daemonPath) {
                return @{ Dir = (Split-Path $daemonPath -Parent); Exe = $daemonPath }
            }
        }
    }

    $proc = Get-Process -Name "bitcoin-abc-qt","bitcoin-qt" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path) {
        return @{ Dir = (Split-Path $proc.Path -Parent); Exe = $proc.Path }
    }

    foreach ($drive in @("C","D","E")) {
        $searchRoot = "${drive}:\"
        if (-not (Test-Path $searchRoot)) { continue }
        $found = Get-ChildItem -Path $searchRoot -Filter "bitcoin-abc-qt.exe" -Recurse -Depth 4 -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            return @{ Dir = $found.DirectoryName; Exe = $found.FullName }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  eCash (Bitcoin ABC) Node Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-XEC-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing eCash (Bitcoin ABC) installation..." -ForegroundColor Yellow
$existing = Find-XECExecutable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  Bitcoin ABC already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  Bitcoin ABC not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~10 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain (~200+ GB)." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "bitcoin-abc-$FallbackVersion-win64-setup-unsigned.exe"
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading Bitcoin ABC $useTag..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "xecsetup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $exePath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $exePath)
        $sizeMB = [math]::Round((Get-Item $exePath).Length / 1MB, 1)
        Write-Host "  Downloaded Bitcoin ABC ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download Bitcoin ABC." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://github.com/$GithubRepo/releases" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Installing Bitcoin ABC..." -ForegroundColor Yellow

    try {
        Write-Host "  Running installer silently..." -ForegroundColor Gray
        Write-Host "  Install directory: $XECDefaultInstallDir" -ForegroundColor Gray

        $installArgs = "/S /D=$XECDefaultInstallDir"
        $process = Start-Process -FilePath $exePath -ArgumentList $installArgs -Wait -PassThru
        if ($process.ExitCode -ne 0) {
            Write-Host "  WARNING: Installer exited with code $($process.ExitCode)." -ForegroundColor Yellow
            Write-Host "  The installation may still have succeeded." -ForegroundColor Gray
        }

        $exeNames = @("bitcoin-abc-qt.exe", "bitcoin-qt.exe", "bitcoind.exe")
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $XECDefaultInstallDir $exe
            if (Test-Path $testPath) { $foundExe = $testPath; break }
            $binPath = Join-Path $XECDefaultInstallDir "bin\$exe"
            if (Test-Path $binPath) { $foundExe = $binPath; break }
            $daemonPath = Join-Path $XECDefaultInstallDir "daemon\$exe"
            if (Test-Path $daemonPath) { $foundExe = $daemonPath; break }
        }

        if ($foundExe) {
            Write-Host "  Installed to: $XECDefaultInstallDir" -ForegroundColor Green
        } else {
            Write-Host "  Searching for eCash executable..." -ForegroundColor Gray
            $result = Find-XECExecutable
            if ($result) {
                $foundExe = $result.Exe
                Write-Host "  Found at: $($result.Dir)" -ForegroundColor Green
            } else {
                Write-Host "  WARNING: Could not find bitcoin-abc-qt.exe automatically." -ForegroundColor Yellow
                Write-Host ""
                $manualPath = Read-Host "  Enter full path to bitcoin-abc-qt.exe (or press Enter to skip)"
                $manualPath = $manualPath.Trim().Trim('"')
                if ($manualPath -and (Test-Path $manualPath)) {
                    $foundExe = $manualPath
                    Write-Host "  Using: $foundExe" -ForegroundColor Green
                } else {
                    Write-Host "  Skipping -- you can create a desktop shortcut manually later." -ForegroundColor Gray
                }
            }
        }
    } catch {
        Write-Host "  ERROR: Failed to install Bitcoin ABC." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $exePath -ErrorAction SilentlyContinue
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $XECDefaultDataDir)) {
    New-Item -ItemType Directory -Path $XECDefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $XECDefaultDataDir" -ForegroundColor Green
}

if ($pruneEnabled) {
    $confPath = Join-Path $XECDefaultDataDir "bitcoin.conf"
    $pruneValue = "prune=10000"
    if (Test-Path $confPath) {
        $confContent = Get-Content $confPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $confPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoin.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $confPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoin.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $confPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoin.conf with pruning enabled (~10 GB)" -ForegroundColor Green
    }
} else {
    Write-Host "  Config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
}

$firewallRuleName = "eCash Node P2P (Port 8633)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8633 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow eCash (Bitcoin ABC) peer-to-peer connections" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8633" -ForegroundColor Green

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "eCash Node.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.Arguments = "-datadir=`"$XECDefaultDataDir`""
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "eCash (Bitcoin ABC) Node"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: eCash Node" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  eCash (Bitcoin ABC) READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to: $XECDefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Data folder:  $XECDefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Double-click 'eCash Node' on your Desktop" -ForegroundColor Yellow
Write-Host "     to open the wallet and start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from eCash Node:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host "       eCash uses CashAddr format (ecash:q...)" -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start eCash Node now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting eCash Node..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$XECDefaultDataDir`"", "-conf=bitcoin.conf"
    Write-Host "  eCash Node is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
