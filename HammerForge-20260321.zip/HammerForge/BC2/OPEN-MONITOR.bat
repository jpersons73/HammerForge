@echo off
echo Opening HammerForge Mining Monitor...
echo.
start "" "http://localhost:5000/monitor"
echo Monitor page opened in your default browser.
echo.
echo If nothing opened, make sure the mining server is running first.
echo (Double-click the desktop shortcut for this coin)
echo.
pause
