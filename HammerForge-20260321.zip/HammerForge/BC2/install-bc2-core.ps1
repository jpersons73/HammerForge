# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# BitcoinII-Core Wallet Installer
# Downloads and installs BitcoinII-Core from GitHub
# Double-click INSTALL-BC2-CORE.bat to run this

$ErrorActionPreference = "Continue"

$FallbackVersion = "29.1.0"
$GithubRepo = "Bitcoin-II/BitcoinII-Core"
$AssetPattern = "win64-GUI\.zip$"
$BC2DefaultInstallDir = "$env:ProgramFiles\BitcoinII"
$BC2DefaultDataDir = "$env:APPDATA\BitcoinII"

function Get-LatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $apiUrl = "https://api.github.com/repos/$GithubRepo/releases/latest"
        $headers = @{ "User-Agent" = "SoloMinerInstaller" }
        $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 15
        $tag = $response.tag_name
        $version = $tag -replace '^v', ''
        foreach ($asset in $response.assets) {
            if ($asset.name -match $AssetPattern) {
                return @{
                    Version = $version
                    Tag = $tag
                    FileName = $asset.name
                    Url = $asset.browser_download_url
                }
            }
        }
        Write-Host "  No matching Windows asset found in latest release ($tag)" -ForegroundColor Yellow
    } catch {
        Write-Host "  Could not check GitHub for latest version: $_" -ForegroundColor Yellow
    }
    return $null
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-BC2Executable {
    $searchDirs = @(
        "$env:ProgramFiles\BitcoinII",
        "${env:ProgramFiles(x86)}\BitcoinII",
        "$env:LOCALAPPDATA\BitcoinII",
        "C:\BitcoinII",
        "$env:ProgramFiles\Bitcoin2",
        "${env:ProgramFiles(x86)}\Bitcoin2",
        "C:\Bitcoin2"
    )
    $exeNames = @("bitcoinII-qt.exe", "bitcoin-qt.exe", "bitcoinIId.exe", "bitcoind.exe")

    foreach ($dir in $searchDirs) {
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $dir $exe
            if (Test-Path $testPath) {
                return @{ Dir = $dir; Exe = $testPath }
            }
            $binPath = Join-Path $dir "bin\$exe"
            if (Test-Path $binPath) {
                return @{ Dir = $dir; Exe = $binPath }
            }
        }
    }
    return $null
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  BitcoinII-Core Wallet Installer" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Host "ERROR: This installer requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click INSTALL-BC2-CORE.bat and select 'Run as administrator'" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/4] Checking for existing BitcoinII-Core installation..." -ForegroundColor Yellow
$existing = Find-BC2Executable
$foundExe = $null
$pruneEnabled = $false

if ($existing) {
    Write-Host "  BitcoinII-Core already installed at: $($existing.Dir)" -ForegroundColor Green
    $foundExe = $existing.Exe
    Write-Host "  Skipping download -- writing config files..." -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "  BitcoinII-Core not found. Will download and install." -ForegroundColor Yellow
    Write-Host ""

    Write-Host "  Would you like to enable blockchain pruning?" -ForegroundColor White
    Write-Host "  Pruning keeps only the last ~1 month of blocks (~5 GB)" -ForegroundColor Gray
    Write-Host "  instead of the full blockchain." -ForegroundColor Gray
    Write-Host "  Mining works fine with pruning enabled." -ForegroundColor Gray
    Write-Host ""
    $enablePruning = Read-Host "  Enable pruning? (y/n)"
    $pruneEnabled = ($enablePruning -eq "y")
    if ($pruneEnabled) {
        Write-Host "  Pruning will be enabled (keeping ~1 month of blocks)." -ForegroundColor Green
    } else {
        Write-Host "  Full blockchain will be kept (no pruning)." -ForegroundColor Gray
    }
    Write-Host ""

    Write-Host "[2/4] Checking for latest version..." -ForegroundColor Yellow
    $release = Get-LatestRelease
    if ($release) {
        $useVersion = $release.Version
        $useTag = $release.Tag
        $useFileName = $release.FileName
        $useUrl = $release.Url
        Write-Host "  Latest version: $useTag" -ForegroundColor Green
    } else {
        $useVersion = $FallbackVersion
        $useTag = "v$FallbackVersion"
        $useFileName = "BitcoinII-$FallbackVersion-x86_64-win64-GUI.zip"
        $useUrl = "https://github.com/$GithubRepo/releases/download/$useTag/$useFileName"
        Write-Host "  Using fallback version: $useTag" -ForegroundColor Yellow
    }

    Write-Host "`n[3/4] Downloading BitcoinII-Core $useTag..." -ForegroundColor Yellow
    $tempDir = Join-Path $env:TEMP "bc2setup"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $zipPath = Join-Path $tempDir $useFileName

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        Write-Host "  URL: $useUrl" -ForegroundColor Gray
        Write-Host "  Downloading... (this may take a few minutes)" -ForegroundColor Gray
        $wc.DownloadFile($useUrl, $zipPath)
        $sizeMB = [math]::Round((Get-Item $zipPath).Length / 1MB, 1)
        Write-Host "  Downloaded BitcoinII-Core ($sizeMB MB)" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Failed to download BitcoinII-Core." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Please download manually from:" -ForegroundColor Yellow
        Write-Host "  https://github.com/$GithubRepo/releases" -ForegroundColor Cyan
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "`n  Installing BitcoinII-Core..." -ForegroundColor Yellow
    $extractDir = Join-Path $tempDir "bc2-extract"

    try {
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
        Write-Host "  Extracting archive..." -ForegroundColor Gray
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

        $innerDir = Get-ChildItem $extractDir | Select-Object -First 1
        $sourceDir = $innerDir.FullName

        if (Test-Path $BC2DefaultInstallDir) {
            $backup = "$BC2DefaultInstallDir.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Write-Host "  Backing up existing install to: $backup" -ForegroundColor Gray
            Rename-Item $BC2DefaultInstallDir $backup
        }

        New-Item -ItemType Directory -Path $BC2DefaultInstallDir -Force | Out-Null
        Copy-Item "$sourceDir\*" $BC2DefaultInstallDir -Recurse -Force

        $exeNames = @("bitcoinII-qt.exe", "bitcoin-qt.exe", "bitcoinIId.exe", "bitcoind.exe")
        foreach ($exe in $exeNames) {
            $testPath = Join-Path $BC2DefaultInstallDir $exe
            if (Test-Path $testPath) { $foundExe = $testPath; break }
            $binPath = Join-Path $BC2DefaultInstallDir "bin\$exe"
            if (Test-Path $binPath) { $foundExe = $binPath; break }
        }

        if ($foundExe) {
            Write-Host "  Installed to: $BC2DefaultInstallDir" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Files extracted but executable not found in expected location." -ForegroundColor Yellow
            Write-Host "  Check: $BC2DefaultInstallDir" -ForegroundColor Gray
        }
    } catch {
        Write-Host "  ERROR: Failed to extract BitcoinII-Core." -ForegroundColor Red
        Write-Host "  Error: $_" -ForegroundColor Gray
        Read-Host "Press Enter to exit"
        exit 1
    } finally {
        Remove-Item $zipPath -ErrorAction SilentlyContinue
        Remove-Item $extractDir -Recurse -ErrorAction SilentlyContinue
    }
}

Write-Host "`n[4/4] Finishing setup..." -ForegroundColor Yellow

if (-not (Test-Path $BC2DefaultDataDir)) {
    New-Item -ItemType Directory -Path $BC2DefaultDataDir -Force | Out-Null
    Write-Host "  Created data directory: $BC2DefaultDataDir" -ForegroundColor Green
}

$dataDirs = @($BC2DefaultDataDir, "$env:LOCALAPPDATA\BitcoinII")
$wrongConfNames = @("bitcoin.conf", "Bitcoin.conf", "BitcoinII.conf")

foreach ($dataDir in $dataDirs) {
    if (-not (Test-Path $dataDir)) { continue }
    foreach ($name in $wrongConfNames) {
        $testPath = Join-Path $dataDir $name
        if (Test-Path $testPath) {
            $backup = "$testPath.old.$(Get-Date -Format 'yyyyMMdd_HHmmss')"
            Copy-Item $testPath $backup -Force -ErrorAction SilentlyContinue
            Remove-Item $testPath -Force -ErrorAction SilentlyContinue
            Write-Host "  Removed wrong-named config: $name (backed up)" -ForegroundColor Yellow
        }
    }
    $correctConf = Join-Path $dataDir "bitcoinII.conf"
    if (Test-Path $correctConf) {
        $content = Get-Content $correctConf -Raw -ErrorAction SilentlyContinue
        if ($content -and $content.Contains("server=1")) {
            Write-Host "  Existing bitcoinII.conf with RPC settings preserved: $correctConf" -ForegroundColor Green
        } else {
            Write-Host "  Found bitcoinII.conf but no RPC settings -- will be configured by mining installer" -ForegroundColor Gray
        }
    } else {
        Write-Host "  RPC config will be created by INSTALL-MINING.bat during mining setup." -ForegroundColor Gray
    }
}

if ($pruneEnabled) {
    $bc2ConfPath = Join-Path $BC2DefaultDataDir "bitcoinII.conf"
    $pruneValue = "prune=5000"
    if (Test-Path $bc2ConfPath) {
        $confContent = Get-Content $bc2ConfPath -Raw
        if ($confContent -match "(?m)^\s*prune\s*=") {
            $confContent = $confContent -replace "(?m)^\s*prune\s*=.*$", $pruneValue
            Set-Content -Path $bc2ConfPath -Value $confContent -NoNewline
            Write-Host "  Updated pruning setting in bitcoinII.conf" -ForegroundColor Green
        } else {
            Add-Content -Path $bc2ConfPath -Value "`r`n$pruneValue"
            Write-Host "  Added pruning to existing bitcoinII.conf" -ForegroundColor Green
        }
    } else {
        Set-Content -Path $bc2ConfPath -Value "$pruneValue`r`n"
        Write-Host "  Created bitcoinII.conf with pruning enabled (~5 GB)" -ForegroundColor Green
    }
}

$oldFirewallRule = "BitcoinII-Core P2P (Port 8333)"
$existingOldRule = Get-NetFirewallRule -DisplayName $oldFirewallRule -ErrorAction SilentlyContinue
if ($existingOldRule) {
    Remove-NetFirewallRule -DisplayName $oldFirewallRule
    Write-Host "  Removed old firewall rule for port 8333" -ForegroundColor Gray
}
$oldFirewallRule8233 = "BitcoinII-Core P2P (Port 8233)"
$existingOldRule8233 = Get-NetFirewallRule -DisplayName $oldFirewallRule8233 -ErrorAction SilentlyContinue
if ($existingOldRule8233) {
    Remove-NetFirewallRule -DisplayName $oldFirewallRule8233
    Write-Host "  Removed old firewall rule for port 8233" -ForegroundColor Gray
}
$firewallRuleName = "BitcoinII-Core P2P (Port 8338)"
$existingRule = Get-NetFirewallRule -DisplayName $firewallRuleName -ErrorAction SilentlyContinue
if ($existingRule) {
    Remove-NetFirewallRule -DisplayName $firewallRuleName
}
New-NetFirewallRule -DisplayName $firewallRuleName `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 8338 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow BitcoinII-Core peer-to-peer connections on port 8338" | Out-Null
Write-Host "  Firewall rule added: Allow TCP port 8338 (BC2 P2P)" -ForegroundColor Green

if ($foundExe) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktopPath "BitcoinII-Core.lnk"

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $foundExe
    $shortcut.WorkingDirectory = (Split-Path $foundExe)
    $shortcut.Description = "BitcoinII-Core Wallet"
    $shortcut.Save()

    Write-Host "  Desktop shortcut created: BitcoinII-Core" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  BitcoinII-Core READY" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to: $BC2DefaultInstallDir" -ForegroundColor Cyan
Write-Host "  Data folder:  $BC2DefaultDataDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor White
Write-Host ""
Write-Host "  1. Double-click 'BitcoinII-Core' on your Desktop" -ForegroundColor Yellow
Write-Host "     to open the wallet and start syncing the blockchain." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. The first sync will take some time. Let it finish" -ForegroundColor Yellow
Write-Host "     before starting the mining setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Once synced, run INSTALL-MINING.bat to set up" -ForegroundColor Yellow
Write-Host "     your stratum server for solo mining." -ForegroundColor Gray
Write-Host ""
Write-Host "  TIP: Get a wallet address from BitcoinII-Core:" -ForegroundColor White
Write-Host "       File > Receiving Addresses > New" -ForegroundColor Gray
Write-Host ""

$startNow = Read-Host "  Start BitcoinII-Core now? (y/n)"
if ($startNow -eq "y" -and $foundExe) {
    Write-Host ""
    Write-Host "  Starting BitcoinII-Core..." -ForegroundColor Yellow
    Start-Process $foundExe -ArgumentList "-datadir=`"$BC2DefaultDataDir`"", "-conf=bitcoinII.conf"
    Write-Host "  BitcoinII-Core is starting. Let it sync fully before mining." -ForegroundColor Green
}

Write-Host ""
Read-Host "Press Enter to exit"
