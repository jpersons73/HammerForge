@echo off
echo ============================================
echo   BitcoinII-Core Uninstaller
echo ============================================
echo.
echo This will remove BitcoinII-Core from your system.
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0uninstall-bc2-core.ps1"

pause
