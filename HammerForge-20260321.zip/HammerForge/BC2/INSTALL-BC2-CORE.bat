@echo off
echo ============================================
echo   BitcoinII-Core Wallet Installer
echo ============================================
echo.
echo This will download and install BitcoinII-Core
echo from GitHub (https://github.com/Bitcoin-II/BitcoinII-Core)
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-bc2-core.ps1"

pause
