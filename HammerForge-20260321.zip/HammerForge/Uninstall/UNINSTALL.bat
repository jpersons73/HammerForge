@echo off
echo ============================================
echo   Solo Mining - Uninstaller
echo ============================================
echo.
echo Coin wallets and blockchain data will NOT be removed.
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting elevated permissions...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"

pause
