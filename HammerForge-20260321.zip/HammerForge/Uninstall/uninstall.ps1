# Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
# Proprietary and confidential. See LICENSE file for details.
# Solo Mining Uninstaller (All Coins)
# Run as Administrator

$ErrorActionPreference = "SilentlyContinue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((Split-Path -Leaf $ScriptDir) -eq "Uninstall") {
    $ProjectDir = Split-Path -Parent $ScriptDir
} else {
    $ProjectDir = $ScriptDir
}

$AllCoins = @("BC2", "DGB", "BTC", "BCH", "BSV", "XEC", "FB", "PPC")
$AllPorts = @(3333, 3334, 3335, 3336, 3337, 3338, 3339, 3340)

Write-Host ""
Write-Host "============================================" -ForegroundColor Yellow
Write-Host "  Solo Mining Uninstaller" -ForegroundColor Yellow
Write-Host "  BC2 / DGB / BTC / BCH / BSV / XEC / FB / PPC" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "  This will remove:" -ForegroundColor White
Write-Host "    - Stratum server files and configs" -ForegroundColor Gray
Write-Host "    - Firewall rules (ports 3333-3340)" -ForegroundColor Gray
Write-Host "    - Desktop shortcuts (all coins)" -ForegroundColor Gray
Write-Host ""
Write-Host "  This will NOT remove:" -ForegroundColor White
Write-Host "    - Coin wallets or node software" -ForegroundColor Gray
Write-Host "    - Blockchain data and wallet files" -ForegroundColor Gray
Write-Host "    - Node.js" -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "Proceed with uninstall? (y/n)"
if ($confirm -ne "y") {
    Write-Host "Cancelled." -ForegroundColor Gray
    exit 0
}

Write-Host ""

Write-Host "Stopping services..." -ForegroundColor Yellow
foreach ($coin in $AllCoins) {
    taskkill /f /im node.exe /fi "WINDOWTITLE eq $coin HammerForge*" 2>$null
}

Write-Host "Removing firewall rules..." -ForegroundColor Yellow
foreach ($i in 0..($AllCoins.Length - 1)) {
    $coin = $AllCoins[$i]
    $port = $AllPorts[$i]
    $ruleNames = @(
        "HammerForge $coin Stratum (Port $port)",
        "HammerForge Stratum (Port $port)"
    )
    foreach ($ruleName in $ruleNames) {
        Remove-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    }
}
Remove-NetFirewallRule -DisplayName "BC2 Stratum Server (Port 3333)" -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "BitcoinII-Core P2P (Port 8333)" -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "DigiByte Core P2P (Port 12024)" -ErrorAction SilentlyContinue

Write-Host "Removing desktop shortcuts..." -ForegroundColor Yellow
$desktopPath = [Environment]::GetFolderPath("Desktop")
foreach ($coin in $AllCoins) {
    Remove-Item "$desktopPath\$coin HammerForge.lnk" -ErrorAction SilentlyContinue
    Remove-Item "$desktopPath\$coin Monitor.lnk" -ErrorAction SilentlyContinue
    Remove-Item "$desktopPath\$coin Monitor.url" -ErrorAction SilentlyContinue
}

Write-Host "Removing generated files..." -ForegroundColor Yellow
$MiningDir = Join-Path $ProjectDir "Mining"

foreach ($coin in $AllCoins) {
    $batchPath = Join-Path $MiningDir "start-mining-$($coin.ToLower()).bat"
    if (Test-Path $batchPath) { Remove-Item $batchPath -Force }
    $configPath = Join-Path $ProjectDir "config-$($coin.ToLower()).json"
    if (Test-Path $configPath) { Remove-Item $configPath -Force }
}

$legacyFiles = @("start-mining.bat", "stop-mining.bat", "config.json", ".env")
foreach ($coin in $AllCoins) {
    $legacyFiles += "start-mining-$($coin.ToLower()).bat"
    $legacyFiles += "config-$($coin.ToLower()).json"
}
foreach ($file in $legacyFiles) {
    $path = Join-Path $ProjectDir $file
    if (Test-Path $path) { Remove-Item $path -Force }
}

$logsDir = Join-Path $ProjectDir "logs"
if (Test-Path $logsDir) { Remove-Item $logsDir -Recurse -Force }
$nodeModulesDir = Join-Path $ProjectDir "node_modules"
if (Test-Path $nodeModulesDir) { Remove-Item $nodeModulesDir -Recurse -Force }
$stratumDir = Join-Path $ProjectDir "stratum-server"
if (Test-Path $stratumDir) { Remove-Item $stratumDir -Recurse -Force }

$cloudflaredDir = Join-Path $ProjectDir "cloudflared"
if (Test-Path $cloudflaredDir) {
    taskkill /im cloudflared.exe /f 2>$null
    Remove-Item $cloudflaredDir -Recurse -Force
}
Remove-NetFirewallRule -DisplayName "HammerForge Mining Monitor (Port 5000)" -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Uninstall complete." -ForegroundColor Green
Write-Host "Coin wallets, blockchain data, and Node.js were NOT removed." -ForegroundColor Yellow
Write-Host ""
