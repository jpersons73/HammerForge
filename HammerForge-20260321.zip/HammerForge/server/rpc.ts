// Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
// Proprietary and confidential. See LICENSE file for details.

import { storage } from "./storage";
import { log } from "./index";
import type { CoinType } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

let rpcPollInterval: ReturnType<typeof setInterval> | null = null;
let hashratePollInterval: ReturnType<typeof setInterval> | null = null;
let templatePollInterval: ReturnType<typeof setInterval> | null = null;

export interface BlockTemplate {
  version: number;
  previousblockhash: string;
  transactions: BlockTemplateTx[];
  coinbasevalue: number;
  target: string;
  bits: string;
  height: number;
  curtime: number;
  mintime: number;
  mutable: string[];
  sigoplimit: number;
  sizelimit: number;
  weightlimit: number;
}

export interface BlockTemplateTx {
  data: string;
  txid: string;
  hash: string;
  fee: number;
  sigops: number;
  weight: number;
}

interface CoinDefaults {
  label: string;
  hashrateNoUrl: string;
  gbtParams: any[];
  algoNote: string;
  coinGeckoId: string;
  dataDirName: string;
}

const COIN_DEFAULTS: Record<CoinType, CoinDefaults> = {
  BC2: {
    label: "BC2",
    hashrateNoUrl: "https://www.hashrate.no/coins/BC2",
    gbtParams: [{ rules: ["segwit"] }],
    algoNote: "",
    coinGeckoId: "",
    dataDirName: "BitcoinII",
  },
  DGB: {
    label: "DGB",
    hashrateNoUrl: "",
    gbtParams: [{ rules: ["segwit"] }, "sha256d"],
    algoNote: " SHA-256",
    coinGeckoId: "digibyte",
    dataDirName: "DigiByte",
  },
  BTC: {
    label: "BTC",
    hashrateNoUrl: "",
    gbtParams: [{ rules: ["segwit"] }],
    algoNote: "",
    coinGeckoId: "bitcoin",
    dataDirName: "Bitcoin",
  },
  BCH: {
    label: "BCH",
    hashrateNoUrl: "",
    gbtParams: [{}],
    algoNote: "",
    coinGeckoId: "bitcoin-cash",
    dataDirName: "BitcoinCash",
  },
  BSV: {
    label: "BSV",
    hashrateNoUrl: "",
    gbtParams: [{}],
    algoNote: "",
    coinGeckoId: "bitcoin-cash-sv",
    dataDirName: "BitcoinSV",
  },
  XEC: {
    label: "XEC",
    hashrateNoUrl: "",
    gbtParams: [{}],
    algoNote: "",
    coinGeckoId: "ecash",
    dataDirName: "BitcoinABC",
  },
  FB: {
    label: "FB",
    hashrateNoUrl: "",
    gbtParams: [{ rules: ["segwit"] }],
    algoNote: "",
    coinGeckoId: "fractal-bitcoin",
    dataDirName: "FractalBitcoin",
  },
  PPC: {
    label: "PPC",
    hashrateNoUrl: "",
    gbtParams: [{ rules: ["segwit"] }],
    algoNote: "",
    coinGeckoId: "peercoin",
    dataDirName: "Peercoin",
  },
};

function getCoinDefaults(): CoinDefaults {
  const config = storage.getConfig();
  return COIN_DEFAULTS[config.coin] || COIN_DEFAULTS.BC2;
}

let currentTemplate: BlockTemplate | null = null;
let lastPrevHash: string = "";
let templateAvailable = false;
let onNewBlockCallback: (() => void) | null = null;
let rpcFailCount = 0;
let dgbDiffLogged = false;
let dgbDiffLogged2 = false;

function difficultyFromBits(bitsHex: string): number {
  const bits = parseInt(bitsHex, 16);
  const exponent = (bits >> 24) & 0xff;
  const mantissa = bits & 0x007fffff;
  const target = mantissa * Math.pow(2, 8 * (exponent - 3));
  if (target <= 0) return 0;
  const diff1Target = 0x00000000FFFF * Math.pow(2, 8 * (0x1d - 3));
  return diff1Target / target;
}

export function getBlockTemplate(): BlockTemplate | null {
  return currentTemplate;
}

export async function getFreshBlockTemplate(): Promise<BlockTemplate | null> {
  try {
    const coinDef = getCoinDefaults();
    const template = await rpcCall("getblocktemplate", coinDef.gbtParams);
    if (!template || !template.previousblockhash) return null;
    return template as BlockTemplate;
  } catch {
    return null;
  }
}

export function isTemplateAvailable(): boolean {
  return templateAvailable;
}

export function setOnNewBlock(callback: () => void): void {
  onNewBlockCallback = callback;
}

let cachedCookieAuth: string | null = null;
let cookieAuthFailed = false;

function tryReadCookieAuth(): string | null {
  if (cookieAuthFailed) return null;
  if (cachedCookieAuth) return cachedCookieAuth;

  const config = storage.getConfig();
  const coinDef = getCoinDefaults();
  const dataDirName = coinDef.dataDirName || config.coin;

  const possiblePaths: string[] = [];
  const appData = process.env.APPDATA || "";
  const localAppData = process.env.LOCALAPPDATA || "";

  if (appData) possiblePaths.push(path.join(appData, dataDirName, ".cookie"));
  if (localAppData) possiblePaths.push(path.join(localAppData, dataDirName, ".cookie"));

  for (const cookiePath of possiblePaths) {
    try {
      if (fs.existsSync(cookiePath)) {
        const cookie = fs.readFileSync(cookiePath, "utf-8").trim();
        if (cookie.includes(":")) {
          cachedCookieAuth = Buffer.from(cookie).toString("base64");
          log(`Using cookie auth from ${cookiePath}`, "rpc");
          return cachedCookieAuth;
        }
      }
    } catch {}
  }
  return null;
}

export async function rpcCall(method: string, params: any[] = []): Promise<any> {
  const config = storage.getConfig();
  const url = `http://${config.rpcHost}:${config.rpcPort}`;
  const rpcUser = (config.rpcUser || "").trim();
  const rpcPass = (config.rpcPassword || "").trim();
  const auth = Buffer.from(`${rpcUser}:${rpcPass}`).toString("base64");

  const body = JSON.stringify({
    jsonrpc: "1.0",
    id: Date.now(),
    method,
    params,
  });

  let response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${auth}`,
    },
    body,
    signal: AbortSignal.timeout(10000),
  });

  if (response.status === 401) {
    const cookieAuth = tryReadCookieAuth();
    if (cookieAuth) {
      response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Basic ${cookieAuth}`,
        },
        body,
        signal: AbortSignal.timeout(10000),
      });
      if (response.status === 401) {
        cookieAuthFailed = true;
        cachedCookieAuth = null;
      }
    }
  }

  if (!response.ok) {
    throw new Error(`RPC error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  if (data.error) {
    throw new Error(`RPC error: ${data.error.message}`);
  }
  return data.result;
}

export async function submitBlock(blockHex: string): Promise<string | null> {
  try {
    const result = await rpcCall("submitblock", [blockHex]);
    return result;
  } catch (err: any) {
    log(`submitblock RPC failed: ${err.message}`, "rpc");
    return `error: ${err.message}`;
  }
}

async function pollBlockTemplate(): Promise<void> {
  try {
    const coinDef = getCoinDefaults();
    const template = await rpcCall("getblocktemplate", coinDef.gbtParams);

    if (!template || !template.previousblockhash) {
      return;
    }

    currentTemplate = template as BlockTemplate;
    const wasAvailable = templateAvailable;
    templateAvailable = true;
    if (rpcFailCount > 0) {
      log(`RPC connection restored after ${rpcFailCount} failed attempts — REAL templates active`, "rpc");
    }
    rpcFailCount = 0;

    if (!wasAvailable) {
      log(`Block template received: height=${template.height} txs=${template.transactions?.length || 0} reward=${(template.coinbasevalue / 1e8).toFixed(8)} ${coinDef.label}`, "rpc");
      const tpl = template as any;
      log(`  version=0x${template.version.toString(16)} bits=${template.bits} target=${template.target?.slice(0, 24)}...`, "rpc");
      if (coinDef.label === "DGB") {
        log(`  pow_algo=${tpl.pow_algo || "N/A"} pow_algo_id=${tpl.pow_algo_id ?? "N/A"}`, "rpc");
        const algoVersionBits = template.version & 0xF00;
        const algoNames: Record<number, string> = { 0x000: "Scrypt", 0x200: "SHA-256D", 0x400: "Groestl", 0x600: "Skein", 0x800: "Qubit", 0xE00: "Odo" };
        log(`  version algo bits=0x${algoVersionBits.toString(16)} (${algoNames[algoVersionBits] || "unknown"})`, "rpc");
        const extraKeys = Object.keys(tpl).filter(k => !["version","previousblockhash","transactions","coinbasevalue","target","bits","height","curtime","mintime","mutable","sigoplimit","sizelimit","weightlimit","noncerange","capabilities","longpollid","submitold","expires"].includes(k));
        if (extraKeys.length > 0) {
          log(`  DGB extra fields: ${extraKeys.map(k => `${k}=${JSON.stringify(tpl[k])}`).join(", ")}`, "rpc");
        }
      }
    }

    if (template.previousblockhash !== lastPrevHash) {
      if (lastPrevHash !== "") {
        log(`NEW BLOCK detected: height=${template.height} prevhash=${template.previousblockhash.slice(0, 16)}... version=0x${template.version.toString(16)} bits=${template.bits}`, "rpc");
      }
      lastPrevHash = template.previousblockhash;

      storage.updateNetworkStats({
        blockHeight: template.height,
      });

      if (onNewBlockCallback) {
        onNewBlockCallback();
      }
    }
  } catch (err: any) {
    const config = storage.getConfig();
    if (templateAvailable) {
      log(`Block template LOST: ${err.message}`, "rpc");
      log(`  ${config.coin} node RPC (${config.rpcHost}:${config.rpcPort}) stopped responding. Miners now on FALLBACK templates — blocks CANNOT be found!`, "rpc");
    }
    templateAvailable = false;
    rpcFailCount++;
    if (rpcFailCount === 1 || rpcFailCount === 3 || rpcFailCount % 12 === 0) {
      log(`RPC FAILED (attempt #${rpcFailCount}): Cannot reach ${config.coin} node at ${config.rpcHost}:${config.rpcPort} — ${err.message}`, "rpc");
      if (rpcFailCount === 1) {
        log(`  RPC auth: user="${config.rpcUser}" pass="${(config.rpcPassword || "").slice(0, 4)}..." (${(config.rpcPassword || "").length} chars)`, "rpc");
      }
      log(`  Blocks CANNOT be found on fallback templates. Check: Is the node running? Is RPC enabled in the conf? Are credentials correct?`, "rpc");
    }
  }
}

async function pollNetworkStats(): Promise<void> {
  try {
    const coinDef = getCoinDefaults();
    const [blockchainInfo, miningInfo] = await Promise.all([
      rpcCall("getblockchaininfo"),
      rpcCall("getmininginfo"),
    ]);

    let difficulty = miningInfo.difficulty || blockchainInfo.difficulty || 0;
    let hashrate = miningInfo.networkhashps || 0;

    if (coinDef.label === "DGB") {
      if (!dgbDiffLogged) {
        dgbDiffLogged = true;
        log(`DGB RPC debug: miningInfo.difficulty=${JSON.stringify(miningInfo.difficulty)} (type=${typeof miningInfo.difficulty})`, "rpc");
        log(`DGB RPC debug: blockchainInfo.difficulty=${JSON.stringify(blockchainInfo.difficulty)} (type=${typeof blockchainInfo.difficulty})`, "rpc");
        const allKeys = Object.keys(miningInfo);
        log(`DGB miningInfo keys: ${allKeys.join(", ")}`, "rpc");
      }

      if (currentTemplate && currentTemplate.bits) {
        const sha256Diff = difficultyFromBits(currentTemplate.bits);
        if (sha256Diff > 0) {
          if (!dgbDiffLogged2) {
            dgbDiffLogged2 = true;
            log(`DGB SHA-256D difficulty from block template bits=${currentTemplate.bits}: ${sha256Diff.toFixed(2)}`, "rpc");
          }
          difficulty = sha256Diff;
        }
      } else {
        if (typeof miningInfo.difficulty === "object" && miningInfo.difficulty !== null) {
          difficulty = miningInfo.difficulty["sha256d"] || miningInfo.difficulty["sha256"] || difficulty;
        }
      }

      try {
        const sha256Hashrate = await rpcCall("getnetworkhashps", [120, -1, "sha256d"]);
        if (typeof sha256Hashrate === "number" && sha256Hashrate > 0) {
          hashrate = sha256Hashrate;
        }
      } catch {
        try {
          const sha256Hashrate = await rpcCall("getnetworkhashps", [120, -1, "sha256"]);
          if (typeof sha256Hashrate === "number" && sha256Hashrate > 0) {
            hashrate = sha256Hashrate;
          }
        } catch {}
      }
    }

    storage.updateNetworkStats({
      blockHeight: blockchainInfo.blocks || 0,
      networkDifficulty: difficulty,
      networkHashrate: hashrate,
    });
  } catch {
  }
}

function formatLargeNumber(value: number): string {
  if (value <= 0) return "?";
  if (value >= 1e15) return `${(value / 1e15).toFixed(2)} P`;
  if (value >= 1e12) return `${(value / 1e12).toFixed(2)} T`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)} G`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(2)} M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(2)} K`;
  return value.toFixed(2);
}

function formatHashrate(hashrate: number): string {
  if (hashrate <= 0) return "?";
  if (hashrate >= 1e18) return `${(hashrate / 1e18).toFixed(2)} EH/s`;
  if (hashrate >= 1e15) return `${(hashrate / 1e15).toFixed(2)} PH/s`;
  if (hashrate >= 1e12) return `${(hashrate / 1e12).toFixed(2)} TH/s`;
  if (hashrate >= 1e9) return `${(hashrate / 1e9).toFixed(2)} GH/s`;
  if (hashrate >= 1e6) return `${(hashrate / 1e6).toFixed(2)} MH/s`;
  if (hashrate >= 1e3) return `${(hashrate / 1e3).toFixed(2)} KH/s`;
  return `${hashrate.toFixed(2)} H/s`;
}

function parseHashrateValue(text: string): number {
  const match = text.match(/([\d.]+)\s*(Ph\/s|Th\/s|Gh\/s|Mh\/s|Kh\/s|h\/s|EH\/s)/i);
  if (!match) return 0;
  const value = parseFloat(match[1]);
  const unit = match[2].toLowerCase();
  const multipliers: Record<string, number> = {
    "h/s": 1,
    "kh/s": 1e3,
    "mh/s": 1e6,
    "gh/s": 1e9,
    "th/s": 1e12,
    "ph/s": 1e15,
    "eh/s": 1e18,
  };
  return value * (multipliers[unit] || 1);
}

function parseDifficultyValue(text: string): number {
  const match = text.match(/([\d.]+)\s*(G|T|M|K|P|E|B)?/i);
  if (!match) return 0;
  const value = parseFloat(match[1]);
  const suffix = (match[2] || "").toUpperCase();
  const multipliers: Record<string, number> = {
    "": 1,
    "K": 1e3,
    "M": 1e6,
    "B": 1e9,
    "G": 1e9,
    "T": 1e12,
    "P": 1e15,
    "E": 1e18,
  };
  return value * (multipliers[suffix] || 1);
}

async function pollExternalStats(): Promise<void> {
  const coinDef = getCoinDefaults();
  const config = storage.getConfig();

  if (coinDef.coinGeckoId) {
    await pollCoinGeckoStats(coinDef);
    return;
  }

  if (coinDef.hashrateNoUrl) {
    await pollHashrateNo(coinDef);
    return;
  }
}

async function pollHashrateNo(coinDef: CoinDefaults): Promise<void> {
  try {
    const response = await fetch(coinDef.hashrateNoUrl, {
      signal: AbortSignal.timeout(10000),
      headers: {
        "User-Agent": `${coinDef.label}SoloMiner/1.0`,
      },
    });

    if (!response.ok) return;
    const html = await response.text();

    const priceMatch = html.match(/optionHeader['"]\s*>Price<\/div>.*?class=['"]\s*w3-rest\s*['"]\s*>\$([\d.]+)/s);
    if (priceMatch) {
      const price = parseFloat(priceMatch[1]);
      if (price > 0) {
        storage.updateNetworkStats({ coinPrice: price });
      }
    }

    const diffMatch = html.match(/optionHeader['"]\s*>Difficulty<\/div>.*?class=['"]\s*w3-rest\s*['"]\s*>([\d.]+\s*[GTKMPEB]?)/s);
    if (diffMatch) {
      const diff = parseDifficultyValue(diffMatch[1]);
      if (diff > 0) {
        storage.updateNetworkStats({ networkDifficulty: diff });
      }
    }

    const hashrateMatch = html.match(/optionHeader['"]\s*>Hashrate<\/div>.*?class=['"]\s*w3-rest\s*['"]\s*>([\d.]+\s*(?:Ph\/s|Th\/s|Gh\/s|Mh\/s|Kh\/s|Eh\/s|h\/s))/si);
    if (hashrateMatch) {
      const hashrate = parseHashrateValue(hashrateMatch[1]);
      if (hashrate > 0) {
        storage.updateNetworkStats({ networkHashrate: hashrate });
      }
    }

    log(`hashrate.no ${coinDef.label}: price=$${priceMatch?.[1] || "?"}, diff=${diffMatch?.[1] || "?"}, hashrate=${hashrateMatch?.[1] || "?"}`, "rpc", true);
  } catch (err: any) {
    log(`hashrate.no fetch failed: ${err.message}`, "rpc");
  }
}

async function pollCoinGeckoStats(coinDef: CoinDefaults): Promise<void> {
  try {
    const response = await fetch(`https://api.coingecko.com/api/v3/coins/${coinDef.coinGeckoId}?localization=false&tickers=false&community_data=false&developer_data=false`, {
      signal: AbortSignal.timeout(10000),
      headers: {
        "User-Agent": `${coinDef.label}SoloMiner/1.0`,
        "Accept": "application/json",
      },
    });

    if (!response.ok) {
      log(`CoinGecko ${coinDef.label}: HTTP ${response.status}`, "rpc");
      return;
    }

    const data = await response.json() as any;
    const price = data?.market_data?.current_price?.usd;
    const priceStr = price != null ? `$${price}` : "$?";

    if (price != null && price > 0) {
      storage.updateNetworkStats({ coinPrice: price });
    }

    const stats = storage.getNetworkStats();
    const diff = stats.networkDifficulty;
    const diffStr = formatLargeNumber(diff);
    const hashrate = stats.networkHashrate;
    const hashStr = hashrate > 0 ? `, hashrate=${formatHashrate(hashrate)}` : "";

    log(`CoinGecko ${coinDef.label}: price=${priceStr}, diff=${diffStr}${hashStr}`, "rpc", true);
  } catch (err: any) {
    log(`CoinGecko ${coinDef.label} fetch failed: ${err.message}`, "rpc");
  }
}

export function startRpcPolling(): void {
  if (rpcPollInterval) return;

  const coinDef = getCoinDefaults();

  pollNetworkStats();
  pollExternalStats();
  pollBlockTemplate();

  rpcPollInterval = setInterval(() => {
    pollNetworkStats();
  }, 15000);

  hashratePollInterval = setInterval(() => {
    pollExternalStats();
  }, 120000);

  const currentConfig = storage.getConfig();
  const templatePollMs = currentConfig.coin === "DGB" ? 2000 : 5000;
  templatePollInterval = setInterval(() => {
    pollBlockTemplate();
  }, templatePollMs);

  const statsSource = coinDef.coinGeckoId ? "CoinGecko" : (coinDef.hashrateNoUrl ? "hashrate.no" : "RPC only");
  log(`RPC polling started (${coinDef.label}${coinDef.algoNote} node + ${statsSource} + block templates)`, "rpc");
}

export function stopRpcPolling(): void {
  if (rpcPollInterval) {
    clearInterval(rpcPollInterval);
    rpcPollInterval = null;
  }
  if (hashratePollInterval) {
    clearInterval(hashratePollInterval);
    hashratePollInterval = null;
  }
  if (templatePollInterval) {
    clearInterval(templatePollInterval);
    templatePollInterval = null;
  }
}
