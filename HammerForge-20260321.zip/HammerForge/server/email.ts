import nodemailer from "nodemailer";
import type { EmailConfig } from "@shared/schema";

function log(msg: string): void {
  const ts = new Date().toLocaleTimeString("en-US", { hour12: true });
  console.log(`${ts} [email] ${msg}`);
}

let cachedTransporter: nodemailer.Transporter | null = null;
let cachedConfigKey = "";

function getTransporter(emailCfg: EmailConfig): nodemailer.Transporter {
  const key = `${emailCfg.smtpHost}:${emailCfg.smtpPort}:${emailCfg.smtpUser}`;
  if (cachedTransporter && cachedConfigKey === key) {
    return cachedTransporter;
  }

  cachedTransporter = nodemailer.createTransport({
    host: emailCfg.smtpHost,
    port: emailCfg.smtpPort,
    secure: emailCfg.useTls && emailCfg.smtpPort === 465,
    auth: {
      user: emailCfg.smtpUser,
      pass: emailCfg.smtpPass,
    },
    tls: emailCfg.useTls ? {} : undefined,
  });
  cachedConfigKey = key;
  return cachedTransporter;
}

export async function sendBlockFoundEmail(
  emailCfg: EmailConfig,
  blockInfo: {
    coin: string;
    height: number;
    hash: string;
    reward: string;
    difficulty: string;
    worker: string;
    workerIp: string;
    timestamp: string;
    status: string;
  }
): Promise<void> {
  if (!emailCfg.enabled || !emailCfg.to || !emailCfg.smtpHost) {
    return;
  }

  try {
    const transporter = getTransporter(emailCfg);

    const subject = `BLOCK FOUND! ${blockInfo.coin} - Height ${blockInfo.height}`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #eee; padding: 30px; border-radius: 12px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #f59e0b; margin: 0; font-size: 28px;">BLOCK FOUND!</h1>
          <p style="color: #999; margin: 5px 0 0;">HammerForge Solo Mining</p>
        </div>
        <div style="background: #16213e; border-radius: 8px; padding: 20px; margin: 15px 0;">
          <table style="width: 100%; border-collapse: collapse; color: #eee;">
            <tr><td style="padding: 8px 0; color: #999; width: 120px;">Coin</td><td style="padding: 8px 0; font-weight: bold; color: #f59e0b;">${blockInfo.coin}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Height</td><td style="padding: 8px 0;">${blockInfo.height}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Reward</td><td style="padding: 8px 0; font-weight: bold; color: #22c55e;">${blockInfo.reward} ${blockInfo.coin}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Status</td><td style="padding: 8px 0; color: #22c55e;">${blockInfo.status}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Difficulty</td><td style="padding: 8px 0;">${blockInfo.difficulty}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Worker</td><td style="padding: 8px 0;">${blockInfo.worker}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Worker IP</td><td style="padding: 8px 0;">${blockInfo.workerIp}</td></tr>
            <tr><td style="padding: 8px 0; color: #999;">Time</td><td style="padding: 8px 0;">${blockInfo.timestamp}</td></tr>
          </table>
        </div>
        <div style="background: #0f3460; border-radius: 8px; padding: 15px; margin: 15px 0;">
          <p style="color: #999; margin: 0 0 5px; font-size: 12px;">Block Hash</p>
          <p style="color: #eee; margin: 0; font-size: 11px; word-break: break-all; font-family: monospace;">${blockInfo.hash}</p>
        </div>
        <div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #333;">
          <p style="color: #f59e0b; margin: 0; font-size: 14px;">100% of this block reward goes to YOUR wallet!</p>
        </div>
      </div>
    `;

    const text = [
      `BLOCK FOUND! - ${blockInfo.coin}`,
      ``,
      `Coin:       ${blockInfo.coin}`,
      `Height:     ${blockInfo.height}`,
      `Reward:     ${blockInfo.reward} ${blockInfo.coin}`,
      `Status:     ${blockInfo.status}`,
      `Hash:       ${blockInfo.hash}`,
      `Difficulty: ${blockInfo.difficulty}`,
      `Worker:     ${blockInfo.worker} (${blockInfo.workerIp})`,
      `Time:       ${blockInfo.timestamp}`,
      ``,
      `100% of this block reward goes to YOUR wallet!`,
    ].join("\n");

    await transporter.sendMail({
      from: emailCfg.smtpUser,
      to: emailCfg.to,
      subject,
      text,
      html,
    });

    log(`Block found email sent to ${emailCfg.to}`);
  } catch (err: any) {
    log(`Failed to send block found email: ${err.message}`);
    throw err;
  }
}
