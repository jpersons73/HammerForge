// Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
// Proprietary and confidential. See LICENSE file for details.

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { stopStratumServer } from "./stratum";
import path from "path";
import fs from "fs";

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

import * as fs from "fs";
import * as nodePath from "path";

let stratumLogStream: fs.WriteStream | null = null;

function getStratumLogStream(): fs.WriteStream {
  if (!stratumLogStream) {
    const logsDir = nodePath.resolve(import.meta.dirname, "..", "logs");
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }
    const logPath = nodePath.join(logsDir, "stratum.log");
    stratumLogStream = fs.createWriteStream(logPath, { flags: "a" });
  }
  return stratumLogStream;
}

export function log(message: string, source = "express", fileOnly = false) {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  const line = `${formattedTime} [${source}] ${message}`;
  if (!fileOnly) {
    console.log(line);
  }

  if (source === "stratum" || source === "rpc") {
    try {
      const stream = getStratumLogStream();
      const date = new Date().toISOString().slice(0, 10);
      stream.write(`${date} ${line}\n`);
    } catch {}
  }
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      const isPolling = path === "/api/monitor" || path === "/api/monitor-demo";
      if (isPolling) return;
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse).slice(0, 200)}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  app.use((err: any, _req: Request, res: Response, next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error("Internal Server Error:", err);

    if (res.headersSent) {
      return next(err);
    }

    return res.status(status).json({ message });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    try {
      serveStatic(app);
    } catch (err: any) {
      log(`Static build not found — serving standalone monitor page: ${err.message}`);
      const monitorHtml = path.resolve(import.meta.dirname, "monitor.html");
      if (fs.existsSync(monitorHtml)) {
        app.get("/", (_req, res) => res.redirect("/monitor"));
        app.get("/monitor", (_req, res) => res.sendFile(monitorHtml));
        app.get("/monitor-demo", (_req, res) => res.sendFile(monitorHtml));
      }
    }
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  const port = parseInt(process.env.PORT || "5000", 10);

  httpServer.on("error", (err: any) => {
    if (err.code === "EADDRINUSE") {
      log(`Port ${port} is already in use — web server disabled (stratum server still running)`, "express");
    } else {
      log(`HTTP server error: ${err.message}`, "express");
    }
  });

  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
    },
    async () => {
      log(`serving on port ${port}`);

      if (process.platform === "win32") {
        try {
          const { exec } = await import("child_process");
          setTimeout(() => {
            exec(`start "" "http://localhost:${port}/monitor"`);
            log("Opened mining monitor in default browser");
          }, 5000);
        } catch {
        }
      }
    },
  );

  let shuttingDown = false;
  const gracefulShutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    log(`${signal} received — shutting down gracefully...`);
    stopStratumServer();
    httpServer.close(() => {
      log("HTTP server closed");
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 3000);
  };

  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
})();
