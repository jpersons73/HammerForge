// Copyright (c) 2025 James Vernon Persons. All Rights Reserved.
// Proprietary and confidential. See LICENSE file for details.

import type { Express } from "express";
import type { Server } from "http";
import archiver from "archiver";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { startStratumServer, stopStratumServer } from "./stratum";
import { startDemoMode, stopDemoMode } from "./demo";
import { startRpcPolling, stopRpcPolling } from "./rpc";
import { execSync } from "child_process";
import { log } from "./index";
import { sendBlockFoundEmail } from "./email";

let tunnelUrl: string | null = null;

function loadConfigFromFile(): void {
  const configFile = process.env.CONFIG_FILE || "config.json";
  const configPath = path.resolve(import.meta.dirname, "..", configFile);
  try {
    if (fs.existsSync(configPath)) {
      let raw = fs.readFileSync(configPath, "utf-8");
      raw = raw.replace(/^\uFEFF/, "").replace(/^\xEF\xBB\xBF/, "").trim();
      const fileConfig = JSON.parse(raw);
      const validCoins = ["BC2", "DGB", "BTC", "BCH", "BSV", "XEC", "FB", "PPC"];
      const coin = validCoins.includes(fileConfig.coin) ? fileConfig.coin : "BC2";
      const coinPortDefaults: Record<string, { rpc: number; stratum: number; user: string; pass: string }> = {
        BC2: { rpc: 8232, stratum: 3333, user: "bc2rpc", pass: "bc2rpcpassword" },
        DGB: { rpc: 14022, stratum: 3334, user: "dgbrpc", pass: "dgbrpcpassword" },
        BTC: { rpc: 8332, stratum: 3335, user: "btcrpc", pass: "btcrpcpassword" },
        BCH: { rpc: 8432, stratum: 3336, user: "bchrpc", pass: "bchrpcpassword" },
        BSV: { rpc: 8532, stratum: 3337, user: "bsvrpc", pass: "bsvrpcpassword" },
        XEC: { rpc: 8632, stratum: 3338, user: "xecrpc", pass: "xecrpcpassword" },
        FB: { rpc: 8732, stratum: 3339, user: "fbrpc", pass: "fbrpcpassword" },
        PPC: { rpc: 9902, stratum: 3340, user: "ppcrpc", pass: "ppcrpcpassword" },
      };
      const defaults = coinPortDefaults[coin] || coinPortDefaults.BC2;
      const defaultRpcPort = defaults.rpc;
      const defaultStratumPort = defaults.stratum;
      const defaultRpcUser = defaults.user;
      const defaultRpcPassword = defaults.pass;
      const miningCfg: any = {
        walletAddress: fileConfig.walletAddress || "",
        stratumPort: fileConfig.stratumPort || defaultStratumPort,
        rpcHost: fileConfig.rpcHost || "127.0.0.1",
        rpcPort: fileConfig.rpcPort || defaultRpcPort,
        rpcUser: fileConfig.rpcUser || defaultRpcUser,
        rpcPassword: fileConfig.rpcPassword || defaultRpcPassword,
        coin,
      };
      if (fileConfig.email && fileConfig.email.enabled) {
        miningCfg.email = {
          enabled: true,
          smtpHost: fileConfig.email.smtpHost || "",
          smtpPort: fileConfig.email.smtpPort || 587,
          smtpUser: fileConfig.email.smtpUser || "",
          smtpPass: fileConfig.email.smtpPass || "",
          to: fileConfig.email.to || "",
          useTls: fileConfig.email.useTls !== false,
        };
      }
      storage.setConfig(miningCfg);
      log(`Loaded config from ${configPath}`, "config");
      log(`  coin=${coin} wallet=${miningCfg.walletAddress || "(empty)"} stratum=${miningCfg.stratumPort} rpc=${miningCfg.rpcHost}:${miningCfg.rpcPort} user=${miningCfg.rpcUser}`, "config");
    }
  } catch (err: any) {
    log(`Could not load ${configFile}: ${err.message}`, "config");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  loadConfigFromFile();

  const coinFromEnv = process.env.MINING_COIN;
  const validCoinTypes = ["BC2", "DGB", "BTC", "BCH", "BSV", "XEC", "FB", "PPC"];
  if (coinFromEnv && validCoinTypes.includes(coinFromEnv)) {
    const cfg = storage.getConfig();
    cfg.coin = coinFromEnv as any;
    const envPortDefaults: Record<string, { rpc: number; stratum: number; walletEnv: string; rpcUserEnv: string; rpcPassEnv: string }> = {
      BC2: { rpc: 8232, stratum: 3333, walletEnv: "BC2_WALLET_ADDRESS", rpcUserEnv: "BC2_RPC_USER", rpcPassEnv: "BC2_RPC_PASSWORD" },
      DGB: { rpc: 14022, stratum: 3334, walletEnv: "DGB_WALLET_ADDRESS", rpcUserEnv: "DGB_RPC_USER", rpcPassEnv: "DGB_RPC_PASSWORD" },
      BTC: { rpc: 8332, stratum: 3335, walletEnv: "BTC_WALLET_ADDRESS", rpcUserEnv: "BTC_RPC_USER", rpcPassEnv: "BTC_RPC_PASSWORD" },
      BCH: { rpc: 8432, stratum: 3336, walletEnv: "BCH_WALLET_ADDRESS", rpcUserEnv: "BCH_RPC_USER", rpcPassEnv: "BCH_RPC_PASSWORD" },
      BSV: { rpc: 8532, stratum: 3337, walletEnv: "BSV_WALLET_ADDRESS", rpcUserEnv: "BSV_RPC_USER", rpcPassEnv: "BSV_RPC_PASSWORD" },
      XEC: { rpc: 8632, stratum: 3338, walletEnv: "XEC_WALLET_ADDRESS", rpcUserEnv: "XEC_RPC_USER", rpcPassEnv: "XEC_RPC_PASSWORD" },
      FB: { rpc: 8732, stratum: 3339, walletEnv: "FB_WALLET_ADDRESS", rpcUserEnv: "FB_RPC_USER", rpcPassEnv: "FB_RPC_PASSWORD" },
      PPC: { rpc: 9902, stratum: 3340, walletEnv: "PPC_WALLET_ADDRESS", rpcUserEnv: "PPC_RPC_USER", rpcPassEnv: "PPC_RPC_PASSWORD" },
    };
    const envDefaults = envPortDefaults[coinFromEnv];
    if (envDefaults) {
      if (!cfg.rpcPort) cfg.rpcPort = envDefaults.rpc;
      if (!cfg.stratumPort) cfg.stratumPort = envDefaults.stratum;
      const walletFromEnv = process.env[envDefaults.walletEnv];
      if (walletFromEnv) cfg.walletAddress = walletFromEnv;
      const rpcUserFromEnv = process.env[envDefaults.rpcUserEnv];
      if (rpcUserFromEnv) cfg.rpcUser = rpcUserFromEnv;
      const rpcPassFromEnv = process.env[envDefaults.rpcPassEnv];
      if (rpcPassFromEnv) cfg.rpcPassword = rpcPassFromEnv;
    }
    storage.setConfig(cfg);
  }

  const walletEnvMap: Array<{ envKey: string; coin: string; rpcUserKey: string; rpcPassKey: string }> = [
    { envKey: "BC2_WALLET_ADDRESS", coin: "BC2", rpcUserKey: "BC2_RPC_USER", rpcPassKey: "BC2_RPC_PASSWORD" },
    { envKey: "DGB_WALLET_ADDRESS", coin: "DGB", rpcUserKey: "DGB_RPC_USER", rpcPassKey: "DGB_RPC_PASSWORD" },
    { envKey: "BTC_WALLET_ADDRESS", coin: "BTC", rpcUserKey: "BTC_RPC_USER", rpcPassKey: "BTC_RPC_PASSWORD" },
    { envKey: "BCH_WALLET_ADDRESS", coin: "BCH", rpcUserKey: "BCH_RPC_USER", rpcPassKey: "BCH_RPC_PASSWORD" },
    { envKey: "BSV_WALLET_ADDRESS", coin: "BSV", rpcUserKey: "BSV_RPC_USER", rpcPassKey: "BSV_RPC_PASSWORD" },
    { envKey: "XEC_WALLET_ADDRESS", coin: "XEC", rpcUserKey: "XEC_RPC_USER", rpcPassKey: "XEC_RPC_PASSWORD" },
    { envKey: "FB_WALLET_ADDRESS", coin: "FB", rpcUserKey: "FB_RPC_USER", rpcPassKey: "FB_RPC_PASSWORD" },
    { envKey: "PPC_WALLET_ADDRESS", coin: "PPC", rpcUserKey: "PPC_RPC_USER", rpcPassKey: "PPC_RPC_PASSWORD" },
  ];
  if (!coinFromEnv) {
    for (const entry of walletEnvMap) {
      const wallet = process.env[entry.envKey];
      if (wallet) {
        const cfg = storage.getConfig();
        cfg.walletAddress = wallet;
        cfg.coin = entry.coin as any;
        const envPortDefaults: Record<string, { rpc: number; stratum: number; user: string; pass: string }> = {
          BC2: { rpc: 8232, stratum: 3333, user: "bc2rpc", pass: "bc2rpcpassword" },
          DGB: { rpc: 14022, stratum: 3334, user: "dgbrpc", pass: "dgbrpcpassword" },
          BTC: { rpc: 8332, stratum: 3335, user: "btcrpc", pass: "btcrpcpassword" },
          BCH: { rpc: 8432, stratum: 3336, user: "bchrpc", pass: "bchrpcpassword" },
          BSV: { rpc: 8532, stratum: 3337, user: "bsvrpc", pass: "bsvrpcpassword" },
          XEC: { rpc: 8632, stratum: 3338, user: "xecrpc", pass: "xecrpcpassword" },
          FB: { rpc: 8732, stratum: 3339, user: "fbrpc", pass: "fbrpcpassword" },
          PPC: { rpc: 9902, stratum: 3340, user: "ppcrpc", pass: "ppcrpcpassword" },
        };
        const defaults = envPortDefaults[entry.coin];
        cfg.rpcPort = defaults.rpc;
        cfg.stratumPort = defaults.stratum;
        cfg.rpcUser = process.env[entry.rpcUserKey] || defaults.user;
        cfg.rpcPassword = process.env[entry.rpcPassKey] || defaults.pass;
        storage.setConfig(cfg);
        break;
      }
    }
  }

  const config = storage.getConfig();
  const hasWallet = !!config.walletAddress;
  const isDemoEnv = !hasWallet;
  const coinLabels: Record<string, string> = {
    BC2: "BC2", DGB: "DGB (SHA-256)", BTC: "BTC", BCH: "BCH", BSV: "BSV", XEC: "XEC", FB: "FB (Fractal Bitcoin)", PPC: "PPC (Peercoin)"
  };
  const coinLabel = coinLabels[config.coin] || config.coin;

  if (isDemoEnv) {
    startDemoMode();
    log(`Running in DEMO mode for ${coinLabel} (no wallet configured)`, "app");
  } else {
    log(`${coinLabel} solo mining to wallet: ${config.walletAddress}`, "app");
  }

  startRpcPolling();

  try {
    const stratumPort = storage.getConfig().stratumPort || 3333;
    startStratumServer(stratumPort);
  } catch (err: any) {
    log(`Stratum server not started (port may be unavailable): ${err.message}`, "stratum");
  }

  httpServer.on("close", () => {
    stopDemoMode();
    stopStratumServer();
    stopRpcPolling();
  });

  app.get("/api/download", (_req, res) => {
    try {
      const projectRoot = path.resolve(import.meta.dirname, "..");

      const ts = new Date().toISOString().slice(0, 10).replace(/-/g, "");
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename=HammerForge-${ts}.zip`);
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");

      const archive = archiver("zip", { zlib: { level: 9 } });

      archive.on("error", (err: any) => {
        log(`Zip error: ${err.message}`, "download");
        if (!res.headersSent) {
          res.status(500).json({ error: "Failed to create zip" });
        }
      });

      archive.pipe(res);

      const codeDirs = ["server", "shared", "client"];
      for (const dir of codeDirs) {
        archive.directory(path.join(projectRoot, dir), `HammerForge/${dir}`, (entry) => {
          if (entry.name.includes("node_modules") || entry.name.includes(".cache")) {
            return false;
          }
          return entry;
        });
      }

      const projectFiles = ["package.json", "tsconfig.json", "vite.config.ts", "tailwind.config.ts", "postcss.config.js"];
      for (const file of projectFiles) {
        const filePath = path.join(projectRoot, file);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: `HammerForge/${file}` });
        }
      }

      const windowsDir = path.join(projectRoot, "windows");
      if (fs.existsSync(windowsDir)) {
        const windowsEntries = fs.readdirSync(windowsDir);
        for (const entry of windowsEntries) {
          if (entry.includes("node_modules") || entry.includes(".cache") || entry.startsWith(".") || entry === "Thumbs.db" || entry === "desktop.ini") continue;
          const fullPath = path.join(windowsDir, entry);
          const stat = fs.statSync(fullPath);
          if (stat.isFile()) {
            archive.file(fullPath, { name: `HammerForge/${entry}` });
          } else if (stat.isDirectory()) {
            const subFiles = fs.readdirSync(fullPath);
            for (const sf of subFiles) {
              if (sf.startsWith(".") || sf === "Thumbs.db" || sf === "desktop.ini") continue;
              const sfPath = path.join(fullPath, sf);
              if (fs.statSync(sfPath).isFile()) {
                archive.file(sfPath, { name: `HammerForge/${entry}/${sf}` });
              }
            }
          }
        }
      }

      const rootFiles: Array<{ src: string; dest: string }> = [
        { src: "GITHUB-README.md", dest: "README.md" },
        { src: "LICENSE", dest: "LICENSE" },
      ];
      for (const { src, dest } of rootFiles) {
        const filePath = path.join(projectRoot, src);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: `HammerForge/${dest}` });
        }
      }

      archive.finalize();
    } catch (err: any) {
      log(`Download error: ${err.message}`, "download");
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to create download" });
      }
    }
  });

  app.get("/api/monitor", (_req, res) => {
    res.json(storage.getMonitorData());
  });

  app.get("/monitor", (_req, res) => {
    const monitorHtml = path.resolve(import.meta.dirname, "monitor.html");
    if (fs.existsSync(monitorHtml)) {
      res.sendFile(monitorHtml);
    } else {
      res.status(200).send("<html><body style='background:#0a0a0f;color:#eee;padding:40px;text-align:center'><h1>Monitor page not found</h1></body></html>");
    }
  });

  app.get("/api/dashboard", (_req, res) => {
    res.json(storage.getDashboardData());
  });

  app.get("/api/hashrate-history", (_req, res) => {
    res.json(storage.getHashrateHistory());
  });

  app.get("/api/blocks-found", (_req, res) => {
    res.json(storage.getBlocksFound());
  });

  app.get("/api/tunnel-url", (_req, res) => {
    if (!tunnelUrl) {
      try {
        const tsIp = execSync("tailscale ip -4", { timeout: 3000, encoding: "utf-8" }).trim();
        if (tsIp && /^100\./.test(tsIp)) {
          tunnelUrl = `http://${tsIp}:5000/monitor`;
          log(`Tailscale IP detected: ${tsIp} -- remote URL: ${tunnelUrl}`, "server");
        }
      } catch {}
    }
    res.json({ url: tunnelUrl });
  });

  app.post("/api/tunnel-url", (req, res) => {
    const { url } = req.body;
    if (url && typeof url === "string") {
      tunnelUrl = url;
      log(`Remote access URL set: ${url}`, "server");
    }
    res.json({ ok: true });
  });

  app.get("/api/monitor-demo", (_req, res) => {
    const now = Date.now();
    const coin = storage.getConfig().coin || "BTC";
    const walletAddress = storage.getConfig().walletAddress || "bc1qczmq77nrrqsxn3uk8p007r9pf07uzq2t96w3g5";

    const demoWorkers = [
      { id: "w1", name: "Bitaxe-Ultra-1", minerType: "Bitaxe", ipAddress: "192.168.1.50", connected: true, connectedAt: now - 86400000, lastShareAt: now - 12000, sharesAccepted: 4821, sharesRejected: 23, hashrate1m: 580e9, hashrate5m: 565e9, hashrate1hr: 572e9, hashrate1d: 568e9, bestDifficulty: 2847291, bestDifficultyShare: "00000000000a3f2e...", colorIndex: 0 },
      { id: "w2", name: "Bitaxe-Ultra-2", minerType: "Bitaxe", ipAddress: "192.168.1.51", connected: true, connectedAt: now - 72000000, lastShareAt: now - 8000, sharesAccepted: 3912, sharesRejected: 15, hashrate1m: 545e9, hashrate5m: 552e9, hashrate1hr: 548e9, hashrate1d: 551e9, bestDifficulty: 1923847, bestDifficultyShare: "00000000000b8c1d...", colorIndex: 1 },
      { id: "w3", name: "Avalon-Nano3S", minerType: "Avalon Nano 3S", ipAddress: "192.168.1.52", connected: true, connectedAt: now - 43200000, lastShareAt: now - 5000, sharesAccepted: 6234, sharesRejected: 41, hashrate1m: 3.8e12, hashrate5m: 3.75e12, hashrate1hr: 3.82e12, hashrate1d: 3.79e12, bestDifficulty: 18293741, bestDifficultyShare: "000000000001e8f3...", colorIndex: 2 },
      { id: "w4", name: "NiceHash", minerType: "NiceHash", ipAddress: "85.214.132.77", connected: true, connectedAt: now - 7200000, lastShareAt: now - 3000, sharesAccepted: 892, sharesRejected: 2, hashrate1m: 45e12, hashrate5m: 42e12, hashrate1hr: 43.5e12, hashrate1d: 0, bestDifficulty: 89274123, bestDifficultyShare: "0000000000002a1f...", colorIndex: 3 },
      { id: "w5", name: "MagicMiner-01", minerType: "MagicMiner", ipAddress: "192.168.1.55", connected: false, connectedAt: now - 172800000, lastShareAt: now - 3600000, sharesAccepted: 12847, sharesRejected: 87, hashrate1m: 0, hashrate5m: 0, hashrate1hr: 0, hashrate1d: 890e9, bestDifficulty: 5182934, bestDifficultyShare: "00000000000712ab...", colorIndex: 4 },
    ];

    const totalHashrate = demoWorkers.reduce((s, w) => s + w.hashrate1m, 0);
    const totalAccepted = demoWorkers.reduce((s, w) => s + w.sharesAccepted, 0);
    const totalRejected = demoWorkers.reduce((s, w) => s + w.sharesRejected, 0);

    const hashrateHistory: any[] = [];
    for (let i = 240; i >= 0; i--) {
      const t = now - i * 30000;
      const jitter = 0.85 + Math.random() * 0.3;
      const nhJitter = i < 60 ? (0.8 + Math.random() * 0.4) : 0;
      const hr = (4.9e12 * jitter) + (45e12 * nhJitter);
      const wk = i < 60 ? 4 : 3;
      const bestShareVal = Math.floor(50000 + Math.random() * 2000000 + (240 - i) * 8000);
      hashrateHistory.push({
        timestamp: t,
        hashrate: hr,
        workers: wk,
        accepted: Math.floor(totalAccepted * (240 - i) / 240),
        rejected: Math.floor(totalRejected * (240 - i) / 240),
        bestShare: bestShareVal,
      });
    }

    const demoShares: any[] = [];
    const workerNames = ["Bitaxe-Ultra-1", "Bitaxe-Ultra-2", "Avalon-Nano3S", "NiceHash", "MagicMiner-01"];
    for (let i = 0; i < 50; i++) {
      const wIdx = Math.floor(Math.random() * 4);
      const diff = [15000, 32000, 65536, 500000][wIdx] || 15000;
      const shareDiff = diff * (1 + Math.random() * 3);
      demoShares.push({
        id: `s${i}`,
        workerId: `w${wIdx + 1}`,
        workerName: workerNames[wIdx],
        difficulty: Math.floor(shareDiff),
        targetDifficulty: diff,
        accepted: Math.random() > 0.03,
        timestamp: now - i * 15000 - Math.floor(Math.random() * 5000),
        hash: "0000000000" + Array.from({length: 54}, () => "0123456789abcdef"[Math.floor(Math.random()*16)]).join(""),
      });
    }

    const bestShareHistory = [
      { timestamp: now - 14400000, difficulty: 1283941 },
      { timestamp: now - 13500000, difficulty: 892417 },
      { timestamp: now - 12600000, difficulty: 4729183 },
      { timestamp: now - 11700000, difficulty: 2184923 },
      { timestamp: now - 10800000, difficulty: 3512847 },
      { timestamp: now - 9900000, difficulty: 18293741 },
      { timestamp: now - 9000000, difficulty: 7291534 },
      { timestamp: now - 8100000, difficulty: 11482915 },
      { timestamp: now - 7200000, difficulty: 5847291 },
      { timestamp: now - 6300000, difficulty: 52918234 },
      { timestamp: now - 5400000, difficulty: 31284719 },
      { timestamp: now - 4500000, difficulty: 14829374 },
      { timestamp: now - 3600000, difficulty: 42918234 },
      { timestamp: now - 2700000, difficulty: 89274123 },
      { timestamp: now - 1800000, difficulty: 28471923 },
      { timestamp: now - 900000, difficulty: 61829347 },
    ];

    const blocksFound = [
      { coin, height: 891234, hash: "000000000000000000024a8f3e1b9c7d5f2a4e6b8c0d1f3a5b7c9d1e3f5a7b9c", reward: "3.125", difficulty: "89,274,123", worker: "NiceHash", workerIp: "85.214.132.77", timestamp: new Date(now - 172800000).toLocaleString(), status: "ACCEPTED BY NETWORK" },
      { coin, height: 889012, hash: "00000000000000000001f8a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2", reward: "3.125", difficulty: "52,918,234", worker: "Avalon-Nano3S", workerIp: "192.168.1.52", timestamp: new Date(now - 604800000).toLocaleString(), status: "ACCEPTED BY NETWORK" },
    ];

    res.json({
      config: { coin, walletAddress, stratumPort: storage.getConfig().stratumPort, algoNote: coin === "DGB" ? " SHA-256" : "" },
      workers: demoWorkers,
      recentShares: demoShares,
      networkStats: {
        blockHeight: 891456,
        networkDifficulty: 113757254524742,
        networkHashrate: 8.14e20,
        coinPrice: 87425.32,
        bestShare: 89274123,
        totalAccepted,
        totalRejected,
        uptime: 259200,
        connectedWorkers: 4,
        totalHashrate,
      },
      stratumStatus: { running: true, port: storage.getConfig().stratumPort, connections: 4, startedAt: now - 259200000 },
      hashrateHistory,
      bestShareHistory,
      blocksFound,
    });
  });

  app.get("/api/email-status", (_req, res) => {
    const cfg = storage.getConfig();
    if (cfg.email && cfg.email.enabled) {
      res.json({
        enabled: true,
        to: cfg.email.to,
        smtpHost: cfg.email.smtpHost,
        smtpPort: cfg.email.smtpPort,
      });
    } else {
      res.json({ enabled: false });
    }
  });

  app.post("/api/test-email", async (_req, res) => {
    const cfg = storage.getConfig();
    if (!cfg.email || !cfg.email.enabled) {
      return res.status(400).json({ error: "Email notifications not configured" });
    }
    try {
      await sendBlockFoundEmail(cfg.email, {
        coin: cfg.coin || "TEST",
        height: 999999,
        hash: "0000000000000000000test0000000000000000000000000000000000000000",
        reward: "0.00000000",
        difficulty: "1,000,000",
        worker: "test-worker",
        workerIp: "127.0.0.1",
        timestamp: new Date().toLocaleString(),
        status: "TEST - Email notifications are working!",
      });
      res.json({ success: true, message: `Test email sent to ${cfg.email.to}` });
    } catch (err: any) {
      res.status(500).json({ error: `Failed to send test email: ${err.message}` });
    }
  });

  return httpServer;
}
