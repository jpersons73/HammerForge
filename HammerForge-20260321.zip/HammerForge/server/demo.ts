import { storage } from "./storage";
import type { Worker, ShareEntry } from "@shared/schema";
import { randomUUID, createHash } from "crypto";

let demoInterval: ReturnType<typeof setInterval> | null = null;

function randomHashrate(base: number, variance: number): number {
  return Math.max(0, base + (Math.random() - 0.5) * variance * 2);
}

export function startDemoMode(): void {
  if (demoInterval) return;

  storage.updateNetworkStats({
    blockHeight: 891234,
  });

  demoInterval = setInterval(() => {
    const workers = storage.getWorkers();
    workers.forEach((worker) => {
      if (Math.random() < 0.7) {
        const u = Math.random();
        const shareDiff = Math.max(10000, Math.floor(10000 / Math.pow(u, 1)));
        const accepted = Math.random() > 0.03;

        const share: ShareEntry = {
          id: randomUUID(),
          workerId: worker.id,
          workerName: worker.name,
          difficulty: shareDiff,
          targetDifficulty: 10000,
          accepted,
          timestamp: Date.now(),
          hash: createHash("sha256").update(randomUUID()).digest("hex"),
        };
        storage.addShare(share);

        const updates: Partial<Worker> = {
          lastShareAt: Date.now(),
          hashrate1m: randomHashrate(420e9, 60e9),
          hashrate5m: randomHashrate(415e9, 40e9),
          hashrate1hr: randomHashrate(410e9, 25e9),
          hashrate1d: randomHashrate(405e9, 15e9),
        };

        if (accepted) {
          updates.sharesAccepted = worker.sharesAccepted + 1;
        } else {
          updates.sharesRejected = worker.sharesRejected + 1;
        }

        if (shareDiff > worker.bestDifficulty) {
          updates.bestDifficulty = shareDiff;
          updates.bestDifficultyShare = share.hash;
        }

        storage.updateWorker(worker.id, updates);
      }
    });

    storage.updateNetworkStats({
      blockHeight: storage.getNetworkStats().blockHeight + (Math.random() < 0.02 ? 1 : 0),
    });
  }, 5000);
}

export function stopDemoMode(): void {
  if (demoInterval) {
    clearInterval(demoInterval);
    demoInterval = null;
  }
}
