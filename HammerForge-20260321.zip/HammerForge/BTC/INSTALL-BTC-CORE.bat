@echo off
echo ============================================
echo   Bitcoin Core Wallet Installer
echo ============================================
echo.
echo This will download and install Bitcoin Core
echo from bitcoincore.org
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-btc-core.ps1"

pause
