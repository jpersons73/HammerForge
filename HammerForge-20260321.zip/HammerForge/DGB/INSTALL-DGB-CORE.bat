@echo off
echo ============================================
echo   DigiByte Core Wallet Installer
echo ============================================
echo.
echo This will download and install DigiByte Core
echo from GitHub (https://github.com/DigiByte-Core/digibyte)
echo.
echo DigiByte mining uses the SHA-256 algorithm.
echo.
echo Requesting Administrator privileges...
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0install-dgb-core.ps1"

pause
